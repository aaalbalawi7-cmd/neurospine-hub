// Topics, topic pages, search, images, quick reference, bookmarks, notes, flashcards, compare.
import { Lib, esc, tokenize, isSkipPage } from './library.js';
import { SECTIONS, FOCUS, QUICKREF, IMAGE_KINDS, HIGHLIGHT_COLORS, HIGHLIGHT_LABELS } from './taxonomy.js';
import { getPdf, renderPage, imageBoxes } from './pdfproc.js';
import { S, views, actions, $, $$, go, render, toast, modal, confirmBox, fmtDate, fmtAgo, n, citeChip, emptyState, notFound, saveSingleton, putItem, delItem, topicStatusChip, isFav, pageHash, recordVisit, colorCss, uid, storageError } from './core.js';

// ---------- excerpt registry (for buttons on verbatim passages) ----------
const EX = new Map(); let exN = 0; let lastExKey = 0;
function exKey(pa) { const k = ++exN; EX.set(k, pa); if (EX.size > 6000) EX.delete(EX.keys().next().value); lastExKey = k; return k; }
const exGet = k => EX.get(k);
export function excerptCard(pa, hl, { compact = false } = {}) {
  const k = exKey(pa);
  const body = hl ? Lib.markHtml(pa.text, hl) : esc(pa.text);
  return `<div class="excerpt" data-src-doc="${pa.docId}" data-src-p="${pa.p}">
    ${pa.head || pa.crumbs?.length ? `<div class="crumbs">${esc([...(pa.crumbs || []).slice(-2), pa.head].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(' › '))}</div>` : ''}
    <blockquote>${body}</blockquote>
    <div class="meta">${citeChip(pa.docId, pa.p)}
      <div class="acts">${compact ? '' : `<button class="btn sm ghost" data-act="ex-hl" data-k="${k}" title="Save to My Notes">Save</button><button class="btn sm ghost" data-act="ex-card" data-k="${k}">Flashcard</button><button class="btn sm ghost" data-act="ex-qref" data-k="${k}">Quick ref</button>`}<button class="btn sm ghost" data-act="ex-col" data-k="${k}">Add to…</button></div>
    </div></div>`;
}
actions['ex-hl'] = async (el) => { const pa = exGet(+el.dataset.k); const { saveAnnotation } = await import('./viewer.js'); await saveAnnotation({ docId: pa.docId, p: pa.p, quote: pa.text, source: 'excerpt', label: el.closest('[data-section]')?.dataset.label || '' }); toast('Saved to My Notes.'); };
actions['ex-card'] = (el) => { const pa = exGet(+el.dataset.k); openCardModal({ docId: pa.docId, p: pa.p, text: pa.text, front: pa.head || '' }); };
actions['ex-qref'] = (el) => { const pa = exGet(+el.dataset.k); openQrefModal({ docId: pa.docId, p: pa.p, text: pa.text, title: pa.head || '' }); };
actions['ex-col'] = (el) => { const pa = exGet(+el.dataset.k); collectionPicker({ type: 'passage', docId: pa.docId, p: pa.p, text: pa.text.slice(0, 1500), title: pa.head || Lib.breadcrumb(pa.docId, pa.p).slice(-1)[0] || '' }); };

// ---------- Medical Topics ----------
views.topics = () => {
  const tax = Lib.taxonomy; const q = (S.topicFilter || '').toLowerCase();
  const maxPages = Math.max(1, ...Lib.allTopics().map(t => (Lib.topicPages.get(t.id) || []).length));
  const sugg = Lib.suggestions;
  const cats = tax.map((c, ci) => {
    const subs = c.subs.map(s => {
      const id = s.alias || s.id; const t = Lib.topics.get(id); if (!t) return '';
      if (q && !t.name.toLowerCase().includes(q) && !c.name.toLowerCase().includes(q)) return '';
      const pages = Lib.topicPages.get(id) || []; const docs = new Set(pages.map(([gi]) => Lib.gDoc[gi])).size;
      return `<div class="sub ${pages.length ? '' : 'zero'}"><a href="#topic-${id}">${esc(s.name)}${s.alias ? ' <span class="muted" style="font-size:12px">(shared)</span>' : ''}</a><span class="row" style="gap:8px">${topicStatusChip(id)}${isFav(id) ? '<span title="Favorite" style="color:var(--warn)">★</span>' : ''}<span class="muted tnum" style="font-size:12.5px">${pages.length ? `${n(pages.length)} pages · ${docs} doc${docs > 1 ? 's' : ''}` : 'No sources yet'}</span></span><span class="bar"><i style="width:${Math.round(100 * Math.sqrt(pages.length / maxPages))}%"></i></span></div>`;
    }).join('');
    if (!subs) return '';
    const total = new Set(c.subs.flatMap(s => (Lib.topicPages.get(s.alias || s.id) || []).map(x => x[0]))).size;
    return `<details class="cat" ${q || ci < 1 ? 'open' : ''}><summary><span class="code">${esc(c.code || ci + 1)}</span><h3>${esc(c.name)}</h3><span class="muted tnum" style="font-size:13px">${n(total)} pages</span></summary>${subs}</details>`;
  }).join('');
  return `<div class="page-head"><span class="eyebrow">Medical Topics</span><h1>Topics organized from your PDFs</h1><p>Pages are sorted into topics from their chapter titles, headings and wording. Open a topic to read verbatim excerpts arranged under standard headings, each linked to its page.</p></div>
  <div class="row" style="margin-bottom:14px"><input type="search" id="tf" placeholder="Filter topics" value="${esc(S.topicFilter || '')}" style="flex:1;max-width:420px"><a class="btn" href="#preferences">Edit categories</a></div>
  <div class="stack">${cats || emptyState('No topics match', 'Try a different filter.')}</div>
  <div class="panel" style="margin-top:20px"><div class="row between"><h3>Suggested topics from your PDFs</h3><span class="muted tnum">${n(sugg.length)}</span></div>
  <p class="muted" style="font-size:13.5px;margin-bottom:10px">Chapters and sections in your documents that don't match an existing topic. Add one to place it in a category; its pages then appear on its own topic page.</p>
  ${sugg.length ? `<input type="search" id="sf" placeholder="Filter suggestions" style="width:100%;max-width:420px;margin-bottom:8px"><div class="list" id="slist">${suggList(sugg)}</div>` : '<p class="muted">Upload PDFs to see suggestions.</p>'}</div>`;
};
function suggList(list) {
  return list.slice(0, 150).map((s, i) => `<div class="li"><div><div class="t">${esc(s.title)}</div><small>${s.sources.map(x => `${esc(Lib.shortName(x.docId))} p. ${esc(Lib.label(x.docId, x.p0))}–${esc(Lib.label(x.docId, x.p1))}`).join(' · ')}${s.cat ? ` · suggested: ${esc(Lib.taxonomy.find(c => c.id === s.cat)?.name || '')}` : ''}</small></div><button class="btn sm" data-act="sugg-add" data-key="${esc(s.key)}">Add</button></div>`).join('') + (list.length > 150 ? `<p class="muted">${list.length - 150} more. Filter to find them.</p>` : '');
}
views.after_topics = (a, root) => {
  root.querySelector('#tf').addEventListener('input', e => { S.topicFilter = e.target.value; const pos = e.target.selectionStart; render().then(() => { const f = $('#tf'); f.focus(); f.setSelectionRange(pos, pos); }); });
  root.querySelector('#sf')?.addEventListener('input', e => { const q = e.target.value.toLowerCase(); $('#slist').innerHTML = suggList(Lib.suggestions.filter(s => s.title.toLowerCase().includes(q))); });
};
actions['sugg-add'] = (el) => {
  const s = Lib.suggestions.find(x => x.key === el.dataset.key); if (!s) return;
  const m = modal(`<h3>Add “${esc(s.title)}” as a topic</h3><label>Name <input type="text" id="sn" value="${esc(s.title)}" style="width:100%"></label>
  <label>Category <select id="sc" style="width:100%">${Lib.taxonomy.map(c => `<option value="${c.id}" ${c.id === s.cat ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
  <p class="muted" style="font-size:13px">Its pages: ${s.sources.map(x => `${esc(Lib.shortName(x.docId))} p. ${esc(Lib.label(x.docId, x.p0))}–${esc(Lib.label(x.docId, x.p1))}`).join('; ')}</p>
  <div class="row end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="sa">Add topic</button></div>`);
  m.el.querySelector('#sa').onclick = async () => {
    const tree = JSON.parse(JSON.stringify(Lib.taxonomy)); const cat = tree.find(c => c.id === m.el.querySelector('#sc').value);
    const id = 'c-' + uid(); const name = m.el.querySelector('#sn').value.trim() || s.title;
    cat.subs.push({ id, name, kw: [s.title.toLowerCase().replace(/[,:;]/g, ' ').replace(/\s+/g, ' ').trim() + ':2'], anchors: s.sources });
    m.close(); const { saveTaxonomy } = await import('./app.js'); await saveTaxonomy(tree); toast(`Added ${name}.`); go('topic-' + id);
  };
};

// ---------- topic page ----------
views.topic = (id) => {
  const t = Lib.topics.get(id);
  if (!t) return `<div class="panel"><h2>Topic not found</h2><p class="muted">It may have been removed from your categories.</p></div>`;
  recordVisit({ type: 'topic', id });
  const c = Lib.topicContent(id);
  const cat = Lib.taxonomy.find(x => x.id === t.cat);
  const st = S.topicStatus[id] || '';
  const docs = new Set(c.pages.map(([gi]) => Lib.gDoc[gi]));
  const kwHl = { terms: new Set(t.kwc.filter(k => k.toks.length === 1 && k.w >= 1).map(k => k.toks[0])), phrases: t.kwc.filter(k => k.toks.length > 1 && k.w >= 1.5).map(k => k.toks) };
  const head = `<div class="page-head"><span class="eyebrow">${esc(cat?.code || '')} · ${esc(cat?.name || '')}</span>
    <div class="row between"><h1>${esc(t.name)}</h1><div class="row">
      <div class="seg" id="tstatus">${[['reviewed', 'Reviewed'], ['review', 'Needs review'], ['important', 'Important']].map(([k, l]) => `<button data-s="${k}" class="${st === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <button class="icon-btn ${isFav(id) ? 'on' : ''}" data-act="t-fav" data-id="${id}" aria-label="Favorite" title="Favorite">★</button>
      <button class="btn sm" data-act="t-col" data-id="${id}">Add to collection</button>
      <button class="btn sm" data-act="t-export" data-id="${id}">Export PDF</button>
    </div></div>
    <p>${c.pages.length ? `${n(c.pages.length)} pages in ${docs.size} document${docs.size > 1 ? 's' : ''} discuss this topic. Excerpts below are quoted verbatim from those pages; select any text to highlight it.` : ''}</p></div>`;
  if (!c.pages.length) return head + `<div class="panel stack">${notFound()}<p class="muted">No uploaded page matched this topic's keywords. Upload a reference that covers it, or adjust the topic's keywords in Settings.</p><div class="row"><a class="btn primary" href="#library">Upload PDFs</a><a class="btn" href="#preferences">Edit keywords</a></div></div>`;
  const present = new Set(c.sections.map(s => s.id));
  const toc = `<nav class="toc" aria-label="Sections">${SECTIONS.map((s, i) => `<a href="#topic-${id}" data-jump="sec-${s.id}" class="${present.has(s.id) ? '' : 'dim'}">${i + 1}. ${esc(s.name)}</a>`).join('')}<a href="#topic-${id}" data-jump="sec-refs">17. References</a></nav>`;
  const primary = c.primary.length ? `<div class="panel"><h3>Main sections in your sources</h3><div class="list">${c.primary.slice(0, 12).map(s => `<div class="li"><div><div class="t">${esc(s.t)}</div><small>${esc(Lib.shortName(s.docId))} · pp. ${esc(Lib.label(s.docId, s.p))}–${esc(Lib.label(s.docId, s.end))}</small></div><a class="btn sm" href="#${pageHash(s.docId, s.p)}">Open</a></div>`).join('')}</div></div>` : '';
  const figs = Lib.figures.filter(f => f.topics.includes(id)).slice(0, 12);
  const secHtml = c.sections.map(s => {
    const num = SECTIONS.findIndex(x => x.id === s.id) + 1;
    const aiKey = `topic:${id}:${s.id}`; const cached = S.ai.get(aiKey.replace(/[^A-Za-z0-9_\-.~:@+]/g, '_'));
    return `<section class="section" id="sec-${s.id}" data-section="${s.id}" data-label="${esc(s.name)}">
      <div class="section-h"><h3><span class="num">${String(num).padStart(2, '0')}</span>${esc(s.name)}</h3><div class="row"><span class="muted" style="font-size:12.5px">${s.items.length + s.more} matching passages</span><button class="btn sm" data-act="ai-section" data-topic="${id}" data-sec="${s.id}">${cached ? 'Show cited summary' : 'Summarize with citations'}</button></div></div>
      <div id="ai-${s.id}"></div>
      ${s.items.map(pa => excerptCard(pa, kwHl)).join('')}
      ${s.more ? `<button class="btn sm ghost" data-act="sec-more" data-topic="${id}" data-sec="${s.id}">Show ${Math.min(6, s.more)} more passages</button>` : ''}
    </section>`;
  }).join('');
  const refs = Lib.refList(c.pages.map(x => x[0]));
  const refHtml = `<section class="section" id="sec-refs"><div class="section-h"><h3><span class="num">17</span>References and original PDF pages</h3></div>
    <div class="panel"><div class="list">${refs.map(r => `<div><div class="t" style="font-weight:600;margin-bottom:6px">${esc(Lib.docName(r.docId))}</div><div class="chips">${r.runs.slice(0, 80).map(([a, b]) => `<a class="chip mono" href="#${pageHash(r.docId, a)}">p. ${esc(Lib.label(r.docId, a))}${b > a ? '–' + esc(Lib.label(r.docId, b)) : ''}</a>`).join('')}${r.runs.length > 80 ? `<span class="muted">+${r.runs.length - 80} more ranges</span>` : ''}</div></div>`).join('')}</div></div></section>`;
  const side = `<div class="stack sticky">
    ${figs.length ? `<div class="panel"><h3>Figures and tables</h3><div class="stack">${figs.slice(0, 6).map(f => `<a href="#images" data-act="fig-open" data-fig="${esc(f.id)}" class="row" style="gap:8px;align-items:flex-start;color:inherit"><span class="label-chip">${esc(f.label)}</span><span style="font-size:13px">${esc(f.cap.slice(f.label.length, 110))}…</span></a>`).join('')}</div><a class="btn sm" style="margin-top:10px" href="#images" data-act="img-topic" data-id="${id}">All ${figs.length}${figs.length === 12 ? '+' : ''} in Image Library</a></div>` : ''}
    <div class="panel stack"><h3>Tools</h3>
      <button class="btn" data-act="t-ask" data-id="${id}">Ask the assistant about ${esc(t.name)}</button>
      <button class="btn" data-act="t-compare" data-id="${id}">Compare references</button>
      <button class="btn" data-act="t-cards" data-id="${id}">Generate flashcards</button>
      <button class="btn" data-act="t-search" data-id="${id}">Search within this topic</button>
      <button class="btn" data-act="t-overlap" data-id="${id}">Find overlapping passages</button>
      <div id="overlap"></div>
    </div></div>`;
  return head + toc + `<div class="layout-2" style="margin-top:16px"><div class="stack" style="gap:26px">${primary}${secHtml || '<div class="panel">' + notFound() + '<p class="muted">Pages match this topic, but no passage fits the standard headings. See the references below.</p></div>'}${refHtml}</div>${side}</div>`;
};
views.after_topic = (id, root) => {
  root.querySelector('#tstatus')?.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; const s = b.dataset.s; if (S.topicStatus[id] === s) delete S.topicStatus[id]; else S.topicStatus[id] = s; saveSingleton('topicStatus'); $$('#tstatus button').forEach(x => x.classList.toggle('on', S.topicStatus[id] === x.dataset.s)); });
  root.querySelectorAll('[data-jump]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); document.getElementById(a.dataset.jump)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));
};
actions['sec-more'] = (el) => {
  const c = Lib.topicContent(el.dataset.topic, { perSection: 9 }); const s = c.sections.find(x => x.id === el.dataset.sec); if (!s) return;
  const t = Lib.topics.get(el.dataset.topic); const hl = { terms: new Set(t.kwc.filter(k => k.toks.length === 1 && k.w >= 1).map(k => k.toks[0])), phrases: [] };
  const sec = el.closest('section'); sec.querySelectorAll('.excerpt').forEach(x => x.remove()); el.insertAdjacentHTML('beforebegin', s.items.map(pa => excerptCard(pa, hl)).join('')); el.remove();
};
actions['t-fav'] = (el) => { const id = el.dataset.id; const f = S.favorites.topics; const i = f.indexOf(id); if (i >= 0) f.splice(i, 1); else f.push(id); el.classList.toggle('on', i < 0); saveSingleton('favorites'); };
actions['t-col'] = (el) => collectionPicker({ type: 'topic', id: el.dataset.id, title: Lib.topics.get(el.dataset.id)?.name });
actions['t-search'] = (el) => { S.search.opts.topic = el.dataset.id; S.search.q = S.search.q || Lib.topics.get(el.dataset.id).name; go('search'); };
actions['t-ask'] = (el) => { S.askTopic = el.dataset.id; go('assistant'); };
actions['t-compare'] = (el) => { S.compareTopic = el.dataset.id; go('compare'); };
actions['t-cards'] = (el) => { S.cardTopic = el.dataset.id; go('flashcards'); };
actions['t-export'] = async (el) => { const { exportTopicPdf } = await import('./exporter.js'); exportTopicPdf(el.dataset.id); };
actions['img-topic'] = (el) => { S.imgFilter = { ...(S.imgFilter || {}), topic: el.dataset.id }; go('images'); };
actions['t-overlap'] = (el) => {
  const pages = (Lib.topicPages.get(el.dataset.id) || []).slice(0, 80).map(x => x[0]);
  const pairs = Lib.overlaps(pages).slice(0, 10);
  $('#overlap').innerHTML = pairs.length ? `<p class="muted" style="font-size:13px">Page pairs from different documents with shared wording (likely overlapping information):</p>` + pairs.map(x => `<div class="src"><div class="row">${citeChip(Lib.gDoc[x.a], Lib.gPage[x.a])}<span>↔</span>${citeChip(Lib.gDoc[x.b], Lib.gPage[x.b])}</div><small class="muted tnum">${Math.round(x.sim * 100)}% of 4-word phrases shared</small></div>`).join('') : '<p class="muted" style="font-size:13px">No substantial overlap found between documents for this topic.</p>';
};

// ---------- search ----------
views.search = () => {
  const o = S.search.opts;
  const docs = [...S.docs.values()];
  return `<div class="page-head"><span class="eyebrow">Search</span><h1>Search the library</h1></div>
  <form id="sform" class="stack" style="gap:0">
    <div class="bigsearch"><div class="gsearch" style="max-width:none;flex:1"><input type="search" id="sq" value="${esc(S.search.q)}" placeholder="e.g. &quot;Hunt and Hess&quot; OR WFNS, glioma NOT pediatric, spondylolisthesis AND meyerding" autocomplete="off" style="padding-left:14px;font-size:17px"><div class="ac hidden" id="sac"></div></div><button class="btn primary">Search</button></div>
    <div class="searchbar-opts">
      <select id="so-cat" aria-label="Category"><option value="">All categories</option>${Lib.taxonomy.map(c => `<option value="${c.id}" ${o.category === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      <select id="so-topic" aria-label="Topic"><option value="">Any topic</option>${Lib.allTopics().map(t => `<option value="${t.id}" ${o.topic === t.id ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select>
      <select id="so-focus" aria-label="Focus"><option value="">Any content</option>${Object.entries(FOCUS).map(([k, f]) => `<option value="${k}" ${o.focus === k ? 'selected' : ''}>${f.name}</option>`).join('')}</select>
      <label class="chk"><input type="checkbox" id="so-fuzzy" ${o.fuzzy ? 'checked' : ''}> Fuzzy</label>
      <label class="chk"><input type="checkbox" id="so-abbr" ${o.abbr !== false ? 'checked' : ''}> Expand abbreviations</label>
      <label class="chk"><input type="checkbox" id="so-group" ${S.search.group ? 'checked' : ''}> Group by document</label>
    </div>
    ${docs.length > 1 ? `<div class="chips" style="margin-top:10px" id="so-docs">${docs.map(d => `<button type="button" class="chip ${o.docs.includes(d.id) ? 'on' : ''}" data-doc="${d.id}">${esc(Lib.shortName(d.id))}</button>`).join('')}</div>` : ''}
  </form>
  <details style="margin-top:10px" class="muted"><summary style="cursor:pointer;font-size:13px">Search syntax</summary><div style="font-size:13px;padding:8px 0;display:grid;gap:4px">
    <span><span class="mono">"exact phrase"</span> matches words in order · <span class="mono">A AND B</span> (default) · <span class="mono">A OR B</span> · <span class="mono">NOT A</span> or <span class="mono">-A</span> · <span class="mono">( )</span> to group</span>
    <span><span class="mono">mening*</span> prefix match · <span class="mono">schwanoma~</span> fuzzy match · abbreviations such as <span class="mono">SAH</span>, <span class="mono">ACDF</span> or <span class="mono">TLIF</span> also find the spelled-out term</span></div></details>
  <div id="sres" style="margin-top:14px"></div>`;
};
views.after_search = (a, root) => {
  const o = S.search.opts; const q = root.querySelector('#sq');
  const run = () => { S.search.q = q.value; S.search.shown = 20; drawResults(); $('#gq').value = q.value; };
  root.querySelector('#sform').addEventListener('submit', e => { e.preventDefault(); $('#sac').classList.add('hidden'); run(); });
  const bindSel = (sel, key) => root.querySelector(sel).addEventListener('change', e => { o[key] = e.target.value; drawResults(); });
  bindSel('#so-cat', 'category'); bindSel('#so-topic', 'topic'); bindSel('#so-focus', 'focus');
  root.querySelector('#so-fuzzy').addEventListener('change', e => { o.fuzzy = e.target.checked; drawResults(); });
  root.querySelector('#so-abbr').addEventListener('change', e => { o.abbr = e.target.checked; drawResults(); });
  root.querySelector('#so-group').addEventListener('change', e => { S.search.group = e.target.checked; drawResults(); });
  root.querySelector('#so-docs')?.addEventListener('click', e => { const b = e.target.closest('[data-doc]'); if (!b) return; const d = b.dataset.doc; const i = o.docs.indexOf(d); if (i >= 0) o.docs.splice(i, 1); else o.docs.push(d); b.classList.toggle('on'); drawResults(); });
  // autocomplete
  const box = root.querySelector('#sac');
  q.addEventListener('input', () => { const it = Lib.ready && q.value.length > 1 ? Lib.suggest(q.value, 8) : []; box.innerHTML = it.map(s => `<button type="button" data-t="${esc(s.text)}" data-k="${s.kind}" data-id="${s.id || ''}"><span>${esc(s.text)}</span><small>${s.kind === 'topic' ? 'Topic' : esc(s.hint || '')}</small></button>`).join(''); box.classList.toggle('hidden', !it.length); });
  box.addEventListener('mousedown', e => { const b = e.target.closest('button'); if (!b) return; e.preventDefault(); box.classList.add('hidden'); if (b.dataset.k === 'topic') go('topic-' + b.dataset.id); else { q.value = b.dataset.t; run(); } });
  q.addEventListener('blur', () => setTimeout(() => box.classList.add('hidden'), 150));
  drawResults();
};
function drawResults() {
  const box = $('#sres'); if (!box) return; const q = S.search.q.trim();
  if (!Lib.ready) { box.innerHTML = '<p class="muted">The library is still being indexed…</p>'; return; }
  if (!q) { box.innerHTML = Lib.pageCount ? '<p class="muted">Type a term, phrase or abbreviation.</p>' : emptyState('Nothing to search yet', 'Upload PDFs in the PDF Library first.', '<a class="btn primary" href="#library">Upload PDFs</a>'); return; }
  const r = Lib.search(q, S.search.opts); S.search.last = r; const hl = Lib.highlightSet(r.info);
  const notes = [];
  if (r.info.corrected.length) notes.push('Showing close spellings for ' + r.info.corrected.map(([a, b]) => `<b>${esc(a)}</b> → <b>${esc(b)}</b>`).join(', '));
  if (r.info.expanded.length) notes.push('Also matched ' + r.info.expanded.map(([a, b]) => `${esc(a.toUpperCase())} = “${esc(b)}”`).join(', '));
  if (!r.total) { box.innerHTML = notFound() + (notes.length ? `<p class="note-bar">${notes.join(' · ')}</p>` : '') + `<p class="muted" style="margin-top:8px">Try fewer words, the fuzzy option, or a different spelling.</p>`; return; }
  let list = r.results;
  if (S.search.group) { const by = new Map(); for (const x of list) { if (!by.has(x.docId)) by.set(x.docId, []); by.get(x.docId).push(x); } list = [...by.values()].flat(); }
  const shown = list.slice(0, S.search.shown);
  let lastDoc = null;
  box.innerHTML = `<div class="row between"><p class="note-bar"><b class="tnum">${n(r.total)}</b> matching pages · ${r.ms} ms${notes.length ? ' · ' + notes.join(' · ') : ''}</p></div>
  <div class="panel" style="padding:4px 18px">${shown.map(x => {
    const crumbs = Lib.breadcrumb(x.docId, x.p); const sn = Lib.snippets(x.gi, hl);
    const grp = S.search.group && x.docId !== lastDoc ? `<h3 style="padding-top:14px">${esc(Lib.docName(x.docId))}</h3>` : ''; lastDoc = x.docId;
    return grp + `<div class="result"><div class="row between"><h4><a href="#${pageHash(x.docId, x.p)}" data-act="open-hit" data-doc="${x.docId}" data-p="${x.p}">${esc(crumbs.slice(-1)[0] || 'Page ' + Lib.label(x.docId, x.p))}</a></h4>${citeChip(x.docId, x.p)}</div>${crumbs.length > 1 ? `<div class="crumbs">${esc(crumbs.slice(0, -1).join(' › '))}</div>` : ''}${sn.map(s => `<p class="snip">${s}</p>`).join('')}<div class="chips">${(Lib.pageTopics[x.gi] || []).slice(0, 3).map(([t]) => `<a class="chip" href="#topic-${t}">${esc(Lib.topics.get(t)?.name)}</a>`).join('')}</div></div>`;
  }).join('')}</div>
  ${list.length > S.search.shown ? `<div class="row" style="justify-content:center;margin-top:12px"><button class="btn" data-act="more-results">Show more (${n(list.length - S.search.shown)} left)</button></div>` : ''}`;
}
actions['more-results'] = () => { S.search.shown += 30; drawResults(); };
actions['open-hit'] = async (el) => { const { setViewerHighlight } = await import('./viewer.js'); setViewerHighlight(Lib.highlightSet(S.search.last.info)); go(pageHash(el.dataset.doc, +el.dataset.p)); };

// ---------- image library ----------
const thumbCache = new Map(); let thumbQueue = []; let thumbBusy = 0;
async function figCrop(f) {
  const meta = S.docs.get(f.docId); const { pdf } = await getPdf(meta);
  const page = await pdf.getPage(f.p + 1); const vp = page.getViewport({ scale: 1 });
  let boxes = (await imageBoxes(page)).filter(b => b.w * b.h > vp.width * vp.height * 0.02);
  boxes.sort((a, b) => b.w * b.h - a.w * a.h);
  return { pdf, crop: boxes[0] && f.kind !== 'table' ? boxes[0] : null, boxes };
}
function pumpThumbs() {
  while (thumbBusy < 2 && thumbQueue.length) {
    const [f, el] = thumbQueue.shift(); if (!el.isConnected) continue; thumbBusy++;
    (async () => {
      try {
        let url = thumbCache.get(f.id);
        if (!url) { const { pdf, crop } = await figCrop(f); const c = document.createElement('canvas'); await renderPage(pdf, f.p + 1, c, { scale: crop ? 1.2 : 0.5, crop }); url = c.toDataURL('image/jpeg', 0.8); thumbCache.set(f.id, url); }
        el.innerHTML = `<img src="${url}" alt="${esc(f.label)}">`;
      } catch { el.innerHTML = '<div class="ph">Original PDF not on this device</div>'; }
      thumbBusy--; pumpThumbs();
    })();
  }
}
views.images = () => {
  const F = S.imgFilter = S.imgFilter || { kind: '', cat: '', doc: '', q: '', topic: '' };
  return `<div class="page-head"><span class="eyebrow">Image Library</span><h1>Figures, images and tables</h1><p>Every item is taken from a page of your PDFs, found through its caption (or through an image scan of the document). Images are rendered from the original PDF page.</p></div>
  <div class="stack">
    <div class="row"><input type="search" id="if-q" placeholder="Search captions" value="${esc(F.q)}" style="flex:1;max-width:380px">
      <select id="if-cat"><option value="">All categories</option>${Lib.taxonomy.map(c => `<option value="${c.id}" ${F.cat === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
      <select id="if-topic"><option value="">Any topic</option>${Lib.allTopics().map(t => `<option value="${t.id}" ${F.topic === t.id ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select>
      <select id="if-doc"><option value="">All documents</option>${[...S.docs.values()].map(d => `<option value="${d.id}" ${F.doc === d.id ? 'selected' : ''}>${esc(Lib.shortName(d.id))}</option>`).join('')}</select></div>
    <div class="chips" id="if-kind"><button class="chip ${!F.kind ? 'on' : ''}" data-k="">All types</button>${IMAGE_KINDS.map(k => `<button class="chip ${F.kind === k.id ? 'on' : ''}" data-k="${k.id}">${k.name}</button>`).join('')}</div>
    <div id="figs"></div></div>`;
};
function filteredFigs() {
  const F = S.imgFilter; const q = F.q.toLowerCase();
  return Lib.figures.filter(f => (!F.kind || f.kinds.includes(F.kind)) && (!F.doc || f.docId === F.doc) && (!F.topic || f.topics.includes(F.topic)) && (!F.cat || f.topics.some(t => Lib.topics.get(t)?.cat === F.cat)) && (!q || f.cap.toLowerCase().includes(q)));
}
function drawFigs(limit = 60) {
  const box = $('#figs'); if (!box) return; const list = filteredFigs();
  if (!Lib.figures.length) { box.innerHTML = emptyState('No figures yet', 'Figures and tables appear here once PDFs with captions are uploaded.'); return; }
  box.innerHTML = `<p class="note-bar" style="margin-bottom:10px">${n(list.length)} items</p><div class="figgrid">${list.slice(0, limit).map(f => `<div class="fig" data-act="fig-open" data-fig="${esc(f.id)}" tabindex="0"><div class="im" data-thumb="${esc(f.id)}"><div class="ph">${esc(f.label)}</div></div><div class="cap"><div class="row between"><span class="label-chip">${esc(f.label)}</span>${citeChip(f.docId, f.p)}</div><p>${esc(f.cap)}</p></div></div>`).join('')}</div>${list.length > limit ? `<div class="row" style="justify-content:center;margin-top:12px"><button class="btn" data-act="more-figs" data-l="${limit + 60}">Show more</button></div>` : ''}`;
  const io = new IntersectionObserver(ents => { for (const e of ents) if (e.isIntersecting) { io.unobserve(e.target); const f = Lib.figures.find(x => x.id === e.target.dataset.thumb); if (f) { thumbQueue.push([f, e.target]); pumpThumbs(); } } }, { rootMargin: '200px' });
  box.querySelectorAll('[data-thumb]').forEach(el => io.observe(el));
}
actions['more-figs'] = (el) => drawFigs(+el.dataset.l);
views.after_images = (a, root) => {
  const F = S.imgFilter;
  root.querySelector('#if-q').addEventListener('input', e => { F.q = e.target.value; drawFigs(); });
  for (const [sel, key] of [['#if-cat', 'cat'], ['#if-doc', 'doc'], ['#if-topic', 'topic']]) root.querySelector(sel).addEventListener('change', e => { F[key] = e.target.value; drawFigs(); });
  root.querySelector('#if-kind').addEventListener('click', e => { const b = e.target.closest('[data-k]'); if (!b) return; F.kind = b.dataset.k; $$('#if-kind .chip').forEach(x => x.classList.toggle('on', x === b)); drawFigs(); });
  drawFigs();
};
actions['fig-open'] = async (el) => {
  const f = Lib.figures.find(x => x.id === el.dataset.fig); if (!f) return;
  const m = modal(`<div class="lightbox"><div class="stack"><div class="row"><button class="icon-btn" id="lzm" aria-label="Zoom out">−</button><button class="icon-btn" id="lz0" aria-label="Reset zoom">1:1</button><button class="icon-btn" id="lzp" aria-label="Zoom in">+</button><button class="btn sm" id="lfull">Full screen</button><button class="btn sm" id="lpage">Whole page</button><button class="btn sm" id="ltext">Side-by-side text</button></div><div class="lb-stage" id="lbs"><p class="muted" style="padding:40px">Rendering from the original PDF…</p></div></div>
    <div class="stack"><span class="label-chip" style="justify-self:start">${esc(f.label)}</span><p style="font:15px/1.55 var(--font-read)">${esc(f.cap)}</p>${citeChip(f.docId, f.p)}<div class="chips">${f.topics.map(t => `<a class="chip" href="#topic-${t}" data-close>${esc(Lib.topics.get(t)?.name || t)}</a>`).join('')}</div><a class="btn primary" href="#${pageHash(f.docId, f.p)}" data-close>Open the page</a><div id="lside" class="ptext" style="max-height:40vh;overflow:auto;display:none"></div></div></div>`, { wide: true });
  const stage = m.el.querySelector('#lbs'); let z = 1; let whole = f.kind === 'table';
  const draw = async () => {
    try {
      const { pdf, crop } = await figCrop(f); const c = document.createElement('canvas');
      await renderPage(pdf, f.p + 1, c, { scale: 3, crop: whole ? null : crop });
      stage.innerHTML = ''; stage.appendChild(c); c.style.width = (c.width / 3 * z) + 'px';
    } catch { stage.innerHTML = '<p class="muted" style="padding:30px">The original PDF is not available on this device. Attach it from the PDF Library to view images.</p>'; }
  };
  const setZ = v => { z = v; const c = stage.querySelector('canvas'); if (c) c.style.width = (c.width / 3 * z) + 'px'; };
  m.el.querySelector('#lzm').onclick = () => setZ(Math.max(0.3, z * 0.8)); m.el.querySelector('#lzp').onclick = () => setZ(Math.min(5, z * 1.25)); m.el.querySelector('#lz0').onclick = () => setZ(1);
  m.el.querySelector('#lpage').onclick = () => { whole = !whole; draw(); };
  m.el.querySelector('#lfull').onclick = async () => { try { await stage.requestFullscreen(); } catch { m.el.classList.toggle('full'); } };
  m.el.querySelector('#ltext').onclick = () => { const s = m.el.querySelector('#lside'); s.style.display = s.style.display === 'none' ? 'block' : 'none'; s.textContent = Lib.text[f.gi] || ''; };
  draw();
};

// ---------- quick reference ----------
views.quickref = () => {
  const g = S.qrGroup || 'classifications';
  return `<div class="page-head"><span class="eyebrow">Quick Reference</span><h1>Quick reference</h1><p>Classifications, indications, steps and other high-yield material found through headings, table and figure captions and section titles in your PDFs. Open an entry to read the source text.</p></div>
  <div class="tabs" id="qrtabs">${QUICKREF.map(q => `<button data-g="${q.id}" class="${g === q.id ? 'on' : ''}">${q.name} <small class="muted">${n(Lib.qref.filter(e => e.group === q.id).length)}</small></button>`).join('')}<button data-g="mine" class="${g === 'mine' ? 'on' : ''}">My cards <small class="muted">${S.qcards.length}</small></button></div>
  <div class="row" style="margin:14px 0"><input type="search" id="qr-q" placeholder="Filter" value="${esc(S.qrQ || '')}" style="flex:1;max-width:380px"><select id="qr-cat"><option value="">All categories</option>${Lib.taxonomy.map(c => `<option value="${c.id}" ${S.qrCat === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select><button class="btn" data-act="qr-new">New card</button></div>
  <div id="qrlist"></div>`;
};
function drawQr(limit = 80) {
  const box = $('#qrlist'); if (!box) return; const g = S.qrGroup || 'classifications'; const q = (S.qrQ || '').toLowerCase(); const cat = S.qrCat || '';
  if (g === 'mine') {
    const list = S.qcards.filter(c => (!q || (c.title + ' ' + c.text).toLowerCase().includes(q)) && (!cat || c.cat === cat)).sort((a, b) => b.createdAt - a.createdAt);
    box.innerHTML = list.length ? `<div class="grid g2">${list.map(c => `<div class="excerpt" data-src-doc="${c.docId || ''}" data-src-p="${c.p ?? ''}"><div class="row between"><h3>${esc(c.title || 'Untitled')}</h3><span class="label-chip">${esc(c.group ? QUICKREF.find(x => x.id === c.group)?.name || '' : '')}</span></div><blockquote>${esc(c.text)}</blockquote>${c.note ? `<p>${esc(c.note)}</p>` : ''}<div class="meta">${c.docId && S.docs.has(c.docId) ? citeChip(c.docId, c.p) : '<span class="muted" style="font-size:12.5px">No source page</span>'}<div class="acts"><button class="btn sm ghost" data-act="qr-edit" data-id="${c.id}">Edit</button><button class="btn sm ghost danger" data-act="qr-del" data-id="${c.id}">Delete</button></div></div></div>`).join('')}</div>` : emptyState('No custom cards yet', 'Select text anywhere in the library and choose “Quick ref”, or press “Save as card” on an entry.');
    return;
  }
  const list = Lib.qref.filter(e => e.group === g && (!q || e.title.toLowerCase().includes(q) || Lib.breadcrumb(Lib.gDoc[e.gi], Lib.gPage[e.gi]).join(' ').toLowerCase().includes(q)) && (!cat || (Lib.pageTopics[e.gi] || []).some(([t]) => Lib.topics.get(t)?.cat === cat)));
  box.innerHTML = list.length ? `<p class="note-bar">${n(list.length)} entries</p><div class="panel" style="padding:4px 18px">${list.slice(0, limit).map((e, i) => { const d = Lib.gDoc[e.gi], p = Lib.gPage[e.gi]; const cr = Lib.breadcrumb(d, p).slice(-2).join(' › '); return `<details class="result" data-qi="${i}"><summary class="row between" style="cursor:pointer"><span><b>${esc(e.title)}</b>${cr ? ` <span class="crumbs">· ${esc(cr)}</span>` : ''} <span class="label-chip">${e.kind}</span></span>${citeChip(d, p)}</summary><div class="qx" style="margin-top:8px"></div></details>`; }).join('')}</div>${list.length > limit ? `<div class="row" style="justify-content:center;margin-top:12px"><button class="btn" data-act="qr-more" data-l="${limit + 80}">Show more</button></div>` : ''}` : (Lib.pageCount ? notFound() : emptyState('Nothing here yet', 'Upload PDFs to build the quick reference.'));
  box.querySelectorAll('details[data-qi]').forEach(det => det.addEventListener('toggle', () => {
    if (!det.open) return; const e = list[+det.dataset.qi]; const qx = det.querySelector('.qx'); if (qx.innerHTML) return;
    const pa = { gi: e.gi, docId: Lib.gDoc[e.gi], p: Lib.gPage[e.gi], text: Lib.qrefExcerpt(e), head: e.title, crumbs: Lib.breadcrumb(Lib.gDoc[e.gi], Lib.gPage[e.gi]) };
    qx.innerHTML = excerptCard(pa, null) + `<div class="row" style="margin-top:6px"><button class="btn sm" data-act="qr-save" data-k="${lastExKey}" data-g="${g}">Save as card</button></div>`;
  }));
}
views.after_quickref = (a, root) => {
  root.querySelector('#qrtabs').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.qrGroup = b.dataset.g; $$('#qrtabs button').forEach(x => x.classList.toggle('on', x === b)); drawQr(); });
  root.querySelector('#qr-q').addEventListener('input', e => { S.qrQ = e.target.value; drawQr(); });
  root.querySelector('#qr-cat').addEventListener('change', e => { S.qrCat = e.target.value; drawQr(); });
  drawQr();
};
actions['qr-more'] = el => drawQr(+el.dataset.l);
actions['qr-save'] = el => { const pa = exGet(+el.dataset.k); openQrefModal({ docId: pa.docId, p: pa.p, text: pa.text, title: pa.head, group: el.dataset.g }); };
actions['qr-new'] = () => openQrefModal({ text: '', title: '' });
actions['qr-edit'] = el => { const c = S.qcards.find(x => x.id === el.dataset.id); if (c) openQrefModal(c); };
actions['qr-del'] = async el => { if (!await confirmBox('Delete this card?')) return; S.qcards = S.qcards.filter(x => x.id !== el.dataset.id); await delItem('qref', el.dataset.id); drawQr(); };
export function openQrefModal(src) {
  const m = modal(`<h3>${src.id ? 'Edit' : 'New'} quick-reference card</h3>
    <label>Title <input type="text" id="qt" value="${esc(src.title || '')}" style="width:100%"></label>
    <label>Group <select id="qg" style="width:100%"><option value="">General</option>${QUICKREF.map(q => `<option value="${q.id}" ${src.group === q.id ? 'selected' : ''}>${q.name}</option>`).join('')}</select></label>
    <label>Source text <textarea id="qx" style="min-height:140px" ${src.docId ? 'readonly' : ''}>${esc(src.text || '')}</textarea></label>
    ${src.docId ? `<div>${citeChip(src.docId, src.p)} <span class="muted" style="font-size:12.5px">Source text is kept verbatim.</span></div>` : '<p class="muted" style="font-size:12.5px">Cards made without a source page are marked as such.</p>'}
    <label>Your note <textarea id="qn">${esc(src.note || '')}</textarea></label>
    <div class="row end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="qs">Save card</button></div>`);
  m.el.querySelector('#qs').onclick = async () => {
    const topics = src.docId ? (Lib.pageTopics[Lib.gi(src.docId, src.p)] || []).map(x => x[0]) : [];
    const c = { id: src.id || uid(), docId: src.docId || null, p: src.p ?? null, title: m.el.querySelector('#qt').value.trim(), group: m.el.querySelector('#qg').value, text: m.el.querySelector('#qx').value, note: m.el.querySelector('#qn').value, cat: src.cat || (topics[0] ? Lib.categoryOf(topics[0]) : ''), createdAt: src.createdAt || Date.now() };
    const i = S.qcards.findIndex(x => x.id === c.id); if (i >= 0) S.qcards[i] = c; else S.qcards.push(c);
    await putItem('qref', c); m.close(); toast('Card saved to Quick Reference.'); if (S.route.name === 'quickref') drawQr();
  };
}

// ---------- collections ----------
export function collectionPicker(item) {
  const m = modal(`<h3>Add to a collection</h3><p class="muted">${esc(item.title || item.text?.slice(0, 80) || '')}</p>
    <div class="list">${S.cols.map(c => `<label class="li chk"><span><input type="checkbox" value="${c.id}" ${c.items.some(x => sameItem(x, item)) ? 'checked' : ''}> ${esc(c.name)}</span><small>${c.kind === 'study' ? 'Study list' : 'Folder'} · ${c.items.length}</small></label>`).join('') || '<p class="muted">No collections yet.</p>'}</div>
    <div class="row"><input type="text" id="cn" placeholder="New collection name" style="flex:1"><select id="ck"><option value="folder">Folder</option><option value="study">Study list</option></select><button class="btn" id="cadd">Create</button></div>
    <div class="row end"><button class="btn primary" id="cdone">Done</button></div>`);
  m.el.querySelector('#cadd').onclick = async () => { const name = m.el.querySelector('#cn').value.trim(); if (!name) return; const c = { id: uid(), name, kind: m.el.querySelector('#ck').value, items: [], createdAt: Date.now() }; S.cols.push(c); await putItem('cols', c); m.close(); collectionPicker(item); };
  m.el.querySelector('#cdone').onclick = async () => {
    for (const box of m.el.querySelectorAll('input[type=checkbox]')) {
      const c = S.cols.find(x => x.id === box.value); const has = c.items.some(x => sameItem(x, item));
      if (box.checked && !has) { c.items.push({ ...item, added: Date.now() }); await putItem('cols', c); }
      if (!box.checked && has) { c.items = c.items.filter(x => !sameItem(x, item)); await putItem('cols', c); }
    }
    m.close(); toast('Collections updated.');
  };
}
const sameItem = (a, b) => a.type === b.type && (a.type === 'topic' ? a.id === b.id : a.docId === b.docId && a.p === b.p && (a.text || '').slice(0, 60) === (b.text || '').slice(0, 60));

// ---------- bookmarks ----------
views.bookmarks = () => {
  const tab = S.bmTab || 'pages';
  const bms = S.bm.slice().sort((a, b) => b.createdAt - a.createdAt);
  let body = '';
  if (tab === 'pages') body = bms.length ? `<div class="panel" style="padding:4px 18px">${bms.map(b => `<div class="result"><div class="row between"><div><b>${esc(b.title || (b.type === 'page' ? 'Page ' + Lib.label(b.docId, b.p) : 'Passage'))}</b> <span class="label-chip">${b.type === 'page' ? 'Page' : 'Passage'}</span></div>${S.docs.has(b.docId) ? citeChip(b.docId, b.p) : '<span class="muted">Document removed</span>'}</div>${b.quote ? `<p class="snip">${esc(b.quote.slice(0, 500))}</p>` : ''}<div class="row"><small class="muted">${fmtDate(b.createdAt)}</small><button class="btn sm ghost" data-act="bm-col" data-id="${b.id}">Add to collection</button><button class="btn sm ghost danger" data-act="bm-del" data-id="${b.id}">Remove</button></div></div>`).join('')}</div>` : emptyState('No bookmarks yet', 'Use ★ in the page viewer, or select a passage and choose “Bookmark”.');
  if (tab === 'favorites') body = S.favorites.topics.length ? `<div class="panel"><div class="list">${S.favorites.topics.filter(id => Lib.topics.has(id)).map(id => `<div class="li"><a href="#topic-${id}">${esc(Lib.topics.get(id).name)}</a>${topicStatusChip(id)}</div>`).join('')}</div></div>` : emptyState('No favorite topics', 'Star a topic on its page to add it here.');
  if (tab === 'collections') body = `<div class="row" style="margin-bottom:12px"><input type="text" id="ncn" placeholder="New collection" style="max-width:300px"><select id="nck"><option value="folder">Folder</option><option value="study">Study list</option></select><button class="btn" data-act="col-new">Create</button></div>` + (S.cols.length ? `<div class="grid g2">${S.cols.map(c => `<div class="panel stack"><div class="row between"><h3>${esc(c.name)}</h3><span class="label-chip">${c.kind === 'study' ? 'Study list' : 'Folder'}</span></div>${c.items.length ? `<div class="list">${c.items.map((it, i) => `<div class="li"><span>${it.type === 'topic' ? `<a href="#topic-${it.id}">${esc(Lib.topics.get(it.id)?.name || it.title)}</a>` : `${esc((it.title || it.text || '').slice(0, 90))}`}</span><span class="row" style="gap:6px">${it.docId && S.docs.has(it.docId) ? citeChip(it.docId, it.p) : ''}<button class="btn sm ghost" data-act="col-rm" data-id="${c.id}" data-i="${i}" aria-label="Remove">×</button></span></div>`).join('')}</div>` : '<p class="muted">Empty. Use “Add to…” on topics and passages.</p>'}<div class="row"><button class="btn sm danger ghost" data-act="col-del" data-id="${c.id}">Delete collection</button></div></div>`).join('')}</div>` : emptyState('No collections', 'Create folders or study lists to group topics and passages.'));
  return `<div class="page-head"><span class="eyebrow">Bookmarks</span><h1>Bookmarks, favorites and collections</h1></div>
  <div class="tabs" id="bmtabs">${[['pages', `Pages & passages (${S.bm.length})`], ['favorites', `Favorite topics (${S.favorites.topics.length})`], ['collections', `Collections & study lists (${S.cols.length})`]].map(([k, l]) => `<button data-t="${k}" class="${tab === k ? 'on' : ''}">${l}</button>`).join('')}</div><div style="margin-top:16px">${body}</div>`;
};
views.after_bookmarks = (a, root) => root.querySelector('#bmtabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { S.bmTab = b.dataset.t; render(); } });
actions['bm-del'] = async el => { S.bm = S.bm.filter(b => b.id !== el.dataset.id); await delItem('bm', el.dataset.id); render(); };
actions['bm-col'] = el => { const b = S.bm.find(x => x.id === el.dataset.id); collectionPicker({ type: b.type === 'page' ? 'page' : 'passage', docId: b.docId, p: b.p, text: b.quote || '', title: b.title }); };
actions['col-new'] = async () => { const name = $('#ncn').value.trim(); if (!name) return; const c = { id: uid(), name, kind: $('#nck').value, items: [], createdAt: Date.now() }; S.cols.push(c); await putItem('cols', c); render(); };
actions['col-rm'] = async el => { const c = S.cols.find(x => x.id === el.dataset.id); c.items.splice(+el.dataset.i, 1); await putItem('cols', c); render(); };
actions['col-del'] = async el => { if (!await confirmBox('Delete this collection? Items in it are not deleted.')) return; S.cols = S.cols.filter(x => x.id !== el.dataset.id); await delItem('cols', el.dataset.id); render(); };

// ---------- my notes ----------
views.notes = () => {
  const F = S.noteF = S.noteF || { cat: '', doc: '', color: '', label: '', q: '' };
  return `<div class="page-head"><span class="eyebrow">My Notes</span><h1>Highlights and notes</h1><p>Every highlight stays linked to its document and page.</p></div>
  <div class="row" style="margin-bottom:12px"><input type="search" id="nf-q" placeholder="Search highlights and notes" value="${esc(F.q)}" style="flex:1;max-width:360px">
    <select id="nf-cat"><option value="">All categories</option>${Lib.taxonomy.map(c => `<option value="${c.id}" ${F.cat === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
    <select id="nf-doc"><option value="">All documents</option>${[...S.docs.values()].map(d => `<option value="${d.id}" ${F.doc === d.id ? 'selected' : ''}>${esc(Lib.shortName(d.id))}</option>`).join('')}</select>
    <select id="nf-color"><option value="">Any color</option>${HIGHLIGHT_COLORS.map(c => `<option value="${c.id}" ${F.color === c.id ? 'selected' : ''}>${c.name}</option>`).join('')}</select>
    <select id="nf-label"><option value="">Any type</option>${HIGHLIGHT_LABELS.map(l => `<option ${F.label === l ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
  <div class="row" style="margin-bottom:16px"><span class="muted" style="font-size:13px">Export the filtered list:</span><button class="btn sm" data-act="notes-export" data-f="md">Markdown</button><button class="btn sm" data-act="notes-export" data-f="json">JSON</button><button class="btn sm" data-act="notes-export" data-f="pdf">PDF</button></div>
  <div id="nlist"></div>`;
};
export function filteredNotes() {
  const F = S.noteF || {}; const q = (F.q || '').toLowerCase();
  return S.ann.filter(a => (!F.cat || a.cat === F.cat || (a.topics || []).some(t => Lib.topics.get(t)?.cat === F.cat)) && (!F.doc || a.docId === F.doc) && (!F.color || a.color === F.color) && (!F.label || a.label === F.label) && (!q || (a.quote + ' ' + (a.note || '') + ' ' + (a.label || '')).toLowerCase().includes(q)))
    .sort((a, b) => (a.docId > b.docId ? 1 : a.docId < b.docId ? -1 : 0) || a.p - b.p || a.createdAt - b.createdAt);
}
function drawNotes() {
  const box = $('#nlist'); if (!box) return; const list = filteredNotes();
  if (!S.ann.length) { box.innerHTML = emptyState('No highlights yet', 'Select text on any page, excerpt or search result and pick a color.'); return; }
  let last = null;
  box.innerHTML = `<p class="note-bar">${n(list.length)} of ${n(S.ann.length)}</p><div class="stack">` + list.map(a => { const g = a.docId !== last ? `<h3 style="margin-top:10px">${esc(Lib.docName(a.docId))}</h3>` : ''; last = a.docId; return g + `<div class="ann-card" style="--c:${colorCss(a.color)}"><div class="row between"><span class="row" style="gap:6px">${a.label ? `<span class="label-chip">${esc(a.label)}</span>` : ''}${(a.topics || []).slice(0, 2).map(t => Lib.topics.get(t) ? `<a class="chip" href="#topic-${t}">${esc(Lib.topics.get(t).name)}</a>` : '').join('')}</span>${S.docs.has(a.docId) ? citeChip(a.docId, a.p) : ''}</div><q>${esc(a.quote)}</q>${a.note ? `<div><b>Note:</b> ${esc(a.note)}</div>` : ''}<div class="row"><small class="muted">${fmtDate(a.createdAt)}</small><button class="btn sm ghost" data-act="ann-edit" data-id="${a.id}">Edit</button><button class="btn sm ghost" data-act="ann-card" data-id="${a.id}">Flashcard</button><button class="btn sm ghost danger" data-act="ann-del" data-id="${a.id}">Delete</button></div></div>`; }).join('') + '</div>';
}
views.after_notes = (a, root) => {
  const F = S.noteF;
  root.querySelector('#nf-q').addEventListener('input', e => { F.q = e.target.value; drawNotes(); });
  for (const [s, k] of [['#nf-cat', 'cat'], ['#nf-doc', 'doc'], ['#nf-color', 'color'], ['#nf-label', 'label']]) root.querySelector(s).addEventListener('change', e => { F[k] = e.target.value; drawNotes(); });
  drawNotes();
};
actions['ann-card'] = el => { const a = S.ann.find(x => x.id === el.dataset.id); openCardModal({ docId: a.docId, p: a.p, text: a.quote, front: a.note || '' }); };
actions['notes-export'] = async el => { const { exportNotes } = await import('./exporter.js'); exportNotes(filteredNotes(), el.dataset.f); };

// ---------- flashcards ----------
export function openCardModal(src) {
  const m = modal(`<h3>${src.id ? 'Edit flashcard' : 'New flashcard'}</h3>
    <label>Front (question or prompt) <textarea id="ff" placeholder="Write the question">${esc(src.front || '')}</textarea></label>
    <label>Back (verbatim from the source) <textarea id="fb" style="min-height:120px" readonly>${esc(src.back || src.text || '')}</textarea></label>
    <div>${src.docId ? citeChip(src.docId, src.p) : ''}</div>
    <label>Deck <input type="text" id="fd" value="${esc(src.deck || (src.docId ? Lib.topics.get((Lib.pageTopics[Lib.gi(src.docId, src.p)] || [])[0]?.[0])?.name || '' : ''))}" placeholder="Deck name"></label>
    <div class="row end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="fs">Save card</button></div>`);
  m.el.querySelector('#fs').onclick = async () => {
    const front = m.el.querySelector('#ff').value.trim(); if (!front) { toast('Write a question for the front.', 'bad'); return; }
    const c = src.id ? Object.assign(S.cards.find(x => x.id === src.id), { front, deck: m.el.querySelector('#fd').value.trim() }) : { id: uid(), front, back: src.back || src.text, docId: src.docId, p: src.p, deck: m.el.querySelector('#fd').value.trim() || 'General', ef: 2.5, interval: 0, reps: 0, due: Date.now(), createdAt: Date.now() };
    if (!src.id) S.cards.push(c);
    await putItem('cards', c); m.close(); toast('Flashcard saved.'); if (S.route.name === 'flashcards') render();
  };
}
views.flashcards = () => {
  const now = Date.now(); const decks = [...new Set(S.cards.map(c => c.deck || 'General'))].sort();
  const deck = S.fcDeck || ''; const cards = S.cards.filter(c => !deck || (c.deck || 'General') === deck);
  const due = cards.filter(c => (c.due || 0) <= now);
  const topicSel = S.cardTopic || '';
  return `<div class="page-head"><span class="eyebrow">Flashcards</span><h1>Flashcards and spaced repetition</h1><p>Card answers are verbatim text from your PDFs, linked to the page. Reviews are scheduled with spaced repetition (SM-2).</p></div>
  <div class="tiles" style="grid-template-columns:repeat(3,minmax(0,1fr));margin-bottom:16px"><div class="tile"><b>${n(cards.length)}</b><span>Cards${deck ? ' in ' + esc(deck) : ''}</span></div><div class="tile"><b>${n(due.length)}</b><span>Due now</span></div><div class="tile"><b>${n(cards.filter(c => !c.reps).length)}</b><span>New</span></div></div>
  <div class="row" style="margin-bottom:16px"><select id="fc-deck"><option value="">All decks</option>${decks.map(d => `<option ${d === deck ? 'selected' : ''}>${esc(d)}</option>`).join('')}</select><button class="btn primary" data-act="fc-study" ${due.length ? '' : 'disabled'}>Study ${due.length} due card${due.length === 1 ? '' : 's'}</button></div>
  <div class="panel stack" style="margin-bottom:16px"><h3>Generate cards from a topic</h3><p class="muted" style="font-size:13.5px">The assistant drafts questions from the topic's top passages. Each answer must be an exact quote from the page; drafts whose quote can't be found in the source are discarded. You choose which to keep.</p>
    <div class="row"><select id="fc-topic" style="max-width:360px"><option value="">Choose a topic</option>${Lib.allTopics().filter(t => (Lib.topicPages.get(t.id) || []).length).map(t => `<option value="${t.id}" ${topicSel === t.id ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select><button class="btn" data-act="fc-gen">Draft cards</button></div><div id="fc-drafts"></div></div>
  <div class="panel"><h3>All cards</h3>${cards.length ? `<div class="list">${cards.sort((a, b) => (a.due || 0) - (b.due || 0)).map(c => `<div class="li"><div style="min-width:0"><div class="t">${esc(c.front)}</div><small>${esc(c.deck || 'General')} · ${(c.due || 0) <= now ? 'due now' : 'due ' + fmtDate(c.due)}${c.reps ? ` · ${c.reps} reviews` : ' · new'}</small></div><span class="row" style="gap:4px">${c.docId && S.docs.has(c.docId) ? citeChip(c.docId, c.p) : ''}<button class="btn sm ghost" data-act="fc-edit" data-id="${c.id}">Edit</button><button class="btn sm ghost danger" data-act="fc-del" data-id="${c.id}">Delete</button></span></div>`).join('')}</div>` : '<p class="muted">No cards yet. Select a passage anywhere and choose “Flashcard”.</p>'}</div>`;
};
views.after_flashcards = (a, root) => { root.querySelector('#fc-deck').addEventListener('change', e => { S.fcDeck = e.target.value; render(); }); root.querySelector('#fc-topic').addEventListener('change', e => { S.cardTopic = e.target.value; }); };
actions['fc-edit'] = el => { const c = S.cards.find(x => x.id === el.dataset.id); openCardModal({ ...c }); };
actions['fc-del'] = async el => { if (!await confirmBox('Delete this card?')) return; S.cards = S.cards.filter(x => x.id !== el.dataset.id); await delItem('cards', el.dataset.id); render(); };
export function sm2(c, q) { // q: 0 again, 3 hard, 4 good, 5 easy
  const day = 86400000;
  if (q < 3) { c.reps = 0; c.interval = 0; c.due = Date.now() + 10 * 60000; }
  else {
    c.reps = (c.reps || 0) + 1;
    if (c.reps === 1) c.interval = q === 3 ? 1 : (q === 5 ? 3 : 1);
    else if (c.reps === 2) c.interval = q === 3 ? 3 : 6;
    else c.interval = Math.round((c.interval || 1) * (q === 3 ? 1.2 : c.ef) * (q === 5 ? 1.3 : 1));
    c.due = Date.now() + c.interval * day;
  }
  c.ef = Math.max(1.3, (c.ef || 2.5) + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)));
  c.lastReview = Date.now(); return c;
}
actions['fc-study'] = () => {
  const deck = S.fcDeck || ''; const queue = S.cards.filter(c => (!deck || (c.deck || 'General') === deck) && (c.due || 0) <= Date.now()).sort(() => Math.random() - 0.5);
  if (!queue.length) return; let i = 0; let shown = false;
  const m = modal('<div id="fcs"></div>', { wide: true, onClose: () => render() });
  const draw = () => {
    const c = queue[i]; const box = m.el.querySelector('#fcs');
    if (!c) { box.innerHTML = `<div class="fc"><div class="face"><div class="q">Session complete</div><p class="muted">${queue.length} card${queue.length > 1 ? 's' : ''} reviewed.</p></div><div class="row end"><button class="btn primary" data-close>Close</button></div></div>`; return; }
    box.innerHTML = `<div class="fc"><div class="row between"><span class="muted tnum">${i + 1} / ${queue.length}</span><span class="label-chip">${esc(c.deck || 'General')}</span></div>
      <div class="face"><div class="q">${esc(c.front)}</div>${shown ? `<div class="a" style="border-top:1px solid var(--line);padding-top:12px">${esc(c.back)}</div>${c.docId && S.docs.has(c.docId) ? `<div>${citeChip(c.docId, c.p)}</div>` : ''}` : ''}</div>
      ${shown ? `<div class="grades"><button class="btn" data-g="0">Again</button><button class="btn" data-g="3">Hard</button><button class="btn primary" data-g="4">Good</button><button class="btn" data-g="5">Easy</button></div>` : '<button class="btn primary" id="reveal">Show answer</button>'}</div>`;
    box.querySelector('#reveal')?.addEventListener('click', () => { shown = true; draw(); });
    box.querySelectorAll('[data-g]').forEach(b => b.addEventListener('click', async () => { sm2(c, +b.dataset.g); await putItem('cards', c); i++; shown = false; draw(); }));
  };
  draw();
};

// ---------- compare ----------
const ASPECTS = ['definition', 'classification', 'presentation', 'radiology', 'management', 'indications', 'techniques', 'complications', 'followup'];
views.compare = () => {
  const C = S.cmp = S.cmp || { mode: 'refs', q: '', a: '', b: '', aspects: ['definition', 'classification', 'indications', 'techniques', 'complications', 'management'], docs: [] };
  if (S.compareTopic) { C.mode = 'refs'; C.q = Lib.topics.get(S.compareTopic)?.name || ''; C.topic = S.compareTopic; S.compareTopic = null; }
  const docs = [...S.docs.values()];
  return `<div class="page-head"><span class="eyebrow">Compare references</span><h1>Compare and cross-reference</h1><p>Build a table of verbatim passages side by side, one column per reference or per item, with page citations in every cell. The assistant can then summarize agreements and differences, citing those same passages.</p></div>
  <div class="panel stack">
    <div class="seg" id="cmode"><button data-m="refs" class="${C.mode === 'refs' ? 'on' : ''}">One topic across references</button><button data-m="items" class="${C.mode === 'items' ? 'on' : ''}">Two techniques, classifications or approaches</button></div>
    ${C.mode === 'refs' ? `<div class="row"><input type="text" id="cq" placeholder="Topic or question, e.g. vestibular schwannoma" value="${esc(C.q)}" style="flex:1"><select id="ctopic"><option value="">…or pick a topic</option>${Lib.allTopics().filter(t => (Lib.topicPages.get(t.id) || []).length).map(t => `<option value="${t.id}" ${C.topic === t.id ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select></div>
      ${docs.length ? `<div class="chips" id="cdocs">${docs.map(d => `<button class="chip ${!C.docs.length || C.docs.includes(d.id) ? 'on' : ''}" data-doc="${d.id}">${esc(Lib.shortName(d.id))}</button>`).join('')}</div>` : ''}` :
      `<div class="row"><input type="text" id="ca" placeholder="First item, e.g. ACDF" value="${esc(C.a)}" style="flex:1"><span class="muted">vs</span><input type="text" id="cb" placeholder="Second item, e.g. cervical arthroplasty" value="${esc(C.b)}" style="flex:1"></div>`}
    <div class="chips" id="caspects">${ASPECTS.map(id => `<button class="chip ${C.aspects.includes(id) ? 'on' : ''}" data-a="${id}">${SECTIONS.find(s => s.id === id).name}</button>`).join('')}</div>
    <div class="row"><button class="btn primary" data-act="cmp-run">Build comparison</button><button class="btn" data-act="cmp-ai">Summarize agreements and differences</button></div>
  </div>
  <div id="cmpout" style="margin-top:16px"></div>`;
};
views.after_compare = (a, root) => {
  const C = S.cmp;
  root.querySelector('#cmode').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { C.mode = b.dataset.m; render(); } });
  root.querySelector('#cq')?.addEventListener('input', e => { C.q = e.target.value; C.topic = ''; });
  root.querySelector('#ctopic')?.addEventListener('change', e => { C.topic = e.target.value; if (C.topic) { C.q = Lib.topics.get(C.topic).name; root.querySelector('#cq').value = C.q; } });
  root.querySelector('#ca')?.addEventListener('input', e => { C.a = e.target.value; });
  root.querySelector('#cb')?.addEventListener('input', e => { C.b = e.target.value; });
  root.querySelector('#cdocs')?.addEventListener('click', e => { const b = e.target.closest('[data-doc]'); if (!b) return; const all = [...S.docs.keys()]; if (!C.docs.length) C.docs = all.slice(); const i = C.docs.indexOf(b.dataset.doc); if (i >= 0) C.docs.splice(i, 1); else C.docs.push(b.dataset.doc); b.classList.toggle('on'); });
  root.querySelector('#caspects').addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (!b) return; const i = C.aspects.indexOf(b.dataset.a); if (i >= 0) C.aspects.splice(i, 1); else C.aspects.push(b.dataset.a); b.classList.toggle('on'); });
  if (C.lastTable) $('#cmpout').innerHTML = C.lastTable;
};
// Pick the best verbatim passage for (query, aspect) restricted to one document.
export function bestPassages(query, aspectId, docs, k = 2) {
  const sec = SECTIONS.find(s => s.id === aspectId);
  const r = Lib.search(query, { docs, abbr: true }); const hl = Lib.highlightSet(r.info);
  const cands = [];
  for (const res of r.results.filter(x => !isSkipPage(x.gi)).slice(0, 25)) for (const pa of Lib.passages(res.gi)) {
    const ts = tokenize(pa.text); let hit = 0; for (const w of ts) if (hl.terms.has(w)) hit++;
    for (const ph of hl.phrases) if ((' ' + ts.join(' ') + ' ').includes(' ' + ph.join(' ') + ' ')) hit += 3;
    if (!hit) continue;
    let s = Math.min(hit, 6) * 0.5 + res.score * 0.05;
    if (pa.head && sec.head.test(pa.head)) s += 4;
    const g = new RegExp(sec.cue.source, 'gi'); let c = 0; while (g.exec(pa.text) && c < 4) c++; s += c;
    if (c || (pa.head && sec.head.test(pa.head))) cands.push({ ...pa, score: s });
  }
  return { items: cands.sort((a, b) => b.score - a.score).slice(0, k), hl };
}
actions['cmp-run'] = () => {
  const C = S.cmp; const cols = [];
  if (C.mode === 'refs') { if (!C.q.trim()) { toast('Enter a topic or question.', 'bad'); return; } const ds = C.docs.length ? C.docs : [...S.docs.keys()]; for (const d of ds) cols.push({ id: d, name: Lib.docName(d), query: C.q, docs: [d] }); }
  else { if (!C.a.trim() || !C.b.trim()) { toast('Enter both items.', 'bad'); return; } cols.push({ id: 'a', name: C.a, query: C.a, docs: [] }, { id: 'b', name: C.b, query: C.b, docs: [] }); }
  const rows = C.aspects.map(aid => ({ aid, name: SECTIONS.find(s => s.id === aid).name, cells: cols.map(col => bestPassages(col.query, aid, col.docs, 1)) }));
  C.cols = cols; C.rows = rows;
  const html = `<div class="panel flush tablewrap"><table class="cmp"><thead><tr><th style="width:150px">Aspect</th>${cols.map(c => `<th>${esc(c.name)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr><th>${esc(r.name)}</th>${r.cells.map(cell => `<td>${cell.items.length ? cell.items.map(pa => `<div class="x" data-src-doc="${pa.docId}" data-src-p="${pa.p}">${Lib.markHtml(pa.text.slice(0, 520), cell.hl)}${pa.text.length > 520 ? '…' : ''}</div><div style="margin-top:6px">${citeChip(pa.docId, pa.p)}</div>`).join('') : '<span class="muted">Information not found in this source.</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div id="cmpai" style="margin-top:16px"></div>`;
  C.lastTable = html; $('#cmpout').innerHTML = html;
};
