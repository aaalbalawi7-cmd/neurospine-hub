// In-memory library: page index, full-text search engine, topic classification,
// passage extraction and quick-reference mining. Everything here is derived from
// the text of the uploaded PDFs only.
import { DEFAULT_TAXONOMY, SECTIONS, ABBREVIATIONS, FOCUS, QUICKREF, IMAGE_KINDS, OUTLINE_SKIP } from './taxonomy.js';

// ---------- tokenization ----------
const UK = [[/aem/g, 'em'], [/^oe(d|s)/, 'e$1'], [/paed/g, 'ped'], [/^aetio/, 'etio'], [/anaesth/g, 'anesth'], [/^foet/, 'fet'], [/(tum|hum|col|behavi|neighb|lab)our/g, '$1or'], [/(cent|lit|fib)re$/, '$1er'], [/isation/g, 'ization'], [/sulph/g, 'sulf'], [/^grey/, 'gray'], [/leucocyt/g, 'leukocyt']];
const STOP = new Set('the of and in a an to for with on by is are from at as or be what which how does do was were this that these those it its into than then vs versus about between'.split(' '));
export function normTok(w) {
  w = w.replace(/['’]s$/, '').replace(/['’]/g, '');
  if (w.length > 3 && /[a-z]/.test(w)) {
    for (const [re, r] of UK) if (re.test(w)) w = w.replace(re, r);
    if (w === 'metastases') return 'metastasis';
    if (w.length > 4) {
      if (/oses$/.test(w)) return w.slice(0, -2) + 'is';
      if (/ies$/.test(w)) return w.slice(0, -3) + 'y';
      if (/ae$/.test(w) && w.length > 5) return w.slice(0, -1);
      if (/(sses|xes|ches|shes)$/.test(w)) return w.slice(0, -2);
      if (/(ss|us|is|os|as|ys)$/.test(w)) return w;
      if (w.endsWith('s')) return w.slice(0, -1);
    }
  }
  return w;
}
const TOK_RE = /[a-z0-9]+(?:['’][a-z]+)?/g;
export function tokenize(text) {
  const out = []; const s = text.toLowerCase();
  TOK_RE.lastIndex = 0; let m;
  while ((m = TOK_RE.exec(s))) out.push(normTok(m[0]));
  return out;
}
function tokSpans(text) { // [start, end, norm]
  const out = []; const s = text.toLowerCase(); const re = /[a-z0-9]+(?:['’][a-z]+)?/g; let m;
  while ((m = re.exec(s))) out.push([m.index, m.index + m[0].length, normTok(m[0])]);
  return out;
}
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const countIn = (hay, needle) => { let n = 0, i = 0; while ((i = hay.indexOf(needle, i)) !== -1) { n++; i += needle.length - 1; } return n; };
const reCount = (re, s) => { const g = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g'); let n = 0; while (g.exec(s)) { n++; if (n > 8) break; } return n; };

function levenshtein(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]; let best = i;
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (cur[j] < best) best = cur[j];
    }
    if (best > max) return max + 1;
    prev = cur;
  }
  return prev[b.length];
}

const parseKw = (k) => { const m = /^(.*?):(\d+(?:\.\d+)?)$/.exec(k); const term = m ? m[1] : k; const toks = tokenize(term); return { term, toks, str: ' ' + toks.join(' ') + ' ', w: m ? +m[2] : (toks.length > 1 ? 2 : 1) }; };

const SKIP_SECTION = /^(front ?matter|cover|title( page)?|half title|copyright|contents|table of contents|brief contents|preface|forewords?|acknowledg|dedication|contributors|index|subject index|back ?matter|abbreviations( and symbols)?|conventions|videos?|about the (authors?|editors?))\b/i;
function isListing(t) {
  const lines = (t || '').split('\n').filter(l => l.trim()); if (lines.length < 4) return false;
  let k = 0; for (const l of lines) if (/[A-Za-z].*[\s,.]\d{1,4}(\s*[-–]\s*\d{1,4})?(,\s*\d{1,4})*\s*$/.test(l)) k++;
  return k / lines.length >= (lines.length < 15 ? 0.7 : 0.55);
}
export const isSkipPage = (gi) => { const d = Lib.docs.get(Lib.gDoc[gi]); return !!d?.skip?.[Lib.gPage[gi]]; };

// ---------- the library ----------
export const Lib = {
  docs: new Map(),      // id -> { meta, pack, base, n, sectionOf, ranges }
  order: [],            // doc ids in index order
  text: [], tokStr: [], len: [], gDoc: [], gPage: [],
  post: new Map(), vocab: [], df: null, avgLen: 1,
  taxonomy: DEFAULT_TAXONOMY, topics: new Map(), // id -> topic {id,name,cat,kw,...}
  topicPages: new Map(), pageTopics: [], topicSections: new Map(), suggestions: [],
  qref: [], figures: [], ready: false, version: 0,

  get pageCount() { return this.text.length; },
  gi(docId, p) { const d = this.docs.get(docId); return d ? d.base + p : -1; },
  loc(gi) { const d = this.docs.get(this.gDoc[gi]); return { docId: this.gDoc[gi], p: this.gPage[gi], doc: d }; },
  label(docId, p) { const d = this.docs.get(docId); const l = d?.pack?.labels?.[p]; return l || String(p + 1); },
  hasLabel(docId, p) { return !!this.docs.get(docId)?.pack?.labels?.[p]; },
  docName(docId) { const d = this.docs.get(docId); return d ? (d.meta.title || d.meta.name) : 'Unknown document'; },
  shortName(docId) { const n = this.docName(docId); return n.length > 38 ? n.slice(0, 36) + '…' : n; },
  cite(docId, p) { return `${this.docName(docId)}, ${this.pageRef(docId, p)}`; },
  pageRef(docId, p) { if (!this.hasLabel(docId, p)) return `PDF p. ${p + 1}`; const l = this.label(docId, p); return l === String(p + 1) ? `p. ${l}` : `p. ${l} (PDF p. ${p + 1})`; },

  reset() {
    this.docs.clear(); this.order = []; this.text = []; this.tokStr = []; this.len = []; this.gDoc = []; this.gPage = [];
    this.post = new Map(); this.vocab = []; this.ready = false;
  },

  // Add one document's pages to the index.
  async addDoc(meta, pack, yieldEvery = 60) {
    if (this.docs.has(meta.id)) this.removeDoc(meta.id, true);
    const base = this.text.length; const n = pack.pages.length;
    const ocr = meta.ocr || {};
    for (let p = 0; p < n; p++) {
      const gi = base + p;
      const t = (pack.pages[p] || '') + (ocr[p] ? '\n[OCR transcription of the page image]\n' + ocr[p] : '');
      this.text[gi] = t; this.gDoc[gi] = meta.id; this.gPage[gi] = p;
      const toks = tokenize(t.replace(/([a-z])-\n([a-z])/g, '$1$2'));
      this.len[gi] = toks.length; this.tokStr[gi] = ' ' + toks.join(' ') + ' ';
      const tf = new Map(); for (const k of toks) tf.set(k, (tf.get(k) || 0) + 1);
      for (const [k, f] of tf) { let pl = this.post.get(k); if (!pl) { pl = { p: [], f: [] }; this.post.set(k, pl); } pl.p.push(gi); pl.f.push(f); }
      if (p % yieldEvery === yieldEvery - 1) await new Promise(r => setTimeout(r, 0));
    }
    const doc = { meta, pack, base, n };
    this.buildSections(doc);
    doc.skip = new Uint8Array(n);
    for (const r of doc.ranges) if (SKIP_SECTION.test(r.t)) for (let p = r.p; p <= r.end && p < n; p++) doc.skip[p] = 1;
    for (let p = 0; p < n; p++) if (!doc.skip[p] && isListing(this.text[base + p])) doc.skip[p] = 1;
    this.docs.set(meta.id, doc); this.order.push(meta.id);
  },

  removeDoc(id, silent) {
    // Rebuild without that doc (simple and safe).
    const keep = this.order.filter(x => x !== id).map(x => this.docs.get(x));
    this.reset();
    return (async () => { for (const d of keep) await this.addDoc(d.meta, d.pack); if (!silent) this.finalize(); })();
  },

  // Bookmarks titled only with a chapter number get the chapter title from the page's headings.
  fixOutlineTitles(pack) {
    const heads = pack.heads || {};
    const author = l => /,\s*[A-Z][a-z]+\s+[A-Z]/.test(l) || /\band$/.test(l) || /^[A-Z][a-z]+ [A-Z][a-z]+(,| and )/.test(l) || /\b[A-Z][a-z]+ (?:[A-Z]\.\s?)+[A-Z][a-z]+/.test(l) || /^[A-Z][a-z]+ [A-Z]{1,3} [A-Z][a-z]+/.test(l);
    pack.outline = (pack.outline || []).map(e => {
      if (!/^\d{1,3}$/.test(e.t) || e.p < 0) return e;
      const hs = heads[e.p] || []; let k = hs.findIndex(h => h[1].startsWith(e.t + ' ')); let t;
      if (k >= 0) { t = hs[k][1]; for (let j = k + 1; j < hs.length && hs[j][0] === hs[j - 1][0] + 1 && t.length < 110; j++) { const l = hs[j][1]; if (/^\d/.test(l) || l.length > 60 || author(l)) break; t += ' ' + l; } }
      else if (hs[0] && hs[0][1].length < 60 && !author(hs[0][1])) t = e.t + ' ' + hs[0][1];
      return t ? { ...e, t } : e;
    });
  },

  buildSections(doc) {
    if (!doc.pack._fixed) { this.fixOutlineTitles(doc.pack); doc.pack._fixed = true; }
    const ol = doc.pack.outline || []; const n = doc.n;
    const ranges = ol.map((e, i) => {
      let end = n - 1;
      for (let j = i + 1; j < ol.length; j++) if (ol[j].l <= e.l && ol[j].p >= 0) { end = Math.max(e.p, ol[j].p - (ol[j].p > e.p ? 1 : 0)); break; }
      return { ...e, i, end };
    }).filter(r => r.p >= 0);
    const sectionOf = new Int32Array(n).fill(-1);
    for (const r of ranges) for (let p = r.p; p <= r.end && p < n; p++) sectionOf[p] = r.i; // deeper entries come later and overwrite
    doc.ranges = ranges; doc.sectionOf = sectionOf;
  },

  breadcrumb(docId, p) {
    const d = this.docs.get(docId); if (!d || !d.sectionOf) return [];
    const ol = d.pack.outline || []; let i = d.sectionOf[p]; if (i < 0) return [];
    const path = [ol[i].t]; let lvl = ol[i].l;
    for (let j = i - 1; j >= 0 && lvl > 0; j--) if (ol[j].l < lvl) { path.unshift(ol[j].t); lvl = ol[j].l; }
    return path.filter(t => t && !/^\d+$/.test(t) && !/^\S*\d{5,}\S*$/.test(t));
  },

  finalize() {
    let tot = 0; for (const l of this.len) tot += l; this.avgLen = Math.max(1, tot / Math.max(1, this.len.length));
    this.vocab = [...this.post.keys()].sort();
    this.classify();
    this.mineQuickRef();
    this.mineFigures();
    this.ready = true; this.version++;
  },

  // ---------- taxonomy ----------
  setTaxonomy(tax) { this.taxonomy = tax || DEFAULT_TAXONOMY; },
  allTopics() {
    const out = [];
    for (const c of this.taxonomy) for (const s of c.subs) if (!s.alias) out.push({ ...s, cat: c.id, catName: c.name });
    return out;
  },
  topic(id) { return this.topics.get(id); },
  categoryOf(topicId) { return this.topics.get(topicId)?.cat; },

  classify() {
    const N = this.pageCount; this.topics.clear(); this.topicPages.clear(); this.topicSections.clear();
    const scores = new Map();
    const tlist = this.allTopics();
    for (const t of tlist) { t.kwc = (t.kw || []).map(parseKw).filter(k => k.toks.length); this.topics.set(t.id, t); }
    for (const t of tlist) {
      const sc = new Float32Array(N);
      for (const k of t.kwc) {
        const pls = k.toks.map(x => this.post.get(x)); if (pls.some(x => !x)) continue;
        if (pls.length === 1) { const pl = pls[0]; for (let j = 0; j < pl.p.length; j++) sc[pl.p[j]] += k.w * (1 + Math.log(pl.f[j])); continue; }
        pls.sort((a, b) => a.p.length - b.p.length);
        const cand = pls[0].p; const others = pls.slice(1).map(pl => new Set(pl.p));
        for (const gi of cand) {
          if (!others.every(s => s.has(gi))) continue;
          const c = countIn(this.tokStr[gi], k.str);
          if (c) sc[gi] += k.w * (1 + Math.log(c));
        }
      }
      // length normalization
      for (let gi = 0; gi < N; gi++) if (sc[gi]) sc[gi] /= (0.6 + 0.4 * this.len[gi] / this.avgLen);
      scores.set(t.id, sc);
    }
    // outline sections and headings carry strong signal
    const titleScore = (title) => {
      const ts = ' ' + tokenize(title).join(' ') + ' '; const res = [];
      for (const t of tlist) { let s = 0; for (const k of t.kwc) if (ts.includes(k.str)) s += k.w; if (s > 0) res.push([t.id, s]); }
      return res;
    };
    for (const id of this.order) {
      const d = this.docs.get(id);
      d.titleHits = [];
      for (const r of d.ranges) {
        const span = r.end - r.p + 1; const hits = titleScore(r.t);
        for (const [tid, s] of hits) {
          if (s >= 1.5) d.titleHits.push({ topic: tid, r, s });
          const add = (span <= 90 ? 6 : 1.5) * Math.min(s, 4);
          const sc = scores.get(tid);
          for (let p = r.p; p <= r.end && p < d.n; p++) sc[d.base + p] += add;
        }
      }
      const heads = d.pack.heads || {};
      for (const p in heads) for (const [, h] of heads[p]) for (const [tid, s] of titleScore(h)) scores.get(tid)[d.base + (+p)] += 2.5 * Math.min(s, 4);
    }
    // custom anchors (accepted suggestions)
    for (const t of tlist) for (const a of (t.anchors || [])) { const d = this.docs.get(a.docId); if (!d) continue; const sc = scores.get(t.id); for (let p = a.p0; p <= a.p1 && p < d.n; p++) sc[d.base + p] += 12; }
    // front matter, contents, index and other listing pages are never assigned to topics
    for (const id of this.order) { const d = this.docs.get(id); for (let p = 0; p < d.n; p++) if (d.skip[p]) for (const sc of scores.values()) sc[d.base + p] = 0; }
    // assignment
    const THRESH = 4.2;
    this.pageTopics = new Array(N);
    for (let gi = 0; gi < N; gi++) {
      const best = [];
      for (const t of tlist) { const s = scores.get(t.id)[gi]; if (s >= THRESH) best.push([t.id, s]); }
      best.sort((a, b) => b[1] - a[1]); this.pageTopics[gi] = best.slice(0, 5);
    }
    for (const t of tlist) {
      const sc = scores.get(t.id); const arr = [];
      for (let gi = 0; gi < N; gi++) if (sc[gi] >= THRESH) arr.push([gi, sc[gi]]);
      arr.sort((a, b) => b[1] - a[1]); this.topicPages.set(t.id, arr);
      const secs = [];
      for (const id of this.order) for (const h of this.docs.get(id).titleHits) if (h.topic === t.id) secs.push({ docId: id, t: h.r.t, p: h.r.p, end: h.r.end, l: h.r.l, s: h.s });
      secs.sort((a, b) => b.s - a.s || a.l - b.l);
      this.topicSections.set(t.id, secs);
    }
    this.scores = scores;
    this.buildSuggestions(titleScore);
  },

  buildSuggestions(titleScore) {
    const seen = new Map();
    for (const id of this.order) {
      const d = this.docs.get(id);
      for (const r of d.ranges) {
        if (r.l > 2) continue;
        const title = r.t.replace(/^(chapter|section)\s+\d+[:.]?\s*/i, '').replace(/^\d+(\.\d+)*\s*[:.]?\s*/, '').trim();
        if (title.length < 4 || title.length > 90 || OUTLINE_SKIP.test(title)) continue;
        const span = r.end - r.p + 1; if (span < 2 || span > 150) continue;
        const hits = titleScore(title); if (hits.some(([, s]) => s >= 1.5)) continue;
        // category by aggregated page scores
        const catScore = new Map();
        for (let p = r.p; p <= r.end; p++) for (const [tid, s] of this.pageTopics[d.base + p] || []) { const c = this.topics.get(tid)?.cat; catScore.set(c, (catScore.get(c) || 0) + s); }
        const cat = [...catScore.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
        const key = tokenize(title).join(' ');
        const s = seen.get(key) || { title, key, cat, sources: [] };
        s.sources.push({ docId: id, p0: r.p, p1: r.end });
        if (!s.cat) s.cat = cat;
        seen.set(key, s);
      }
    }
    this.suggestions = [...seen.values()];
  },

  // ---------- search ----------
  parse(q) {
    const toks = []; const re = /\s*(\(|\)|"[^"]*"?|[^\s()"]+)/g; let m;
    while ((m = re.exec(q))) toks.push(m[1]);
    let i = 0;
    const peek = () => toks[i];
    const isOp = (t, op) => t === op || (op === 'OR' && t === '|') || (op === 'AND' && t === '&&');
    const parseOr = () => { const kids = [parseAnd()]; while (i < toks.length && isOp(peek(), 'OR')) { i++; kids.push(parseAnd()); } return kids.length > 1 ? { op: 'or', kids } : kids[0]; };
    const parseAnd = () => {
      const kids = [];
      while (i < toks.length && peek() !== ')' && !isOp(peek(), 'OR')) {
        if (isOp(peek(), 'AND')) { i++; continue; }
        const n = parseNot(); if (n) kids.push(n);
      }
      return kids.length === 1 ? kids[0] : { op: 'and', kids };
    };
    const parseNot = () => {
      const t = peek();
      if (t === 'NOT') { i++; const k = parseNot(); return k ? { op: 'not', kid: k } : null; }
      if (t && t.length > 1 && t[0] === '-' ) { toks[i] = t.slice(1); const k = parsePrim(); return k ? { op: 'not', kid: k } : null; }
      return parsePrim();
    };
    const parsePrim = () => {
      const t = toks[i++];
      if (t === undefined) return null;
      if (t === '(') { const e = parseOr(); if (peek() === ')') i++; return e; }
      if (t[0] === '"') { const words = tokenize(t.replace(/"/g, '')); return words.length ? (words.length === 1 ? { op: 'term', w: words[0], raw: t.replace(/"/g, '') } : { op: 'phrase', toks: words, raw: t.replace(/"/g, '') }) : null; }
      const prefix = t.endsWith('*'); const fuzzy = t.endsWith('~');
      const clean = t.replace(/[*~]+$/, '');
      const words = tokenize(clean);
      if (!words.length) return null;
      if (words.length > 1) return { op: 'phrase', toks: words, raw: clean, loose: true };
      if (!prefix && STOP.has(clean.toLowerCase()) && !/^(AND|OR|NOT)$/.test(t)) return null;
      return { op: 'term', w: prefix ? clean.toLowerCase() : words[0], raw: clean, prefix, fuzzy };
    };
    const ast = parseOr();
    return ast;
  },

  termPages(w) { const pl = this.post.get(w); return pl ? pl.p : []; },
  prefixTerms(pre, max = 60) {
    let lo = 0, hi = this.vocab.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (this.vocab[m] < pre) lo = m + 1; else hi = m; }
    const out = [];
    for (let j = lo; j < this.vocab.length && this.vocab[j].startsWith(pre) && out.length < 4000; j++) out.push(this.vocab[j]);
    out.sort((a, b) => this.post.get(b).p.length - this.post.get(a).p.length);
    return out.slice(0, max);
  },
  fuzzyTerms(w, max = 5) {
    if (w.length < 4 || /^\d+$/.test(w)) return [];
    const d = w.length >= 8 ? 2 : 1; const out = [];
    for (const v of this.vocab) {
      if (v === w || Math.abs(v.length - w.length) > d || v[0] !== w[0]) continue;
      const dist = levenshtein(w, v, d); if (dist <= d) out.push([v, dist, this.post.get(v).p.length]);
    }
    out.sort((a, b) => a[1] - b[1] || b[2] - a[2]);
    return out.slice(0, max).map(x => x[0]);
  },

  // Expand a leaf into page set + scoring units.
  evalNode(node, opts, info, positive = true) {
    if (!node) return null;
    if (node.op === 'and') {
      const pos = node.kids.filter(k => k.op !== 'not'); const neg = node.kids.filter(k => k.op === 'not');
      let set = null;
      for (const k of pos) { const s = this.evalNode(k, opts, info, positive); if (s === null) continue; set = set === null ? s : new Set([...set].filter(x => s.has(x))); }
      if (set === null) set = new Set(this.allPages());
      for (const k of neg) { const s = this.evalNode(k.kid, opts, info, !positive); if (s) for (const x of s) set.delete(x); }
      return set;
    }
    if (node.op === 'or') { const set = new Set(); for (const k of node.kids) { const s = this.evalNode(k, opts, info, positive); if (s) for (const x of s) set.add(x); } return set; }
    if (node.op === 'not') { const all = new Set(this.allPages()); const s = this.evalNode(node.kid, opts, info, !positive); if (s) for (const x of s) all.delete(x); return all; }
    if (node.op === 'phrase') return this.evalPhrase(node.toks, info, positive, node.loose ? node.raw : null, opts);
    if (node.op === 'term') {
      let variants = [node.w];
      if (node.prefix) variants = this.prefixTerms(node.w);
      const set = new Set();
      for (const v of variants) for (const gi of this.termPages(v)) set.add(gi);
      if ((node.fuzzy || opts.fuzzy || (!set.size && !node.prefix)) && !node.prefix) {
        const fz = this.fuzzyTerms(node.w);
        if (fz.length) { if (!set.size) info.corrected.push([node.raw, fz[0]]); for (const v of fz) { variants.push(v); for (const gi of this.termPages(v)) set.add(gi); } }
      }
      const ab = opts.abbr !== false ? (ABBREVIATIONS[node.raw.toLowerCase()] || ABBREVIATIONS[node.w]) : null;
      if (ab) { const s = this.evalPhrase(tokenize(ab), info, positive, null, opts); for (const x of s) set.add(x); info.expanded.push([node.raw, ab]); }
      if (positive) info.units.push({ terms: variants, w: 1 });
      return set;
    }
    return null;
  },
  evalPhrase(toks, info, positive, looseRaw, opts) {
    const str = ' ' + toks.join(' ') + ' ';
    const pls = toks.map(t => this.post.get(t));
    const set = new Set();
    if (!pls.some(x => !x)) {
      const sorted = [...pls].sort((a, b) => a.p.length - b.p.length);
      const others = sorted.slice(1).map(pl => new Set(pl.p));
      for (const gi of sorted[0].p) if (others.every(s => s.has(gi)) && this.tokStr[gi].includes(str)) set.add(gi);
    }
    // loose (unquoted multi-token like "c1-c2"): also accept pages having all tokens
    if (looseRaw && !set.size && !pls.some(x => !x)) {
      const sorted = [...pls].sort((a, b) => a.p.length - b.p.length); const others = sorted.slice(1).map(pl => new Set(pl.p));
      for (const gi of sorted[0].p) if (others.every(s => s.has(gi))) set.add(gi);
    }
    // reverse abbreviation: phrase -> abbreviation
    if (opts?.abbr !== false) { const key = toks.join(' '); for (const [a, full] of Object.entries(ABBREVIATIONS)) if (tokenize(full).join(' ') === key) { for (const gi of this.termPages(a)) set.add(gi); if (positive) info.units.push({ terms: [a], w: 0.8 }); break; } }
    if (positive) info.units.push({ phrase: toks, str, w: 1.6 });
    return set;
  },
  allPages() { return Array.from({ length: this.pageCount }, (_, i) => i); },

  search(q, opts = {}) {
    const t0 = performance.now();
    const info = { units: [], corrected: [], expanded: [] };
    const ast = this.parse(q);
    if (!ast) return { results: [], info, ms: 0, total: 0 };
    let set = this.evalNode(ast, opts, info, true) || new Set();
    // filters
    if (opts.docs?.length) { const ds = new Set(opts.docs); set = new Set([...set].filter(gi => ds.has(this.gDoc[gi]))); }
    if (opts.topic) { const tp = new Set((this.topicPages.get(opts.topic) || []).map(x => x[0])); set = new Set([...set].filter(gi => tp.has(gi))); }
    if (opts.category) { set = new Set([...set].filter(gi => (this.pageTopics[gi] || []).some(([tid]) => this.topics.get(tid)?.cat === opts.category))); }
    const focus = opts.focus && FOCUS[opts.focus];
    // scoring (BM25 over positive units)
    const N = this.pageCount; const k1 = 1.2, b = 0.75;
    const score = new Map(); for (const gi of set) score.set(gi, 0);
    for (const u of info.units) {
      if (u.terms) for (const term of u.terms) {
        const pl = this.post.get(term); if (!pl) continue;
        const idf = Math.log(1 + (N - pl.p.length + 0.5) / (pl.p.length + 0.5));
        for (let j = 0; j < pl.p.length; j++) { const gi = pl.p[j]; if (!score.has(gi)) continue; const f = pl.f[j]; score.set(gi, score.get(gi) + u.w * idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * this.len[gi] / this.avgLen))); }
      }
      if (u.phrase) {
        const df = Math.max(1, [...set].filter(gi => this.tokStr[gi].includes(u.str)).length);
        const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
        for (const gi of set) { const f = countIn(this.tokStr[gi], u.str); if (f) score.set(gi, score.get(gi) + u.w * idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * this.len[gi] / this.avgLen))); }
      }
    }
    // structural boost: query words in the page's outline section or headings
    const qwords = new Set(info.units.flatMap(u => u.terms ? [u.terms[0]] : u.phrase));
    let results = [];
    for (const [gi, s0] of score) {
      let s = s0;
      const { docId, p, doc } = this.loc(gi);
      const crumbs = this.breadcrumb(docId, p).join(' ');
      const heads = (doc.pack.heads?.[p] || []).map(h => h[1]).join(' ');
      const ht = new Set(tokenize(crumbs + ' ' + heads)); let hit = 0; for (const w of qwords) if (ht.has(w)) hit++;
      if (hit) s *= 1 + 0.25 * Math.min(hit, 3);
      if (doc.skip?.[p]) s *= 0.3;
      if (focus) { const c = reCount(focus.cue, this.text[gi]); if (!c) continue; s *= 1 + 0.15 * Math.min(c, 5); }
      results.push({ gi, docId, p, score: s });
    }
    results.sort((a, b) => b.score - a.score);
    return { results, info, total: results.length, ms: Math.round(performance.now() - t0) };
  },

  // Words to highlight for a query.
  highlightSet(info) {
    const terms = new Set(); const phrases = [];
    for (const u of info.units) { if (u.terms) u.terms.forEach(t => terms.add(t)); if (u.phrase) phrases.push(u.phrase); }
    return { terms, phrases };
  },
  snippets(gi, hl, { max = 2, width = 34 } = {}) {
    const text = this.text[gi] || ''; const spans = tokSpans(text);
    const hit = new Uint8Array(spans.length);
    for (let i = 0; i < spans.length; i++) if (hl.terms.has(spans[i][2])) hit[i] = 1;
    for (const ph of hl.phrases) for (let i = 0; i + ph.length <= spans.length; i++) { let ok = true; for (let k = 0; k < ph.length; k++) if (spans[i + k][2] !== ph[k]) { ok = false; break; } if (ok) for (let k = 0; k < ph.length; k++) hit[i + k] = 1; }
    const wins = [];
    const used = new Uint8Array(spans.length);
    for (let r = 0; r < max; r++) {
      let best = -1, bestScore = 0;
      for (let i = 0; i < spans.length; i++) {
        if (!hit[i] || used[i]) continue;
        const distinct = new Set(); for (let k = i; k < Math.min(spans.length, i + width); k++) if (hit[k]) distinct.add(spans[k][2]);
        const sc = distinct.size * 3 + [...Array(Math.min(width, spans.length - i)).keys()].reduce((a, k) => a + hit[i + k], 0);
        if (sc > bestScore) { bestScore = sc; best = i; }
      }
      if (best < 0) break;
      const s = Math.max(0, best - 10), e = Math.min(spans.length - 1, best + width);
      for (let k = s; k <= e; k++) used[k] = 1;
      wins.push([s, e]);
    }
    if (!wins.length) { const t = text.slice(0, 260).replace(/\s+/g, ' '); return [esc(t) + (text.length > 260 ? '…' : '')]; }
    return wins.sort((a, b) => a[0] - b[0]).map(([s, e]) => {
      const start = spans[s][0], end = spans[e][1]; let out = ''; let pos = start;
      for (let k = s; k <= e; k++) if (hit[k]) { out += esc(text.slice(pos, spans[k][0])) + '<mark>' + esc(text.slice(spans[k][0], spans[k][1])) + '</mark>'; pos = spans[k][1]; }
      out += esc(text.slice(pos, end));
      return (start > 0 ? '…' : '') + out.replace(/\n/g, ' ') + (end < text.length ? '…' : '');
    });
  },
  markHtml(text, hl) { // whole text with marks
    const spans = tokSpans(text); let out = ''; let pos = 0;
    const hit = new Uint8Array(spans.length);
    for (let i = 0; i < spans.length; i++) if (hl.terms.has(spans[i][2])) hit[i] = 1;
    for (const ph of hl.phrases) for (let i = 0; i + ph.length <= spans.length; i++) { let ok = true; for (let k = 0; k < ph.length; k++) if (spans[i + k][2] !== ph[k]) { ok = false; break; } if (ok) for (let k = 0; k < ph.length; k++) hit[i + k] = 1; }
    for (let k = 0; k < spans.length; k++) if (hit[k]) { out += esc(text.slice(pos, spans[k][0])) + '<mark>' + esc(text.slice(spans[k][0], spans[k][1])) + '</mark>'; pos = spans[k][1]; }
    return out + esc(text.slice(pos));
  },

  suggest(prefixQuery, k = 8) {
    const q = prefixQuery.replace(/^\s+/, ''); const m = /(.*?)([^\s()"]*)$/.exec(q); const head = m[1], last = m[2].toLowerCase();
    const out = [];
    if (last.length >= 2) {
      for (const t of this.allTopics()) if (t.name.toLowerCase().startsWith(q.toLowerCase()) && out.length < 3) out.push({ text: t.name, kind: 'topic', id: t.id });
      for (const [a, full] of Object.entries(ABBREVIATIONS)) if (a.startsWith(last) && out.length < 4) out.push({ text: head + a.toUpperCase(), kind: 'abbr', hint: full });
      for (const v of this.prefixTerms(normTok(last).slice(0, Math.max(2, last.length)), k)) { if (out.length >= k) break; if (!out.some(o => o.text.toLowerCase() === (head + v).toLowerCase())) out.push({ text: head + v, kind: 'term', hint: this.post.get(v).p.length + ' pages' }); }
    }
    return out.slice(0, k);
  },

  // ---------- passages ----------
  _passCache: new Map(),
  passages(gi) {
    if (this._passCache.has(gi)) return this._passCache.get(gi);
    const { docId, p, doc } = this.loc(gi);
    const lines = (this.text[gi] || '').split('\n');
    const heads = new Map((doc?.pack.heads?.[p] || []).map(([i, s]) => [i, s]));
    const crumbs = this.breadcrumb(docId, p);
    const out = []; let cur = null; let head = null;
    const flush = () => { if (cur && cur.text.trim().length > 40) out.push(cur); cur = null; };
    lines.forEach((ln, i) => {
      if (heads.has(i)) { flush(); head = heads.get(i); return; }
      if (!cur) cur = { gi, docId, p, head, crumbs, li: i, text: '' };
      const prev = cur.text;
      const breakHere = prev.length > 380 && /[.!?]$/.test(prev.trim()) && /^[A-Z•●\d(]/.test(ln.trim());
      if (breakHere || prev.length > 900) { flush(); cur = { gi, docId, p, head, crumbs, li: i, text: '' }; }
      cur.text += (cur.text ? (cur.text.endsWith('-') && /^[a-z]/.test(ln) ? '' : '\n') : '') + ln;
    });
    flush();
    if (this._passCache.size > 3000) this._passCache.clear();
    this._passCache.set(gi, out);
    return out;
  },

  // Verbatim excerpts for each topic-page heading.
  topicContent(topicId, { maxPages = 70, perSection = 3 } = {}) {
    const t = this.topics.get(topicId); if (!t) return null;
    const pages = (this.topicPages.get(topicId) || []).slice(0, maxPages);
    const top = pages[0]?.[1] || 1;
    const kwStrs = t.kwc.map(k => k.str);
    const primary = this.topicSections.get(topicId) || [];
    const primaryStart = new Set(primary.map(s => this.gi(s.docId, s.p)));
    const buckets = new Map(SECTIONS.map(s => [s.id, []]));
    for (const [gi, ps] of pages) {
      const weight = 0.5 + 0.5 * ps / top;
      for (const [idx, pa] of this.passages(gi).entries()) {
        const ts = ' ' + tokenize(pa.text).join(' ') + ' ';
        let topicHit = 0; for (const s of kwStrs) if (ts.includes(s)) topicHit++;
        const inPrimary = primary.some(s => s.docId === pa.docId && pa.p >= s.p && pa.p <= s.end);
        if (!topicHit && !inPrimary) continue;
        for (const sec of SECTIONS) {
          let s = 0;
          if (pa.head && sec.head.test(pa.head.replace(/^[\d.\s]+/, ''))) s += 4;
          const c = reCount(sec.cue, pa.text); s += Math.min(3, c) * 0.8;
          if (sec.numbered && /(^|\n)\s*\d+[.)]\s/.test(pa.text)) s += 1;
          if (sec.id === 'definition' && primaryStart.has(gi) && idx === 0) s += 2.5;
          if (s < 1.6) continue;
          s *= weight * (topicHit ? 1 + 0.2 * Math.min(topicHit, 3) : 0.7) * (inPrimary ? 1.3 : 1);
          buckets.get(sec.id).push({ ...pa, score: s });
        }
      }
    }
    const sections = [];
    for (const sec of SECTIONS) {
      const arr = buckets.get(sec.id).sort((a, b) => b.score - a.score);
      const picked = []; const docsUsed = new Map(); const seenText = new Set();
      for (const a of arr) {
        if (picked.length >= perSection) break;
        const key = a.gi + ':' + a.li; if (seenText.has(key)) continue;
        if ((docsUsed.get(a.docId) || 0) >= 2 && arr.some(o => !docsUsed.has(o.docId))) continue;
        picked.push(a); seenText.add(key); docsUsed.set(a.docId, (docsUsed.get(a.docId) || 0) + 1);
      }
      if (picked.length) sections.push({ ...sec, items: picked, more: arr.length - picked.length });
    }
    return { topic: t, pages, primary, sections };
  },

  // Group pages into "doc: p. a–b, c" reference lists.
  refList(gis) {
    const byDoc = new Map();
    for (const gi of gis) { const d = this.gDoc[gi]; if (!byDoc.has(d)) byDoc.set(d, []); byDoc.get(d).push(this.gPage[gi]); }
    return [...byDoc.entries()].map(([docId, ps]) => {
      ps.sort((a, b) => a - b); const runs = [];
      for (const p of ps) { const r = runs[runs.length - 1]; if (r && p === r[1] + 1) r[1] = p; else runs.push([p, p]); }
      return { docId, runs };
    });
  },

  // ---------- quick reference ----------
  mineQuickRef() {
    const out = [];
    const push = (gi, title, kind, li) => {
      for (const g of QUICKREF) if (g.re.test(title) && !(g.not && g.not.test(title))) out.push({ gi, title, kind, li, group: g.id });
    };
    for (const id of this.order) {
      const d = this.docs.get(id);
      for (const p in d.pack.heads || {}) if (!d.skip[p]) for (const [li, h] of d.pack.heads[p]) if (!/\s\d{1,4}$/.test(h) && !/^\d{1,3}\s+[A-Z]/.test(h)) push(d.base + (+p), h, 'heading', li);
      for (const f of d.pack.figs || []) if (!d.skip[f.p]) push(d.base + f.p, f.cap, f.kind, -1);
      for (const r of d.ranges) if (r.l >= 1 && !d.skip[r.p] && !SKIP_SECTION.test(r.t)) push(d.base + r.p, r.t, 'section', -1);
    }
    const seen = new Set();
    this.qref = out.filter(e => { const k = e.group + '|' + e.gi + '|' + e.title.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
  },
  qrefExcerpt(e) {
    const lines = (this.text[e.gi] || '').split('\n');
    let start = e.li >= 0 ? e.li : lines.findIndex(l => l.includes(e.title.slice(0, 30)));
    if (start < 0) start = 0;
    let s = ''; for (let i = start; i < lines.length && s.length < 700; i++) s += (s ? '\n' : '') + lines[i];
    return s;
  },

  // ---------- figures ----------
  mineFigures() {
    const out = [];
    for (const id of this.order) {
      const d = this.docs.get(id);
      const seen = new Set();
      for (const f of d.pack.figs || []) {
        const key = f.label + '|' + f.p; if (seen.has(key) || d.skip[f.p]) continue; seen.add(key);
        const kinds = IMAGE_KINDS.filter(k => k.re.test(f.cap)).map(k => k.id);
        if (f.kind === 'table' && !kinds.includes('table')) kinds.push('table');
        const gi = d.base + f.p;
        const capTopics = [];
        const ts = ' ' + tokenize(f.cap).join(' ') + ' ';
        for (const t of this.topics.values()) { let s = 0; for (const k of t.kwc) if (ts.includes(k.str)) s += k.w; if (s >= 1) capTopics.push([t.id, s]); }
        capTopics.sort((a, b) => b[1] - a[1]);
        const topics = [...new Set([...capTopics.slice(0, 3).map(x => x[0]), ...(this.pageTopics[gi] || []).slice(0, 2).map(x => x[0])])];
        out.push({ id: id + ':' + f.p + ':' + f.label, docId: id, p: f.p, gi, label: f.label, cap: f.cap, kind: f.kind, kinds, topics });
      }
      for (const p of d.meta.imagePages || []) if (!out.some(o => o.docId === id && o.p === p)) out.push({ id: id + ':' + p + ':img', docId: id, p, gi: d.base + p, label: 'Image', cap: (this.breadcrumb(id, p).slice(-1)[0] || 'Page image'), kind: 'figure', kinds: [], topics: (this.pageTopics[d.base + p] || []).slice(0, 2).map(x => x[0]), uncaptioned: true });
    }
    this.figures = out;
  },

  // ---------- overlap between documents ----------
  overlaps(gis, minSim = 0.12) {
    const sh = new Map();
    const shingles = gi => { if (sh.has(gi)) return sh.get(gi); const t = this.tokStr[gi].trim().split(' ').filter(w => !STOP.has(w)); const s = new Set(); for (let i = 0; i + 4 <= t.length; i++) s.add(t[i] + ' ' + t[i + 1] + ' ' + t[i + 2] + ' ' + t[i + 3]); sh.set(gi, s); return s; };
    const pairs = [];
    for (let i = 0; i < gis.length; i++) for (let j = i + 1; j < gis.length; j++) {
      const a = gis[i], b = gis[j]; if (this.gDoc[a] === this.gDoc[b]) continue;
      const A = shingles(a), B = shingles(b); if (!A.size || !B.size) continue;
      let inter = 0; const [small, big] = A.size < B.size ? [A, B] : [B, A]; for (const x of small) if (big.has(x)) inter++;
      const sim = inter / Math.min(A.size, B.size);
      if (sim >= minSim) pairs.push({ a, b, sim, shared: inter });
    }
    return pairs.sort((x, y) => y.sim - x.sim);
  },

  // Passages for AI retrieval.
  retrieve(query, { docs, k = 10, topic, category } = {}) {
    const r = this.search(query, { docs, topic, category, fuzzy: false });
    const hl = this.highlightSet(r.info); const out = [];
    for (const res of r.results.filter(x => !isSkipPage(x.gi)).slice(0, Math.max(k, 6))) {
      const ps = this.passages(res.gi);
      const scored = ps.map(pa => { const ts = tokenize(pa.text); let s = 0; for (const w of ts) if (hl.terms.has(w)) s++; for (const ph of hl.phrases) if ((' ' + ts.join(' ') + ' ').includes(' ' + ph.join(' ') + ' ')) s += 3; return [pa, s]; }).filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]);
      for (const [pa] of scored.slice(0, 2)) out.push(pa);
      if (out.length >= k) break;
    }
    return out.slice(0, k);
  },
};
