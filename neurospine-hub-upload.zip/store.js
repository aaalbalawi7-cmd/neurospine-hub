import { makeApiSample, apiConfig } from './ai-api.js';
// Persistence. Cloud first (the artifact's private per-user db + assets), with an
// IndexedDB fallback so the app still works when cloud storage is unavailable.

const IDB_NAME = 'nsh-hub';
const IDB_VER = 2;
let idbPromise = null;

function idb() {
  if (!idbPromise) {
    idbPromise = new Promise((resolve, reject) => {
      let req;
      try { req = indexedDB.open(IDB_NAME, IDB_VER); } catch (e) { reject(e); return; }
      req.onupgradeneeded = () => {
        const d = req.result;
        for (const s of ['kv', 'files', 'packs', 'partial', 'thumbs']) if (!d.objectStoreNames.contains(s)) d.createObjectStore(s);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return idbPromise;
}

function tx(store, mode, fn) {
  return idb().then(d => new Promise((resolve, reject) => {
    const t = d.transaction(store, mode);
    const os = t.objectStore(store);
    let out;
    const r = fn(os);
    if (r) r.onsuccess = () => { out = r.result; };
    t.oncomplete = () => resolve(out);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  }));
}

export const local = {
  async get(store, key) { try { return await tx(store, 'readonly', os => os.get(key)); } catch { return undefined; } },
  async set(store, key, val) { try { await tx(store, 'readwrite', os => os.put(val, key)); return true; } catch (e) { console.warn('IDB set failed', e); return false; } },
  async del(store, key) { try { await tx(store, 'readwrite', os => os.delete(key)); } catch { /* ignore */ } },
  async keys(store) { try { return (await tx(store, 'readonly', os => os.getAllKeys())) || []; } catch { return []; } },
  async clear(store) { try { await tx(store, 'readwrite', os => os.clear()); } catch { /* ignore */ } },
};

const safeSeg = s => String(s).replace(/[^A-Za-z0-9_\-.~:@+]/g, '_').slice(0, 180) || '_';

// Cloud document store, rooted at the viewer's private subtree data/users/<id>.
class CloudStore {
  constructor(db, uid) { this.db = db; this.base = 'data/users/' + safeSeg(uid); this.kind = 'cloud'; }
  sPath(name) { return this.base + '/' + safeSeg(name); }
  cPath(col) { return this.base + '/' + safeSeg(col) + '/items'; }
  async getS(name) { const s = await this.db.doc(this.sPath(name)).get(); return s.exists ? s.data() : null; }
  async setS(name, data) { await this.db.doc(this.sPath(name)).set(data); }
  async delS(name) { await this.db.doc(this.sPath(name)).delete(); }
  async list(col) {
    const s = await this.db.collection(this.cPath(col)).get();
    return s.docs.map(d => ({ ...d.data(), id: d.id }));
  }
  async put(col, id, data) { await this.db.collection(this.cPath(col)).doc(safeSeg(id)).set(data); }
  async del(col, id) { await this.db.collection(this.cPath(col)).doc(safeSeg(id)).delete(); }
}

// Same API, kept in this browser only.
class LocalStore {
  constructor() { this.kind = 'local'; }
  async getS(name) { return (await local.get('kv', 's:' + name)) ?? null; }
  async setS(name, data) { await local.set('kv', 's:' + name, data); }
  async delS(name) { await local.del('kv', 's:' + name); }
  async list(col) {
    const pre = 'c:' + col + ':';
    const keys = (await local.keys('kv')).filter(k => typeof k === 'string' && k.startsWith(pre));
    const out = [];
    for (const k of keys) { const v = await local.get('kv', k); if (v) out.push({ ...v, id: k.slice(pre.length) }); }
    return out;
  }
  async put(col, id, data) { await local.set('kv', 'c:' + col + ':' + safeSeg(id), data); }
  async del(col, id) { await local.del('kv', 'c:' + col + ':' + safeSeg(id)); }
}

// Serializes writes per key so one document never has two writes in flight.
class WriteQueue {
  constructor(store) { this.store = store; this.chains = new Map(); }
  run(key, fn) {
    const prev = this.chains.get(key) || Promise.resolve();
    const next = prev.catch(() => {}).then(fn);
    this.chains.set(key, next);
    next.finally(() => { if (this.chains.get(key) === next) this.chains.delete(key); });
    return next;
  }
}

export const Store = {
  backend: new LocalStore(),
  cloud: false,
  assets: null,
  sample: null,
  downloads: null,
  user: null,
  uid: null,
  queue: null,
  async init(onStatus) {
    const claude = window.claude;
    this.queue = new WriteQueue(this.backend);
    if (!claude || typeof claude.use !== 'function') {
      // Standalone website: data stays in this browser; AI works with the user's own API key.
      this.standalone = true;
      this.sample = makeApiSample();
      this.aiReady = !!apiConfig().key;
      try { if (navigator.storage?.persist && !(await navigator.storage.persisted())) await navigator.storage.persist(); } catch { /* optional */ }
      onStatus?.('local'); return;
    }
    try {
      const [db, user, assets, sample, downloads] = await Promise.all([
        claude.use('db').catch(() => null), claude.use('user').catch(() => null), claude.use('assets').catch(() => null),
        claude.use('sample').catch(() => null), claude.use('downloads').catch(() => null),
      ]);
      this.user = user; this.assets = assets; this.sample = sample; this.downloads = downloads;
      const uid = user ? await user.id().catch(() => null) : null;
      if (db && uid) {
        const cs = new CloudStore(db, uid);
        // Probe once so a refusal (view-only access) falls back cleanly.
        await cs.getS('profile');
        this.backend = cs; this.cloud = true; this.uid = uid;
        this.queue = new WriteQueue(cs);
      }
    } catch (e) { console.warn('cloud init failed', e); }
    onStatus?.(this.cloud ? 'cloud' : 'local');
  },
  getS(name) { return this.backend.getS(name).catch(e => { console.warn('getS', name, e); return null; }); },
  setS(name, data) { return this.queue.run('s:' + name, () => this.backend.setS(name, data)); },
  delS(name) { return this.queue.run('s:' + name, () => this.backend.delS(name)); },
  list(col) { return this.backend.list(col).catch(e => { console.warn('list', col, e); return []; }); },
  put(col, id, data) { return this.queue.run(col + ':' + id, () => this.backend.put(col, id, data)); },
  del(col, id) { return this.queue.run(col + ':' + id, () => this.backend.del(col, id)); },

  // ---- assets (cloud file storage) ----
  async upload(blob, type) {
    if (!this.assets) throw { code: 'unavailable' };
    let last;
    for (let i = 0; i < 2; i++) {
      try { return await this.assets.upload(blob, { type }); } catch (e) { last = e; if (e?.code !== 'store_unavailable') break; await new Promise(r => setTimeout(r, 1200)); }
    }
    throw last;
  },
  assetUrl(id) { return '/_blob/' + id; },
  async fetchAsset(id) {
    const r = await fetch(this.assetUrl(id), { credentials: 'same-origin' });
    if (!r.ok) throw new Error('asset ' + id + ' HTTP ' + r.status);
    return r;
  },
  async usage() { try { return (await this.assets.list()).usage; } catch { return null; } },
  async deleteAsset(id) { try { await this.assets?.delete(id); } catch (e) { console.warn('asset delete', e); } },
};

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
