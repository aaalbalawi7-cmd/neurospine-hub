// Shared app state, UI helpers and the action/view registries.
import { Store, uid } from './store.js';
import { Lib, esc } from './library.js';
import { HIGHLIGHT_COLORS } from './taxonomy.js';
export { esc, uid };

export const S = {
  docs: new Map(),          // id -> doc meta
  ann: [], bm: [], cards: [], qcards: [], cols: [], chats: [],
  prefs: { theme: 'system', fontSize: 16, fuzzy: false, abbr: true, storeOriginals: true },
  topicStatus: {}, favorites: { topics: [] }, history: { items: [], counts: {} },
  ai: new Map(),            // cached AI syntheses
  search: { q: '', opts: { docs: [], category: '', topic: '', focus: '', fuzzy: false, abbr: true }, shown: 20, last: null },
  route: { name: 'dashboard', arg: null },
  indexing: null,
};

export const views = {};
export const actions = {};
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

// ---------- routing (hash names: #topics, #topic-<id>, #page-<doc>-<n>) ----------
export function go(hash) { if (location.hash === '#' + hash) render(); else location.hash = hash; }
export function parseHash() {
  const h = (location.hash || '').slice(1);
  if (!h) return { name: 'dashboard' };
  let m;
  if ((m = /^topic-(.+)$/.exec(h))) return { name: 'topic', arg: m[1] };
  if ((m = /^page-([A-Za-z0-9]+)-(\d+)$/.exec(h))) return { name: 'viewer', arg: { docId: m[1], p: +m[2] - 1 } };
  if (h === 'preferences') return { name: 'settings' };
  return { name: h };
}
let renderSeq = 0;
export async function render() {
  const r = parseHash(); S.route = r; const seq = ++renderSeq;
  const main = $('#view'); const fn = views[r.name] || views.dashboard;
  $$('.nav a').forEach(a => a.classList.toggle('active', a.dataset.view === (r.name === 'topic' ? 'topics' : r.name === 'viewer' ? 'library' : r.name)));
  document.body.classList.remove('nav-open');
  document.body.dataset.view = r.name;
  try {
    const html = await fn(r.arg);
    if (seq !== renderSeq) return;
    if (typeof html === 'string') { main.innerHTML = html; main.scrollTop = 0; window.scrollTo(0, 0); }
    views['after_' + r.name]?.(r.arg, main);
  } catch (e) {
    console.error(e);
    main.innerHTML = `<div class="panel error"><h2>Something went wrong</h2><p>${esc(e.message || e)}</p></div>`;
  }
}
export const pageHash = (docId, p) => `page-${docId}-${p + 1}`;

// ---------- small UI kit ----------
export function toast(msg, kind = '') {
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg;
  $('#toasts').appendChild(t); setTimeout(() => t.classList.add('out'), 3600); setTimeout(() => t.remove(), 4200);
}
export function modal(html, { wide = false, onClose } = {}) {
  const wrap = document.createElement('div'); wrap.className = 'modal-wrap';
  wrap.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><button class="icon-btn close" data-close aria-label="Close">×</button>${html}</div>`;
  const close = () => { wrap.remove(); onClose?.(); };
  wrap.addEventListener('click', e => { if (e.target === wrap || e.target.closest('[data-close]')) close(); });
  document.body.appendChild(wrap);
  const f = wrap.querySelector('input,textarea,select'); if (f) setTimeout(() => f.focus(), 30);
  return { el: wrap.querySelector('.modal'), close };
}
export function confirmBox(text, okLabel = 'Delete') {
  return new Promise(res => {
    const m = modal(`<h3>${esc(text)}</h3><div class="row end"><button class="btn" data-close>Cancel</button><button class="btn danger" id="cb-ok">${esc(okLabel)}</button></div>`, { onClose: () => res(false) });
    m.el.querySelector('#cb-ok').onclick = () => { res(true); m.close(); };
  });
}
export function fmtDate(t) { if (!t) return ''; const d = new Date(t); return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); }
export function fmtAgo(t) { const s = (Date.now() - t) / 1000; if (s < 60) return 'just now'; if (s < 3600) return Math.round(s / 60) + ' min ago'; if (s < 86400) return Math.round(s / 3600) + ' h ago'; return Math.round(s / 86400) + ' d ago'; }
export const n = x => (x ?? 0).toLocaleString();
export const colorCss = id => (HIGHLIGHT_COLORS.find(c => c.id === id) || HIGHLIGHT_COLORS[0]).css;

// Citation chip that opens the original page.
export function citeChip(docId, p, extra = '') {
  const l = Lib.label(docId, p); const pr = Lib.hasLabel(docId, p) ? `p. ${l}${l !== String(p + 1) ? ` · PDF ${p + 1}` : ''}` : `PDF p. ${p + 1}`;
  return `<a class="cite-chip" href="#${pageHash(docId, p)}" title="${esc(Lib.cite(docId, p))}"><span class="cd">${esc(Lib.shortName(docId))}</span><span class="cp">${esc(pr)}</span>${extra}</a>`;
}
export function emptyState(title, body, cta = '') { return `<div class="empty"><h3>${esc(title)}</h3><p>${body}</p>${cta}</div>`; }
export const notFound = () => `<p class="notfound">Information not found in the uploaded sources.</p>`;

// ---------- persistence helpers ----------
export async function saveSingleton(name) { const map = { prefs: S.prefs, topicStatus: S.topicStatus, favorites: S.favorites, history: S.history }; await Store.setS(name, JSON.parse(JSON.stringify(map[name]))).catch(e => storageError(e)); }
export function storageError(e) {
  console.warn(e);
  if (e?.code === 'quota_exceeded') toast('Cloud storage is full. Delete some items or export a backup.', 'bad');
  else toast('Could not save. Check your connection and try again.', 'bad');
}
export async function putItem(col, item) { item.updatedAt = Date.now(); await Store.put(col, item.id, JSON.parse(JSON.stringify(item))).catch(storageError); }
export async function delItem(col, id) { await Store.del(col, id).catch(storageError); }

let histTimer = null;
export function recordVisit(entry) {
  const h = S.history; const key = entry.type + ':' + (entry.id || entry.docId + ':' + entry.p);
  h.items = [{ ...entry, key, t: Date.now() }, ...h.items.filter(x => x.key !== key)].slice(0, 120);
  if (entry.type === 'topic') h.counts[entry.id] = (h.counts[entry.id] || 0) + 1;
  clearTimeout(histTimer); histTimer = setTimeout(() => saveSingleton('history'), 1500);
}

// ---------- files out ----------
export async function saveFile(filename, data, textFallback) {
  if (Store.downloads) {
    try { await Store.downloads.save({ filename, data }); toast('Saved ' + filename); return true; }
    catch (e) { if (e?.code === 'declined') return false; console.warn('download failed', e); }
  }
  if (Store.standalone) {
    try {
      const blob = data instanceof Blob ? data : new Blob([data], { type: /\.json$/.test(filename) ? 'application/json' : /\.md$/.test(filename) ? 'text/markdown' : 'application/octet-stream' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000); toast('Saved ' + filename); return true;
    } catch (e) { console.warn('download failed', e); }
  }
  if (textFallback != null) {
    const m = modal(`<h3>Copy ${esc(filename)}</h3><p class="muted">File downloads aren't available in this view. Copy the contents instead.</p><textarea class="copybox" readonly>${esc(textFallback)}</textarea><div class="row end"><button class="btn primary" id="cpy">Copy</button></div>`, { wide: true });
    m.el.querySelector('#cpy').onclick = async () => { try { await navigator.clipboard.writeText(textFallback); toast('Copied'); } catch { m.el.querySelector('textarea').select(); toast('Press Ctrl/Cmd+C to copy'); } };
  } else toast('Downloads are not available in this view.', 'bad');
  return false;
}

// ---------- delegated actions ----------
export function bindActions(root) {
  root.addEventListener('click', e => {
    const a = e.target.closest('[data-act]'); if (!a || !root.contains(a)) return;
    const fn = actions[a.dataset.act]; if (!fn) return;
    e.preventDefault(); fn(a, e);
  });
  root.addEventListener('change', e => { const a = e.target.closest('[data-change]'); if (a && actions[a.dataset.change]) actions[a.dataset.change](a, e); });
  root.addEventListener('input', e => { const a = e.target.closest('[data-input]'); if (a && actions[a.dataset.input]) actions[a.dataset.input](a, e); });
}

export function topicStatusChip(id) {
  const s = S.topicStatus[id]; if (!s) return '';
  const label = { reviewed: 'Reviewed', review: 'Needs review', important: 'Important' }[s];
  return `<span class="status s-${s}">${label}</span>`;
}
export function isFav(id) { return S.favorites.topics.includes(id); }
