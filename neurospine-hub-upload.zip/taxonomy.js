// Default category tree, search vocabulary and section cues.
// These lists are search/classification vocabulary only. They hold no medical
// content: every statement the app shows comes from the uploaded PDFs.
// Keyword syntax: "term" (weight 1 for a single word, 2 for a phrase) or "term:0.4" (explicit weight).

export const DEFAULT_TAXONOMY = [
  { id: 'general', name: 'General Neurosurgery', code: 'A', subs: [
    { id: 'neuroanatomy', name: 'Neuroanatomy', kw: ['neuroanatomy:3', 'anatomy:0.6', 'cranial nerve', 'brainstem', 'cerebral cortex', 'circle of willis', 'basal ganglia', 'thalamus', 'internal capsule', 'cerebellum:0.6', 'ventricular system', 'brodmann', 'dermatome', 'spinal cord anatomy', 'vascular anatomy', 'cerebral arteries', 'venous sinuses', 'cortical localization'] },
    { id: 'neuro-exam', name: 'Neurological Examination', kw: ['neurological examination:3', 'neurologic exam', 'neurologic examination', 'physical examination', 'motor exam', 'sensory exam', 'reflexes', 'reflex:0.6', 'muscle strength', 'babinski', 'hoffmann', 'romberg', 'gait:0.6', 'pupillary', 'muscle grading', 'myotome', 'cranial nerve examination'] },
    { id: 'principles', name: 'Neurosurgical Principles', kw: ['surgical principles:3', 'neurosurgical principles', 'brain relaxation', 'surgical positioning', 'patient positioning', 'hemostasis', 'microsurgical technique', 'surgical planning', 'brain retraction', 'operative principles', 'craniotomy closure'] },
    { id: 'neuroimaging', name: 'Neuroimaging', kw: ['neuroimaging:3', 'imaging:0.4', 'mri:0.5', 'magnetic resonance', 'computed tomography', 'ct scan', 'angiography:0.7', 'cerebral angiography', 'cta', 'mra', 'myelography', 'myelogram', 'diffusion weighted', 'dwi', 'flair', 'perfusion imaging', 'pet scan', 'spect', 'radiograph:0.5', 'contrast enhancement'] },
    { id: 'approaches', name: 'Surgical Approaches', kw: ['surgical approach:3', 'approach:0.4', 'craniotomy:0.8', 'pterional', 'retrosigmoid', 'suboccipital', 'far lateral', 'interhemispheric', 'orbitozygomatic', 'subtemporal', 'transcallosal', 'keyhole', 'supraorbital', 'translabyrinthine', 'middle fossa approach', 'transcortical', 'bicoronal'] },
    { id: 'instruments', name: 'Neurosurgical Instruments', kw: ['surgical instruments:3', 'instrument:0.6', 'retractor', 'operating microscope', 'endoscope', 'high-speed drill', 'bipolar', 'ultrasonic aspirator', 'cusa', 'neuronavigation', 'stereotactic frame', 'navigation:0.5', 'exoscope', 'mayfield'] },
    { id: 'periop', name: 'Perioperative Management', kw: ['perioperative:2', 'preoperative:1', 'postoperative:0.5', 'anesthesia:0.8', 'antibiotic prophylaxis', 'dvt prophylaxis', 'anticoagulation', 'antiplatelet', 'reversal of anticoagulation', 'seizure prophylaxis', 'steroid:0.5', 'dexamethasone:0.6', 'fluid management', 'blood pressure management', 'transfusion'] },
    { id: 'critical-care', name: 'Neurocritical Care', kw: ['neurocritical care:3', 'intensive care', 'icu', 'intracranial pressure:2', 'icp:1.2', 'cerebral perfusion pressure', 'hyperosmolar', 'mannitol', 'hypertonic saline', 'sedation', 'hyponatremia', 'siadh', 'cerebral salt wasting', 'diabetes insipidus', 'brain death', 'mechanical ventilation', 'herniation syndrome', 'coma'] },
    { id: 'complications', name: 'Complications and Their Management', kw: ['complications:1.2', 'complication:1', 'postoperative complication:3', 'csf leak', 'wound infection', 'surgical site infection', 'postoperative hematoma', 'venous thromboembolism', 'pulmonary embolism', 'deep vein thrombosis', 'pseudomeningocele', 'postoperative infection', 'wound dehiscence'] },
  ]},
  { id: 'oncology', name: 'Brain Tumors and Neuro-Oncology', code: 'B', subs: [
    { id: 'gliomas', name: 'Gliomas', kw: ['glioma:2', 'gliomas:2', 'astrocytoma', 'oligodendroglioma', 'low-grade glioma:3', 'high-grade glioma:3', 'diffuse glioma', 'idh', '1p/19q', 'pilocytic', 'gliomatosis', 'anaplastic astrocytoma'] },
    { id: 'glioblastoma', name: 'Glioblastoma', kw: ['glioblastoma:3', 'gbm:2', 'temozolomide', 'mgmt', 'stupp', 'tumor treating fields', 'pseudoprogression'] },
    { id: 'meningiomas', name: 'Meningiomas', kw: ['meningioma:3', 'meningiomas:3', 'simpson grade', 'convexity meningioma', 'parasagittal', 'falcine', 'sphenoid wing', 'olfactory groove', 'tuberculum sellae', 'dural tail'] },
    { id: 'pituitary', name: 'Pituitary Tumors', kw: ['pituitary adenoma:3', 'pituitary:1.2', 'prolactinoma', 'acromegaly', 'cushing', 'pituitary apoplexy', 'sellar', 'sella turcica', 'transsphenoidal', 'pituitary neuroendocrine', 'nonfunctioning adenoma', 'macroadenoma', 'microadenoma', 'rathke cleft'] },
    { id: 'vestibular', name: 'Vestibular Schwannomas', kw: ['vestibular schwannoma:3', 'acoustic neuroma:3', 'schwannoma:1', 'cerebellopontine angle', 'cpa tumor', 'koos', 'neurofibromatosis type 2', 'nf2', 'hearing preservation', 'facial nerve preservation'] },
    { id: 'metastases', name: 'Metastatic Brain Tumors', kw: ['brain metastases:3', 'cerebral metastases:3', 'brain metastasis', 'metastatic brain tumor', 'metastases:0.6', 'metastatic:0.5', 'whole brain radiation', 'wbrt', 'radiosurgery:0.7', 'leptomeningeal'] },
    { id: 'peds-tumors', name: 'Pediatric Brain Tumors', kw: ['pediatric brain tumor:3', 'medulloblastoma:2', 'ependymoma:1.2', 'pilocytic astrocytoma', 'craniopharyngioma:1.5', 'dipg', 'diffuse intrinsic pontine glioma', 'atypical teratoid', 'atrt', 'germ cell tumor', 'germinoma', 'posterior fossa tumor', 'pineal region'] },
    { id: 'skull-base', name: 'Skull Base Tumors', kw: ['skull base:2', 'chordoma', 'chondrosarcoma', 'esthesioneuroblastoma', 'glomus jugulare', 'paraganglioma', 'petroclival', 'clivus', 'jugular foramen', 'cavernous sinus', 'anterior skull base', 'endoscopic endonasal'] },
  ]},
  { id: 'vascular', name: 'Cerebrovascular Neurosurgery', code: 'C', subs: [
    { id: 'aneurysms', name: 'Intracranial Aneurysms', kw: ['aneurysm:1.5', 'aneurysms:1.5', 'intracranial aneurysm:3', 'aneurysm clipping', 'clipping', 'coiling', 'flow diverter', 'giant aneurysm', 'unruptured aneurysm', 'pcom', 'acom', 'basilar tip', 'mycotic aneurysm', 'fusiform aneurysm'] },
    { id: 'sah', name: 'Subarachnoid Hemorrhage', kw: ['subarachnoid hemorrhage:3', 'sah:2', 'hunt and hess', 'fisher grade', 'wfns', 'vasospasm', 'delayed cerebral ischemia', 'nimodipine', 'thunderclap', 'perimesencephalic'] },
    { id: 'ich', name: 'Intracerebral Hemorrhage', kw: ['intracerebral hemorrhage:3', 'ich:1.5', 'intraparenchymal hemorrhage', 'hypertensive hemorrhage', 'ich score', 'amyloid angiopathy', 'spot sign', 'lobar hemorrhage', 'cerebellar hemorrhage', 'intraventricular hemorrhage'] },
    { id: 'avm', name: 'Arteriovenous Malformations', kw: ['arteriovenous malformation:3', 'avm:2', 'avms:2', 'spetzler-martin', 'nidus', 'dural arteriovenous fistula', 'davf', 'vein of galen', 'arteriovenous fistula'] },
    { id: 'cavernous', name: 'Cavernous Malformations', kw: ['cavernous malformation:3', 'cavernoma', 'cavernous angioma', 'cerebral cavernous malformation', 'ccm', 'developmental venous anomaly', 'zabramski', 'venous angioma'] },
    { id: 'stroke', name: 'Ischemic Stroke', kw: ['ischemic stroke:3', 'stroke:1', 'cerebral infarction', 'thrombectomy', 'thrombolysis', 'alteplase', 'tpa', 'malignant mca', 'nihss', 'transient ischemic attack', 'large vessel occlusion', 'cerebellar infarction'] },
    { id: 'moyamoya', name: 'Moyamoya Disease', kw: ['moyamoya:3', 'revascularization', 'sta-mca', 'encephaloduroarteriosynangiosis', 'edas', 'cerebral bypass', 'suzuki'] },
    { id: 'carotid', name: 'Carotid Artery Disease', kw: ['carotid endarterectomy:3', 'carotid stenosis:3', 'carotid:1', 'carotid stenting', 'carotid dissection', 'nascet', 'cervical artery dissection', 'vertebral artery dissection'] },
  ]},
  { id: 'spine', name: 'Spine Surgery', code: 'D', subs: [
    { id: 'cervical', name: 'Cervical Spine', kw: ['cervical spine:3', 'cervical:0.5', 'atlantoaxial', 'odontoid', 'acdf', 'anterior cervical discectomy', 'cervical myelopathy', 'cervical radiculopathy', 'craniovertebral junction', 'occipitocervical', 'laminoplasty', 'cervical corpectomy', 'subaxial'] },
    { id: 'thoracic', name: 'Thoracic Spine', kw: ['thoracic spine:3', 'thoracic:0.5', 'thoracic disc', 'costotransversectomy', 'thoracotomy', 'thoracolumbar junction', 'transthoracic', 'thoracic myelopathy'] },
    { id: 'lumbar', name: 'Lumbar Spine', kw: ['lumbar spine:3', 'lumbar:0.5', 'lumbosacral', 'low back pain', 'sciatica', 'lumbar discectomy', 'lumbar fusion', 'sacroiliac', 'lumbar radiculopathy'] },
    { id: 'degenerative', name: 'Degenerative Spine Diseases', kw: ['degenerative disc disease:3', 'degenerative:0.6', 'spondylosis', 'facet arthropathy', 'osteophyte', 'ossification of the posterior longitudinal ligament', 'opll', 'ligamentum flavum', 'adjacent segment', 'cervical spondylotic myelopathy', 'disc degeneration'] },
    { id: 'disc', name: 'Disc Herniation', kw: ['disc herniation:3', 'herniated disc', 'herniated nucleus pulposus', 'hnp', 'microdiscectomy', 'discectomy', 'disc protrusion', 'disc extrusion', 'sequestration', 'far lateral disc', 'herniated lumbar disc'] },
    { id: 'stenosis', name: 'Spinal Stenosis', kw: ['spinal stenosis:3', 'lumbar stenosis', 'lumbar spinal stenosis', 'cervical stenosis', 'neurogenic claudication', 'canal stenosis', 'foraminal stenosis', 'lateral recess', 'laminectomy:0.8'] },
    { id: 'spondylolisthesis', name: 'Spondylolisthesis', kw: ['spondylolisthesis:3', 'spondylolysis', 'meyerding', 'pars defect', 'pars interarticularis', 'isthmic', 'listhesis'] },
    { id: 'deformity', name: 'Spinal Deformities', kw: ['spinal deformity:3', 'adult spinal deformity:3', 'deformity:0.8', 'sagittal balance', 'sagittal vertical axis', 'pelvic incidence', 'lumbar lordosis', 'pelvic tilt', 'osteotomy', 'pedicle subtraction osteotomy', 'smith-petersen', 'proximal junctional kyphosis', 'flatback'] },
    { id: 'scoliosis', name: 'Scoliosis and Kyphosis', kw: ['scoliosis:3', 'kyphosis:2', 'cobb angle', 'adolescent idiopathic scoliosis', 'scheuermann', 'lenke', 'degenerative scoliosis', 'congenital scoliosis', 'neuromuscular scoliosis', 'kyphoplasty', 'vertebroplasty'] },
    { id: 'spinal-tumors', name: 'Spinal Tumors', kw: ['spinal tumor:3', 'spinal cord tumor:3', 'spine tumor', 'intramedullary', 'intradural extramedullary', 'extradural', 'spinal metastases', 'spinal instability neoplastic score', 'sins', 'vertebral hemangioma', 'nerve sheath tumor', 'en bloc', 'spinal ependymoma'] },
    { id: 'spinal-trauma', name: 'Spinal Trauma', kw: ['spine trauma:3', 'spinal trauma:3', 'spine fracture', 'spinal fracture', 'burst fracture', 'chance fracture', 'tlics', 'slic', 'ao spine', 'odontoid fracture', 'hangman', 'jefferson fracture', 'facet dislocation', 'compression fracture', 'thoracolumbar fracture'] },
    { id: 'spinal-infection', name: 'Spinal Infections', kw: ['spinal infection:3', 'spondylodiscitis', 'discitis', 'vertebral osteomyelitis', 'spinal epidural abscess', 'epidural abscess', 'pott', 'tuberculous spondylitis', 'spinal tuberculosis'] },
    { id: 'cord-compression', name: 'Spinal Cord Compression', kw: ['spinal cord compression:3', 'cord compression', 'myelopathy:1', 'metastatic epidural spinal cord compression', 'mescc', 'cauda equina syndrome', 'conus medullaris', 'epidural spinal cord compression'] },
    { id: 'spine-techniques', name: 'Surgical Techniques and Instrumentation', kw: ['pedicle screw:2', 'lateral mass screw', 'spinal instrumentation', 'interbody cage', 'minimally invasive spine', 'percutaneous screw', 'lateral lumbar interbody', 'xlif', 'olif', 'tlif', 'plif', 'alif', 'endoscopic spine', 'robotic', 'intraoperative navigation', 'cortical screw', 'iliac screw'] },
    { id: 'fusion', name: 'Spinal Fusion and Fixation', kw: ['spinal fusion:3', 'fusion:0.8', 'arthrodesis', 'fixation:0.8', 'bone graft', 'autograft', 'allograft', 'bmp', 'pseudarthrosis', 'posterolateral fusion', 'interbody fusion', 'occipitocervical fusion', 'cervical arthroplasty', 'disc arthroplasty'] },
  ]},
  { id: 'trauma', name: 'Neurotrauma', code: 'E', subs: [
    { id: 'tbi', name: 'Traumatic Brain Injury', kw: ['traumatic brain injury:3', 'tbi:2', 'head injury:2', 'head trauma:2', 'concussion', 'brain trauma foundation', 'icp monitoring', 'decompressive craniectomy', 'post-traumatic', 'glasgow coma scale'] },
    { id: 'edh', name: 'Epidural Hematoma', kw: ['epidural hematoma:3', 'extradural hematoma:3', 'edh:2', 'lucid interval', 'middle meningeal artery'] },
    { id: 'sdh', name: 'Subdural Hematoma', kw: ['subdural hematoma:3', 'sdh:2', 'chronic subdural', 'acute subdural', 'burr hole', 'mma embolization', 'subdural hygroma', 'csdh'] },
    { id: 'contusions', name: 'Contusions', kw: ['cerebral contusion:3', 'contusion:2', 'contusions:2', 'hemorrhagic contusion', 'contrecoup', 'blossoming'] },
    { id: 'dai', name: 'Diffuse Axonal Injury', kw: ['diffuse axonal injury:3', 'dai:2', 'shear injury', 'axonal injury'] },
    { id: 'skull-fx', name: 'Skull Fractures', kw: ['skull fracture:3', 'depressed skull fracture', 'basilar skull fracture', 'temporal bone fracture', 'growing skull fracture', 'csf rhinorrhea', 'csf otorrhea', 'battle sign', 'raccoon eyes', 'ping pong fracture'] },
    { id: 'sci', name: 'Spinal Cord Injury', kw: ['spinal cord injury:3', 'sci:1.5', 'asia impairment scale', 'central cord syndrome', 'brown-sequard', 'anterior cord syndrome', 'spinal shock', 'neurogenic shock', 'methylprednisolone', 'sciwora'] },
  ]},
  { id: 'functional', name: 'Functional and Epilepsy Neurosurgery', code: 'F', subs: [
    { id: 'epilepsy', name: 'Epilepsy Surgery', kw: ['epilepsy surgery:3', 'temporal lobectomy', 'amygdalohippocampectomy', 'corpus callosotomy', 'hemispherectomy', 'vagus nerve stimulation', 'vns', 'responsive neurostimulation', 'laser interstitial thermal therapy', 'litt', 'seizure:0.6', 'seizures:0.6', 'epilepsy:1', 'mesial temporal sclerosis', 'engel'] },
    { id: 'dbs', name: 'Deep Brain Stimulation', kw: ['deep brain stimulation:3', 'dbs:2', 'subthalamic nucleus', 'globus pallidus', 'gpi', 'microelectrode recording', 'lead placement'] },
    { id: 'parkinson', name: "Parkinson's Disease", kw: ['parkinson:3', "parkinson's disease:3", 'parkinson disease:3', 'levodopa', 'dyskinesia', 'bradykinesia'] },
    { id: 'movement', name: 'Movement Disorders', kw: ['movement disorder:3', 'essential tremor', 'dystonia', 'tremor:0.8', 'chorea', 'spasticity', 'intrathecal baclofen', 'selective dorsal rhizotomy'] },
    { id: 'trigeminal', name: 'Trigeminal Neuralgia', kw: ['trigeminal neuralgia:3', 'tic douloureux', 'microvascular decompression', 'mvd', 'glycerol rhizotomy', 'balloon compression', 'percutaneous rhizotomy', 'carbamazepine'] },
    { id: 'facial-pain', name: 'Facial Pain', kw: ['facial pain:3', 'glossopharyngeal neuralgia', 'atypical facial pain', 'occipital neuralgia', 'postherpetic neuralgia', 'hemifacial spasm', 'geniculate neuralgia', 'anesthesia dolorosa'] },
    { id: 'functional-gen', name: 'Functional Neurosurgery', kw: ['functional neurosurgery:3', 'stereotactic:1', 'stereotaxis', 'neuromodulation', 'spinal cord stimulation', 'intrathecal pump', 'cordotomy', 'drez', 'pain surgery', 'lesioning'] },
  ]},
  { id: 'pediatric', name: 'Pediatric Neurosurgery', code: 'G', subs: [
    { id: 'hydrocephalus', name: 'Hydrocephalus', kw: ['hydrocephalus:3', 'ventriculoperitoneal shunt', 'vp shunt', 'shunt:1', 'shunts:1', 'third ventriculostomy', 'etv', 'aqueductal stenosis', 'ventriculomegaly', 'shunt malfunction', 'macrocephaly'] },
    { id: 'craniosynostosis', name: 'Craniosynostosis', kw: ['craniosynostosis:3', 'sagittal synostosis', 'metopic', 'coronal synostosis', 'lambdoid', 'plagiocephaly', 'scaphocephaly', 'trigonocephaly', 'cranial vault', 'crouzon', 'apert'] },
    { id: 'ntd', name: 'Neural Tube Defects', kw: ['neural tube defect:3', 'myelomeningocele:3', 'spina bifida', 'encephalocele', 'anencephaly', 'lipomyelomeningocele', 'tethered cord', 'dermal sinus', 'spinal dysraphism', 'occult dysraphism'] },
    { id: 'chiari', name: 'Chiari Malformation', kw: ['chiari:3', 'chiari malformation:3', 'tonsillar herniation', 'tonsillar ectopia', 'syringomyelia', 'syrinx', 'foramen magnum decompression', 'posterior fossa decompression'] },
    { alias: 'peds-tumors', name: 'Pediatric Brain Tumors' },
    { id: 'peds-spine', name: 'Pediatric Spine Disorders', kw: ['pediatric spine:3', 'split cord malformation', 'diastematomyelia', 'klippel-feil', 'os odontoideum', 'atlantoaxial instability', 'down syndrome', 'sciwora', 'tethered cord', 'congenital scoliosis'] },
  ]},
  { id: 'csf', name: 'CSF Disorders and Other Conditions', code: 'H', subs: [
    { alias: 'hydrocephalus', name: 'Hydrocephalus' },
    { id: 'nph', name: 'Normal Pressure Hydrocephalus', kw: ['normal pressure hydrocephalus:3', 'nph:2', 'inph', 'hakim', 'tap test', 'lumbar drain trial', 'evans index', 'callosal angle', 'gait apraxia'] },
    { id: 'csf-leak', name: 'CSF Leaks', kw: ['csf leak:3', 'cerebrospinal fluid leak:3', 'csf fistula', 'rhinorrhea', 'otorrhea', 'beta-2 transferrin', 'intracranial hypotension', 'spontaneous intracranial hypotension', 'epidural blood patch'] },
    { id: 'iih', name: 'Intracranial Hypertension', kw: ['idiopathic intracranial hypertension:3', 'pseudotumor cerebri:3', 'iih:2', 'benign intracranial hypertension', 'papilledema', 'intracranial hypertension:2', 'optic nerve sheath fenestration', 'venous sinus stenting'] },
    { alias: 'chiari', name: 'Chiari Malformations' },
  ]},
];

// The 16 content headings of a topic page (17th is the reference list), with cue patterns
// used to pick verbatim passages from the sources.
export const SECTIONS = [
  { id: 'definition', name: 'Definition', head: /^(definition|overview|introduction|general information|description)\b/i, cue: /\b(is defined as|defined as|definition|refers to|is a (rare|common|benign|malignant|slow|congenital|chronic|acute)|are a (group|family)|denotes|term(ed)?\b|synonyms?)\b/i },
  { id: 'anatomy', name: 'Relevant Anatomy', head: /^(anatomy|anatomic|surgical anatomy|relevant anatomy|blood supply)\b/i, cue: /\b(anatomy|anatomic(al)?|arises? from|supplied by|course of|landmarks?|origin(ates)?|branches|drains? into|located)\b/i },
  { id: 'pathophysiology', name: 'Pathophysiology', head: /^(pathophysiology|pathogenesis|etiology|pathology|mechanism|histology|genetics|risk factors|epidemiology)\b/i, cue: /\b(pathophysiology|pathogenesis|mechanism|etiolog(y|ies)|caused by|results? from|pathology|histolog(y|ic)|mutation|risk factors?)\b/i },
  { id: 'classification', name: 'Classification', head: /^(classification|grading|staging|types|grade|categories)\b/i, cue: /\b(classification|classified|grading|grades?\b|types? [IVX0-9]+|staging|scale|score|WHO grade|subtypes?)\b/i },
  { id: 'presentation', name: 'Clinical Presentation', head: /^(clinical|presentation|signs and symptoms|symptoms|clinical features|clinical presentation)\b/i, cue: /\b(present(s|ing|ation)? (with|as)|symptoms?|signs?\b|clinical (features|presentation|findings)|complain(s|t))\b/i },
  { id: 'workup', name: 'Diagnostic Workup', head: /^(evaluation|diagnosis|diagnostic|work-?up|laboratory|diagnostic tests)\b/i, cue: /\b(diagnos(is|tic|ed)|work-?up|evaluation|laboratory|lab(s)?\b|biopsy|lumbar puncture|screening|sensitivity|specificity)\b/i },
  { id: 'radiology', name: 'Radiological Findings', head: /^(imaging|radiographic|radiologic|radiology|ct|mri|neuroimaging|imaging findings)\b/i, cue: /\b(MRI|CT|CTA|MRA|angiogra(m|phy)|x-?rays?|radiograph(s|ic)?|imaging|T1|T2|FLAIR|enhanc(e|es|ing|ement)|DWI|hyperdense|hypodense|hyperintense|hypointense|signal)\b/i },
  { id: 'ddx', name: 'Differential Diagnosis', head: /^(differential|differential diagnosis|ddx)\b/i, cue: /\b(differential diagnosis|differential|distinguish(ed|ing)? from|mimic(s|king)?|DDx)\b/i },
  { id: 'management', name: 'Management', head: /^(treatment|management|therapy|medical management|nonsurgical|conservative|options)\b/i, cue: /\b(management|treatment|treated|therapy|medical management|conservative|observation|chemotherapy|radiation|radiotherapy|radiosurgery|SRS)\b/i },
  { id: 'indications', name: 'Surgical Indications', head: /^(indications?|surgical indications|indications for surgery|surgical treatment|when to operate)\b/i, cue: /\b(indications?|indicated|candidates? for surgery|surgery is (recommended|indicated)|operative (intervention|treatment)|surgical candidates?|contraindicat(ed|ions?))\b/i },
  { id: 'techniques', name: 'Surgical Techniques', head: /^(surgical technique|technique|operative technique|surgical approach|approach|procedure|surgery)\b/i, cue: /\b(technique|approach|craniotomy|laminectomy|fusion|resection|decompression|instrumentation|fixation|endoscopic|microsurgical|clipping|coiling)\b/i },
  { id: 'steps', name: 'Step-by-Step Surgical Procedure', head: /^(operative steps|surgical steps|steps|procedure|technical (pearls|description)|positioning)\b/i, cue: /\b(position(ed|ing)?|incision|burr holes?|dura(l)? (is )?(opened|opening|closure)|closure|retract(or|ed)|drill(ed|ing)?|exposure|is placed|are placed|is then|then)\b/i, numbered: true },
  { id: 'complications', name: 'Complications', head: /^(complications?|adverse events|risks)\b/i, cue: /\b(complications?|adverse|risk of|morbidity|mortality|infection|CSF leak|hematoma|injury to|deficit)\b/i },
  { id: 'postop', name: 'Postoperative Management', head: /^(post-?op(erative)?( care| management)?|after surgery|post-?surgical)\b/i, cue: /\b(post-?op(erative(ly)?)?|after surgery|post-?surgical|in the ICU|drain(s|age)?\b|discharge)\b/i },
  { id: 'followup', name: 'Follow-up', head: /^(follow-?up|outcome|prognosis|surveillance|recurrence|results)\b/i, cue: /\b(follow-?up|surveillance|recurrence|serial (imaging|MRI|CT)|outcomes?|prognosis|survival)\b/i },
  { id: 'pearls', name: 'Important Clinical Pearls', head: /^(key (concepts?|points?)|pearls?|clinical pearls?|practice guidelines?|booklet|caution|summary)\b/i, cue: /\b(key concepts?|pearls?|caution|NB:|note:|practice guidelines?|level (I|II|III)\b|recommendations?|important)\b/i },
];

// Abbreviation expansions used only to widen searches (abbr <-> phrase).
export const ABBREVIATIONS = {
  sah: 'subarachnoid hemorrhage', ich: 'intracerebral hemorrhage', ivh: 'intraventricular hemorrhage', sdh: 'subdural hematoma', edh: 'epidural hematoma', csdh: 'chronic subdural hematoma',
  tbi: 'traumatic brain injury', dai: 'diffuse axonal injury', avm: 'arteriovenous malformation', davf: 'dural arteriovenous fistula', ccm: 'cerebral cavernous malformation',
  gbm: 'glioblastoma', lgg: 'low grade glioma', hgg: 'high grade glioma', vs: 'vestibular schwannoma', cpa: 'cerebellopontine angle', nph: 'normal pressure hydrocephalus',
  iih: 'idiopathic intracranial hypertension', csf: 'cerebrospinal fluid', icp: 'intracranial pressure', cpp: 'cerebral perfusion pressure', gcs: 'glasgow coma scale',
  etv: 'endoscopic third ventriculostomy', evd: 'external ventricular drain', dbs: 'deep brain stimulation', stn: 'subthalamic nucleus', gpi: 'globus pallidus internus',
  mvd: 'microvascular decompression', tn: 'trigeminal neuralgia', acdf: 'anterior cervical discectomy and fusion', accf: 'anterior cervical corpectomy and fusion',
  tlif: 'transforaminal lumbar interbody fusion', plif: 'posterior lumbar interbody fusion', alif: 'anterior lumbar interbody fusion', xlif: 'extreme lateral interbody fusion',
  llif: 'lateral lumbar interbody fusion', olif: 'oblique lumbar interbody fusion', mis: 'minimally invasive surgery', pso: 'pedicle subtraction osteotomy', spo: 'smith petersen osteotomy',
  sva: 'sagittal vertical axis', ais: 'adolescent idiopathic scoliosis', pjk: 'proximal junctional kyphosis', opll: 'ossification of the posterior longitudinal ligament',
  hnp: 'herniated nucleus pulposus', ddd: 'degenerative disc disease', sci: 'spinal cord injury', sciwora: 'spinal cord injury without radiographic abnormality',
  mescc: 'metastatic epidural spinal cord compression', sins: 'spinal instability neoplastic score', tlics: 'thoracolumbar injury classification and severity score',
  slic: 'subaxial injury classification', ces: 'cauda equina syndrome', lp: 'lumbar puncture', mri: 'magnetic resonance imaging', ct: 'computed tomography',
  cta: 'computed tomography angiography', mra: 'magnetic resonance angiography', dsa: 'digital subtraction angiography', dwi: 'diffusion weighted imaging',
  siadh: 'syndrome of inappropriate antidiuretic hormone', csw: 'cerebral salt wasting', di: 'diabetes insipidus', nf1: 'neurofibromatosis type 1', nf2: 'neurofibromatosis type 2',
  srs: 'stereotactic radiosurgery', wbrt: 'whole brain radiation therapy', litt: 'laser interstitial thermal therapy', vns: 'vagus nerve stimulation',
  scs: 'spinal cord stimulation', ssep: 'somatosensory evoked potentials', mep: 'motor evoked potentials', emg: 'electromyography', dci: 'delayed cerebral ischemia',
  cea: 'carotid endarterectomy', tia: 'transient ischemic attack', lvo: 'large vessel occlusion', nihss: 'national institutes of health stroke scale',
  mca: 'middle cerebral artery', aca: 'anterior cerebral artery', pca: 'posterior cerebral artery', ica: 'internal carotid artery', pica: 'posterior inferior cerebellar artery',
  aica: 'anterior inferior cerebellar artery', acom: 'anterior communicating artery', pcom: 'posterior communicating artery', dvt: 'deep vein thrombosis',
  vte: 'venous thromboembolism', ssi: 'surgical site infection', who: 'world health organization', atrt: 'atypical teratoid rhabdoid tumor', dipg: 'diffuse intrinsic pontine glioma',
  mmae: 'middle meningeal artery embolization', vp: 'ventriculoperitoneal', cvj: 'craniovertebral junction', ccj: 'craniocervical junction', ped: 'pipeline embolization device',
};

// Search "focus" filters (diagnosis, procedure, anatomy, classification, technique).
export const FOCUS = {
  diagnosis: { name: 'Diagnosis', cue: /\b(diagnos(is|tic|ed)|differential|presentation|symptoms?|signs?|criteria|evaluation)\b/i },
  procedure: { name: 'Procedure', cue: /\b(procedure|surgery|surgical|operative|incision|resection|decompression|fusion|craniotomy|laminectomy)\b/i },
  anatomy: { name: 'Anatomy', cue: /\b(anatomy|anatomic(al)?|artery|vein|nerve|nucleus|foramen|ligament|landmark)\b/i },
  classification: { name: 'Classification', cue: /\b(classification|grade|grading|scale|score|staging|types?)\b/i },
  technique: { name: 'Surgical technique', cue: /\b(technique|approach|steps?|positioning|instrumentation|screw|exposure|retraction)\b/i },
};

// Quick Reference groups: matched against headings, figure/table captions and outline titles.
export const QUICKREF = [
  { id: 'classifications', name: 'Classifications & grading', re: /\b(classification|grading|grade|scale|score|staging|types of)\b/i },
  { id: 'indications', name: 'Surgical indications', re: /\bindications?\b/i, not: /contraindic/i },
  { id: 'contraindications', name: 'Contraindications', re: /contraindic/i },
  { id: 'measurements', name: 'Measurements & landmarks', re: /\b(landmarks?|measurements?|normal values|dimensions|distances?|angles?|normal (range|limits))\b/i },
  { id: 'approaches', name: 'Surgical approaches', re: /\bapproach(es)?\b/i },
  { id: 'steps', name: 'Surgical steps', re: /\b(technique|operative steps|surgical steps|procedure|positioning)\b/i },
  { id: 'complications', name: 'Complications', re: /\bcomplications?\b/i },
  { id: 'ddx', name: 'Differential diagnosis', re: /\bdifferential\b/i },
  { id: 'criteria', name: 'Diagnostic criteria', re: /\bcriteria\b/i },
  { id: 'algorithms', name: 'Decision algorithms', re: /\b(algorithm|flowchart|flow chart|decision|management of)\b/i },
  { id: 'exam', name: 'Examination findings', re: /\b(examination|exam\b|physical findings|signs?\b|reflex(es)?|tests?\b)\b/i },
];

// Figure caption modality tags.
export const IMAGE_KINDS = [
  { id: 'mri', name: 'MRI', re: /\b(MRI|MR\b|T1|T2|FLAIR|magnetic resonance|DWI|STIR)\b/i },
  { id: 'ct', name: 'CT', re: /\b(CT|computed tomography|CTA)\b/ },
  { id: 'xray', name: 'X-ray', re: /\b(x-?rays?|radiographs?|plain films?|AP view|lateral view|flexion|extension view)\b/i },
  { id: 'angio', name: 'Angiography', re: /\b(angiogra(m|ms|phy|phic)|DSA|arteriogra)/i },
  { id: 'illustration', name: 'Anatomical illustration', re: /\b(illustration|schematic|drawing|diagram|anatom(y|ic|ical))\b/i },
  { id: 'approach', name: 'Surgical approach', re: /\b(approach|incision|exposure|craniotomy|positioning|skin flap|bone flap|trajectory)\b/i },
  { id: 'intraop', name: 'Intraoperative', re: /\b(intra-?operative|operative (view|photograph|image)|microscop(e|ic) view|surgical view|endoscopic view)\b/i },
  { id: 'instrument', name: 'Instrumentation', re: /\b(screws?|rods?|cages?|plates?|instrument(s|ation)?|implants?|hardware|device)\b/i },
  { id: 'classification', name: 'Classification diagram', re: /\b(classification|grading|grade|types?\b|scale)\b/i },
  { id: 'table', name: 'Table / flowchart', re: /^(table)|\b(algorithm|flowchart|flow chart)\b/i },
];

export const HIGHLIGHT_COLORS = [
  { id: 'yellow', name: 'Yellow', css: 'rgba(250, 204, 21, 0.42)' },
  { id: 'green', name: 'Green', css: 'rgba(74, 222, 128, 0.40)' },
  { id: 'blue', name: 'Blue', css: 'rgba(96, 165, 250, 0.40)' },
  { id: 'pink', name: 'Pink', css: 'rgba(244, 114, 182, 0.40)' },
  { id: 'orange', name: 'Orange', css: 'rgba(251, 146, 60, 0.42)' },
];

export const HIGHLIGHT_LABELS = ['Surgical step', 'Classification', 'Contraindication', 'Complication', 'Clinical pearl', 'Indication', 'Definition', 'Other'];

// Words that make an outline entry a poor topic suggestion.
export const OUTLINE_SKIP = /^(index|contents|table of contents|references?|bibliography|preface|forewords?|acknowledg|copyright|dedication|contributors|abbreviations|conventions|title( page)?|cover|front ?matter|back ?matter|videos?|appendix|introduction|questions?|answers?|answers? and explanations|explanations?|further reading|suggested reading|summary|conclusions?|key points|part [ivxlc]+\b|section \d+|chapter \d+$|\d+(\.\d+)*$)/i;
