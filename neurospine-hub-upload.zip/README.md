# Neurosurgery & Spine Knowledge Hub

A personal reference library that runs entirely in the browser. Upload your own PDFs; the site extracts their text, outline, page numbers and figure captions, sorts pages into neurosurgery and spine topics, and lets you search, highlight, bookmark, take notes and make flashcards. Every passage links back to its document and page.

- Your PDFs, notes and highlights stay in your browser on your device. Nothing is uploaded to this repository or any server.
- Optional AI features use your own Claude API key, entered in Settings, and call the Claude API directly from your device.
- PDF rendering uses pdf.js (Mozilla, Apache-2.0) and PDF export uses pdf-lib (MIT), both loaded from public CDNs.

Published with GitHub Pages: Settings › Pages › Deploy from a branch › `main` / `(root)`.
