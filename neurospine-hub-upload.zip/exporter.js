// Exports (Markdown, JSON, PDF) and backup / restore.
import { Lib } from './library.js';
import { Store } from './store.js';
import { S, saveFile, toast, fmtDate } from './core.js';
import { SECTIONS } from './taxonomy.js';

let pdfLibP = null;
function loadPdfLib() {
  if (window.PDFLib) return Promise.resolve(window.PDFLib);
  if (!pdfLibP) pdfLibP = new Promise((res, rej) => { const s = document.createElement('script'); s.src = /^(127\.0\.0\.1|localhost)$/.test(location.hostname) ? new URL('./lib/pdf-lib.min.js', import.meta.url).href : 'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js'; s.onload = () => res(window.PDFLib); s.onerror = rej; document.head.appendChild(s); });
  return pdfLibP;
}
// Standard PDF fonts only cover Windows-1252; map the common medical symbols.
const MAP = { '≥': '>=', '≤': '<=', '≈': '~', '≠': '!=', '→': '->', '←': '<-', '↑': '(up)', '↓': '(down)', '↔': '<->', 'α': 'alpha', 'β': 'beta', 'γ': 'gamma', 'δ': 'delta', 'κ': 'kappa', 'λ': 'lambda', 'θ': 'theta', 'Δ': 'Delta', '●': '•', '○': 'o', '■': '•', '□': '[ ]', '✓': 'v', '✔': 'v', '⚠': '!', '′': "'", '″': '"', '−': '-', '‐': '-', '‑': '-', '⁄': '/', '∼': '~', '∶': ':', '★': '*', ' ': ' ', '\t': '    ' };
const CP1252 = new Set('€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ');
const clean = s => [...String(s ?? '')].map(ch => { if (MAP[ch]) return MAP[ch]; const c = ch.codePointAt(0); if (c === 10) return '\n'; if ((c >= 32 && c <= 126) || (c >= 160 && c <= 255) || CP1252.has(ch)) return ch; return c < 32 ? '' : '?'; }).join('');

async function buildPdf(title, blocks) {
  const { PDFDocument, StandardFonts, rgb } = await loadPdfLib();
  const doc = await PDFDocument.create();
  const fonts = { body: await doc.embedFont(StandardFonts.TimesRoman), bold: await doc.embedFont(StandardFonts.HelveticaBold), sans: await doc.embedFont(StandardFonts.Helvetica), ital: await doc.embedFont(StandardFonts.TimesRomanItalic) };
  const W = 595, H = 842, M = 56; let page = doc.addPage([W, H]); let y = H - M;
  const newPage = () => { page = doc.addPage([W, H]); y = H - M; };
  const write = (text, { font = 'body', size = 11, color = [0.06, 0.1, 0.16], gap = 4, indent = 0 } = {}) => {
    const f = fonts[font]; const maxW = W - 2 * M - indent;
    for (const para of clean(text).split('\n')) {
      const words = para.split(/ +/); let line = '';
      const flush = () => { if (y < M + size) newPage(); page.drawText(line, { x: M + indent, y: y - size, size, font: f, color: rgb(...color) }); y -= size * 1.35; line = ''; };
      for (const w of words) { const test = line ? line + ' ' + w : w; if (f.widthOfTextAtSize(test, size) > maxW && line) { flush(); line = w; } else line = test; }
      if (line || !para) flush();
    }
    y -= gap;
  };
  write(title, { font: 'bold', size: 18, gap: 6 });
  write(`Exported ${fmtDate(Date.now())} from Neurosurgery & Spine Knowledge Hub. All quoted text is from the uploaded PDFs; citations give document and page.`, { font: 'sans', size: 9, color: [0.35, 0.4, 0.46], gap: 14 });
  for (const b of blocks) {
    if (b.h) { if (y < M + 60) newPage(); y -= 6; write(b.h, { font: 'bold', size: b.level === 2 ? 12 : 14, gap: 4 }); }
    if (b.quote) write(b.quote, { font: 'body', size: 10.5, indent: 12, gap: 2 });
    if (b.note) write('Note: ' + b.note, { font: 'ital', size: 10.5, indent: 12, gap: 2 });
    if (b.cite) write(b.cite, { font: 'sans', size: 8.5, color: [0.04, 0.42, 0.5], indent: 12, gap: 10 });
    if (b.text) write(b.text, { font: 'body', size: 10.5, gap: 6 });
  }
  return doc.save();
}
const safeName = s => s.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').slice(0, 60) || 'export';

export async function exportNotes(list, fmt) {
  if (!list.length) { toast('No highlights match the current filters.', 'bad'); return; }
  const date = new Date().toISOString().slice(0, 10);
  if (fmt === 'json') {
    const data = JSON.stringify(list.map(a => ({ quote: a.quote, note: a.note, label: a.label, color: a.color, document: Lib.docName(a.docId), page: Lib.label(a.docId, a.p), pdfPage: a.p + 1, created: new Date(a.createdAt).toISOString() })), null, 2);
    return saveFile(`notes-${date}.json`, data, data);
  }
  if (fmt === 'md') {
    let md = `# My highlights and notes\n\n_Exported ${date}. Quotes are verbatim from the uploaded PDFs._\n`; let last = null;
    for (const a of list) { if (a.docId !== last) { md += `\n## ${Lib.docName(a.docId)}\n`; last = a.docId; } md += `\n> ${a.quote.replace(/\n/g, ' ')}\n\n— ${Lib.cite(a.docId, a.p)}${a.label ? ` · ${a.label}` : ''}\n${a.note ? `\n**Note:** ${a.note}\n` : ''}`; }
    return saveFile(`notes-${date}.md`, md, md);
  }
  const blocks = []; let last = null;
  for (const a of list) { if (a.docId !== last) { blocks.push({ h: Lib.docName(a.docId) }); last = a.docId; } blocks.push({ quote: '"' + a.quote + '"', note: a.note, cite: Lib.cite(a.docId, a.p) + (a.label ? ' · ' + a.label : '') }); }
  const bytes = await buildPdf('My highlights and notes', blocks);
  return saveFile(`notes-${date}.pdf`, new Blob([bytes], { type: 'application/pdf' }));
}

export async function exportTopicPdf(id) {
  const c = Lib.topicContent(id); if (!c) return;
  const blocks = [];
  if (!c.pages.length) blocks.push({ text: 'Information not found in the uploaded sources.' });
  for (const s of c.sections) {
    blocks.push({ h: (SECTIONS.findIndex(x => x.id === s.id) + 1) + '. ' + s.name });
    const ai = S.ai.get(`topic:${id}:${s.id}`.replace(/[^A-Za-z0-9_\-.~:@+]/g, '_'));
    if (ai) blocks.push({ h: 'Cited summary (AI-organized)', level: 2 }, { text: ai.text.replace(/\[S(\d+)\]/g, (m, k) => { const src = ai.sources[+k - 1]; return src ? ` [${Lib.shortName(src.docId)} p. ${Lib.label(src.docId, src.p)}]` : ''; }) });
    for (const pa of s.items) blocks.push({ quote: pa.text, cite: Lib.cite(pa.docId, pa.p) });
  }
  blocks.push({ h: '17. References and original PDF pages' });
  for (const r of Lib.refList(c.pages.map(x => x[0]))) blocks.push({ text: Lib.docName(r.docId) + ': pp. ' + r.runs.map(([a, b]) => Lib.label(r.docId, a) + (b > a ? '-' + Lib.label(r.docId, b) : '')).join(', ') });
  const notes = S.ann.filter(a => (a.topics || []).includes(id));
  if (notes.length) { blocks.push({ h: 'My highlights on this topic' }); for (const a of notes) blocks.push({ quote: '"' + a.quote + '"', note: a.note, cite: Lib.cite(a.docId, a.p) }); }
  const bytes = await buildPdf(c.topic.name, blocks);
  return saveFile(`${safeName(c.topic.name)}.pdf`, new Blob([bytes], { type: 'application/pdf' }));
}

export async function exportBackup() {
  const data = { app: 'nsh-knowledge-hub', version: 1, exportedAt: new Date().toISOString(),
    docs: [...S.docs.values()].map(({ ocr, imagePages, _missing, ...d }) => d), ann: S.ann, bm: S.bm, cards: S.cards, qref: S.qcards, cols: S.cols,
    prefs: S.prefs, topicStatus: S.topicStatus, favorites: S.favorites, history: S.history, taxonomy: Lib.taxonomy };
  const txt = JSON.stringify(data);
  return saveFile(`knowledge-hub-backup-${data.exportedAt.slice(0, 10)}.json`, txt, txt);
}
export async function importBackup(data) {
  if (data?.app !== 'nsh-knowledge-hub') throw new Error('not a Knowledge Hub backup');
  let count = 0;
  for (const [col, arr] of [['ann', data.ann], ['bm', data.bm], ['cards', data.cards], ['qref', data.qref], ['cols', data.cols], ['docs', data.docs]]) {
    for (const item of arr || []) { if (!item?.id) continue; if (col === 'docs' && S.docs.has(item.id)) continue; await Store.put(col, item.id, item); count++; }
  }
  for (const k of ['prefs', 'topicStatus', 'favorites', 'history']) if (data[k]) await Store.setS(k, data[k]);
  if (data.taxonomy) await Store.setS('taxonomy', { tree: data.taxonomy });
  return count;
}
