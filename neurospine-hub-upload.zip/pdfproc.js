// PDF loading, extraction and rendering (pdf.js, running in the browser).
import { Store, local } from './store.js';

// pdf.js (Mozilla, Apache-2.0) loads from jsDelivr at a pinned version. A local copy is
// used only when the page is served from this machine for development tests.
const DEV = /^(127\.0\.0\.1|localhost)$/.test(location.hostname);
const CDN = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/legacy/build/';
let pdfjsLib = null;
try {
  pdfjsLib = await import(DEV ? './lib/pdf.min.js' : CDN + 'pdf.min.mjs');
  const WORKER = DEV ? new URL('./lib/pdf.worker.min.js', import.meta.url).href : CDN + 'pdf.worker.min.mjs';
  pdfjsLib.GlobalWorkerOptions.workerSrc = WORKER;
  // A cross-origin worker script can't be started directly; a same-origin blob: module imports it.
  try { pdfjsLib.GlobalWorkerOptions.workerPort = new Worker(URL.createObjectURL(new Blob([`import "${WORKER}";`], { type: 'text/javascript' })), { type: 'module' }); }
  catch (e) { console.warn('pdf.js worker wrapper failed; pdf.js will choose its own worker', e); }
} catch (e) { console.error('The PDF engine could not be loaded', e); }
const WASM_URL = DEV ? new URL('./lib/wasm/', import.meta.url).href : undefined;
export { pdfjsLib };
function engine() { if (!pdfjsLib) throw Object.assign(new Error('The PDF engine could not be loaded. Check your internet connection and reload the page.'), { code: 'no_engine' }); return pdfjsLib; }

export const CHUNK = 4 * 1024 * 1024;
const HDR = new TextEncoder().encode('%PDF-1.7\n%NSH-PART\n');
export const HDR_LEN = HDR.length;

// ---------- byte sources ----------
export function blobSource(blob) {
  return { size: blob.size, read: async (b, e) => new Uint8Array(await blob.slice(b, e).arrayBuffer()) };
}

export function cloudSource(meta) {
  const offs = []; let o = 0;
  for (const c of meta.chunks) { offs.push(o); o += c.n; }
  const cache = new Map();
  const chunk = (i) => {
    if (!cache.has(i)) {
      const p = Store.fetchAsset(meta.chunks[i].id).then(r => r.arrayBuffer()).then(b => new Uint8Array(b, meta.hdr || 0));
      cache.set(i, p); p.catch(() => cache.delete(i));
      if (cache.size > 8) cache.delete(cache.keys().next().value);
    }
    return cache.get(i);
  };
  const find = (pos) => { let lo = 0, hi = offs.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (offs[m] <= pos) lo = m; else hi = m - 1; } return lo; };
  return {
    size: meta.size,
    async read(b, e) {
      const out = new Uint8Array(e - b); let pos = b;
      while (pos < e) {
        const i = find(pos); const c = await chunk(i);
        const start = pos - offs[i]; const len = Math.min(c.length - start, e - pos);
        if (len <= 0) throw new Error('chunk underflow');
        out.set(c.subarray(start, start + len), pos - b); pos += len;
      }
      return out;
    },
  };
}

let SourceTransport = null;
function transportFor(src) {
  if (!SourceTransport) SourceTransport = class extends engine().PDFDataRangeTransport {
    constructor(s) { super(s.size, null); this.src = s; }
    requestDataRange(begin, end) { this.src.read(begin, end).then(u => this.onDataRange(begin, u)).catch(err => console.error('range read failed', err)); }
  };
  return new SourceTransport(src);
}

export function closePdf(pdf) { try { pdf?.__task?.destroy(); } catch { /* ignore */ } }
export async function openSource(src) {
  const task = engine().getDocument({
    range: transportFor(src), length: src.size, rangeChunkSize: 1 << 18,
    disableAutoFetch: true, disableStream: true, isEvalSupported: false, ...(WASM_URL ? { wasmUrl: WASM_URL } : {}),
    useSystemFonts: true, enableXfa: false,
  });
  const pdf = await task.promise; pdf.__task = task; return pdf;
}

// ---------- document cache: local file, else cloud parts ----------
const open = new Map();
export async function getPdf(meta) {
  if (open.has(meta.id)) return open.get(meta.id);
  const p = (async () => {
    const blob = await local.get('files', meta.id);
    if (blob) return { pdf: await openSource(blobSource(blob)), where: 'device' };
    if (meta.chunks?.length) return { pdf: await openSource(cloudSource(meta)), where: 'cloud' };
    throw Object.assign(new Error('Original PDF not available here'), { code: 'no_pdf' });
  })();
  open.set(meta.id, p);
  p.catch(() => open.delete(meta.id));
  if (open.size > 4) { const k = open.keys().next().value; if (k !== meta.id) { open.get(k)?.then(o => closePdf(o.pdf)).catch(() => {}); open.delete(k); } }
  return p;
}
export function forgetPdf(id) { const p = open.get(id); if (p) { p.then(o => closePdf(o.pdf)).catch(() => {}); open.delete(id); } }

// ---------- text extraction ----------
const CAPTION_RE = /^(Fig(?:ure)?s?\.?\s*\d+(?:[.\-–]\d+)*[a-z]?|Table\s+\d+(?:[.\-–]\d+)*[a-z]?|Algorithm\s+\d+(?:[.\-–]\d+)*)\b/i;

export function buildLines(items) {
  const lines = []; let cur = null; let lastY = null; let lastEndX = null;
  const flush = () => { if (cur && cur.s.trim()) { cur.s = cur.s.replace(/\s+/g, ' ').trim(); lines.push(cur); } cur = null; lastEndX = null; };
  for (const it of items) {
    if (typeof it.str !== 'string') continue;
    const t = it.transform; const x = t[4], y = t[5];
    const h = Math.hypot(t[2], t[3]) || it.height || 0;
    if (cur && lastY !== null && Math.abs(y - lastY) > Math.max(1.5, h * 0.45)) flush();
    if (!cur) cur = { s: '', h: 0, n: 0 };
    if (it.str) {
      if (lastEndX !== null && x - lastEndX > h * 0.18 && !cur.s.endsWith(' ') && !it.str.startsWith(' ')) cur.s += ' ';
      cur.s += it.str;
      if (it.str.trim()) { cur.h = Math.max(cur.h, h); cur.n += it.str.length; }
      lastEndX = x + (it.width || 0);
      lastY = y;
    }
    if (it.hasEOL) flush();
  }
  flush();
  return lines;
}

function headingLines(lines) {
  const sizes = []; for (const l of lines) for (let k = 0; k < Math.min(l.n, 200); k += 20) sizes.push(l.h);
  sizes.sort((a, b) => a - b);
  const med = sizes.length ? sizes[sizes.length >> 1] : 0;
  const out = [];
  lines.forEach((l, i) => {
    const s = l.s;
    if (s.length < 3 || s.length > 110 || !/[A-Za-z]{3}/.test(s)) return;
    if (/^[\d\s.,-]+$/.test(s)) return;
    const big = med && l.h >= med * 1.12;
    const shortLabel = s.length <= 60 && !/[.;,]$/.test(s) && /^[A-Z][A-Za-z0-9’'()/&+,\- ]{2,58}(:\s?[A-Za-z0-9 ’'()/&+-]{1,30})?$/.test(s) && med && l.h >= med * 0.98 && i < lines.length - 1;
    if (big || (shortLabel && /^(definition|overview|introduction|epidemiology|etiology|pathophysiology|pathogenesis|pathology|classification|grading|clinical|presentation|signs|symptoms|evaluation|diagnosis|imaging|differential|treatment|management|indications?|contraindications?|technique|surgical|operative|procedure|positioning|complications?|post-?operative|follow-?up|outcome|prognosis|key concepts?|pearls?|anatomy|radiographic|natural history|risk factors|recurrence)\b/i.test(s))) out.push([i, s]);
  });
  return out;
}

function captionsFrom(lines, pageIdx) {
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const m = CAPTION_RE.exec(lines[i].s);
    if (!m) continue;
    let cap = lines[i].s; let j = i + 1;
    while (j < lines.length && cap.length < 260 && j - i < 4 && !CAPTION_RE.test(lines[j].s) && !/(ISBN|©|\bet al\.,|^\d{1,4}$)/.test(lines[j].s)) { cap += ' ' + lines[j].s; j++; }
    cap = cap.replace(/\s*\d{0,4}\s*[A-Z][a-z]+ et al\.,.*$/, '').replace(/\s*\(ISBN.*$/, '');
    const label = m[1].replace(/\s+/g, ' ').replace(/^Figs?\.?\s*/i, 'Fig. ').replace(/^Figure\s*/i, 'Fig. ');
    out.push({ p: pageIdx, label, cap: cap.slice(0, 320), kind: /^table/i.test(label) ? 'table' : (/^algorithm/i.test(label) ? 'algorithm' : 'figure') });
  }
  return out;
}

async function flattenOutline(pdf) {
  let tree = null;
  try { tree = await pdf.getOutline(); } catch { return []; }
  if (!tree) return [];
  const out = [];
  const resolve = async (dest) => {
    try {
      let d = dest;
      if (typeof d === 'string') d = await pdf.getDestination(d);
      if (!Array.isArray(d) || !d[0]) return -1;
      if (typeof d[0] === 'number') return d[0];
      return await pdf.getPageIndex(d[0]);
    } catch { return -1; }
  };
  const walk = async (items, level) => {
    for (const it of items) {
      const entry = { t: (it.title || '').replace(/&[a-z0-9_]+;/gi, ' ').replace(/\s+/g, ' ').trim(), p: await resolve(it.dest), l: level };
      out.push(entry);
      if (it.items?.length) await walk(it.items, level + 1);
    }
  };
  await walk(tree, 0);
  for (let i = out.length - 1; i >= 0; i--) {
    if (out[i].p < 0) { for (let j = i + 1; j < out.length && out[j].l > out[i].l; j++) if (out[j].p >= 0) { out[i].p = out[j].p; break; } }
  }
  return out;
}

export async function thumbnail(pdf, pageNum = 1, width = 180) {
  const page = await pdf.getPage(pageNum);
  const vp0 = page.getViewport({ scale: 1 });
  const vp = page.getViewport({ scale: width / vp0.width });
  const c = document.createElement('canvas'); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
  const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, canvas: c, viewport: vp }).promise;
  return c.toDataURL('image/jpeg', 0.72);
}

// Extract everything the library needs from one PDF. Resumable through `partial`.
export async function extractPdf(file, { onProgress, partial, onCheckpoint, signal } = {}) {
  const pdf = await openSource(blobSource(file));
  try {
    const n = pdf.numPages;
    const fingerprint = pdf.fingerprints?.[0] || null;
    onProgress?.({ stage: 'Reading structure', done: 0, total: n });
    const labels = await pdf.getPageLabels().catch(() => null);
    const outline = await flattenOutline(pdf);
    let thumb = null; try { thumb = await thumbnail(pdf, 1); } catch { /* optional */ }
    const pages = partial?.pages || new Array(n).fill(null);
    const heads = partial?.heads || {};
    const figs = partial?.figs || [];
    const empty = partial?.empty || [];
    const start = partial?.next || 0;
    for (let i = start; i < n; i++) {
      if (signal?.aborted) throw Object.assign(new Error('cancelled'), { code: 'cancelled' });
      const page = await pdf.getPage(i + 1);
      const tc = await page.getTextContent();
      const lines = buildLines(tc.items);
      pages[i] = lines.map(l => l.s).join('\n');
      const hd = headingLines(lines); if (hd.length) heads[i] = hd;
      for (const f of captionsFrom(lines, i)) figs.push(f);
      if (pages[i].replace(/\s/g, '').length < 25) empty.push(i);
      page.cleanup();
      if (i % 10 === 0 || i === n - 1) onProgress?.({ stage: 'Extracting text', done: i + 1, total: n });
      if (onCheckpoint && (i + 1) % 150 === 0) await onCheckpoint({ pages, heads, figs, empty, next: i + 1 });
    }
    const printed = inferPrintedLabels(pages);
    stripBoilerplate(pages, heads);
    const outline2 = augmentOutline(outline, heads, n, pages);
    // Pages without a text layer: check whether an image covers them (scanned page -> OCR candidate).
    const scanned = [];
    for (const i of empty.slice(0, 400)) {
      try {
        const page = await pdf.getPage(i + 1);
        const boxes = await imageBoxes(page);
        const vp = page.getViewport({ scale: 1 });
        const area = boxes.reduce((a, b) => a + b.w * b.h, 0) / (vp.width * vp.height);
        if (area > 0.35) scanned.push(i);
        page.cleanup();
      } catch { /* ignore */ }
    }
    const pdfLabels = labels && labels.some((l, k) => l !== String(k + 1)) ? labels : null;
    return { numPages: n, fingerprint, labels: pdfLabels || printed, labelSource: pdfLabels ? 'pdf' : (printed ? 'printed' : null), outline: outline2, thumb, pages, heads, figs, scanned };
  } finally {
    closePdf(pdf);
  }
}

// Remove running headers/footers, page numbers and margin tabs (text repeated at the
// top or bottom of many pages). Headings are never removed.
function stripBoilerplate(pages, heads) {
  const n = pages.length; const cnt = new Map(); const digitCnt = new Map();
  const key = s => s.toLowerCase().replace(/\d+/g, '#').replace(/\s+/g, ' ').trim();
  const split = pages.map(t => (t || '').split('\n'));
  const cand = L => [...new Set([0, 1, 2, L - 1, L - 2, L - 3, L - 4, L - 5].filter(i => i >= 0 && i < L))];
  split.forEach(lines => {
    const seen = new Set();
    for (const i of cand(lines.length)) { const k = key(lines[i]); if (k && !seen.has(k)) { seen.add(k); cnt.set(k, (cnt.get(k) || 0) + 1); } }
    for (const l of lines) if (/^\s*\d{1,4}\s*$/.test(l)) digitCnt.set(l.trim(), (digitCnt.get(l.trim()) || 0) + 1);
  });
  const thr = Math.max(5, Math.round(n * 0.03));
  split.forEach((lines, p) => {
    const hs = new Set((heads[p] || []).map(h => h[0])); const drop = new Set();
    for (const i of cand(lines.length)) {
      if (hs.has(i)) continue; const l = lines[i].trim(); const k = key(l); const c = cnt.get(k) || 0;
      if (/^[#\s]*$/.test(k) || /^[ivxlcdm]{1,7}$/i.test(l) || c >= thr || (c >= 3 && (/\s\d{1,4}$/.test(l) || /^\d{1,4}\s/.test(l)))) drop.add(i);
    }
    lines.forEach((l, i) => { if (!hs.has(i) && /^\s*\d{1,4}\s*$/.test(l) && (digitCnt.get(l.trim()) || 0) >= 3) drop.add(i); });
    if (!drop.size) return;
    const map = []; const kept = [];
    lines.forEach((l, i) => { if (!drop.has(i)) { map[i] = kept.length; kept.push(l); } });
    pages[p] = kept.join('\n');
    if (heads[p]) { heads[p] = heads[p].map(([i, t]) => [map[i], t]).filter(h => h[0] !== undefined); if (!heads[p].length) delete heads[p]; }
  });
}

// Printed page numbers. Numbers at the top or bottom of a page count as the printed page
// number only when neighbouring pages carry numbers that increase in step with them, so
// chapter tabs and other constants are ignored and inserted pages are handled.
function inferPrintedLabels(pages) {
  const n = pages.length;
  const C = pages.map(t => {
    const lines = (t || '').split('\n'); const L = lines.length; const nums = new Set();
    for (const i of [0, 1, 2, L - 1, L - 2, L - 3, L - 4, L - 5]) { if (i < 0 || i >= L) continue; const l = lines[i].trim(); let m; if ((m = /^(\d{1,4})\b/.exec(l))) nums.add(+m[1]); if ((m = /\b(\d{1,4})$/.exec(l))) nums.add(+m[1]); }
    return nums;
  });
  const lab = new Array(n).fill(null); let found = 0;
  for (let p = 0; p < n; p++) {
    let best = null, bs = 0;
    for (const v of C[p]) {
      if (v < 1) continue; const d = p + 1 - v; let sup = 0;
      for (let q = Math.max(0, p - 8); q <= Math.min(n - 1, p + 8); q++) if (q !== p && C[q].has(q + 1 - d)) sup++;
      if (sup > bs) { bs = sup; best = v; }
    }
    if (bs >= 3) { lab[p] = best; found++; }
  }
  if (found < Math.max(10, n * 0.2)) return null;
  // fill gaps when the numbered pages on both sides agree on the offset
  let prev = -1;
  for (let p = 0; p < n; p++) {
    if (lab[p] == null) continue;
    if (prev >= 0 && p - prev > 1 && (prev + 1 - lab[prev]) === (p + 1 - lab[p])) for (let q = prev + 1; q < p; q++) lab[q] = q + 1 - (p + 1 - lab[p]);
    prev = p;
  }
  return lab.map(v => v == null ? null : String(v));
}
function looksListing(t) {
  const lines = (t || '').split('\n').filter(l => l.trim()); if (lines.length < 12) return false;
  let k = 0; for (const l of lines) if (/[A-Za-z].*[\s,.]\d{1,4}(\s*[-–]\s*\d{1,4})?\s*$/.test(l)) k++;
  return k / lines.length >= 0.5;
}

// When a PDF's bookmarks are missing or broken, add chapters found from numbered headings.
function augmentOutline(outline, heads, n, pages) {
  const ok = outline.filter(e => e.p >= 0);
  if (ok.length >= n / 15) return ok;
  const maxL = ok.reduce((m, e) => Math.max(m, e.l), 0);
  const seen = new Set(); let lastNum = 0; const add = [];
  for (const p of Object.keys(heads).map(Number).sort((a, b) => a - b)) {
    const hs = heads[p]; if (looksListing(pages[p])) continue;
    for (let k = 0; k < hs.length; k++) {
      const [i, t] = hs[k]; if (i > 3) break; if (/\s\d{1,4}$/.test(t)) continue;
      const m = /^(\d{1,3})\s+([A-Z][^]{2,})$/.exec(t); if (!m) continue;
      const num = +m[1]; if (seen.has(num) || num < lastNum || num > lastNum + 5) continue;
      let title = t; const nx = hs[k + 1];
      if (nx && nx[0] === i + 1 && !/^\d/.test(nx[1]) && nx[1].length < 60 && !/^(questions|answers|references)$/i.test(nx[1])) title += ' ' + nx[1];
      if (/\s\d{1,4}$/.test(title)) continue;
      seen.add(num); lastNum = num; add.push({ t: title, p, l: maxL + 1, syn: true }); break;
    }
  }
  if (add.length < 3) return ok;
  return [...ok, ...add].map((e, k) => ({ ...e, k })).sort((a, b) => a.p - b.p || a.l - b.l || a.k - b.k).map(({ k, ...e }) => e);
}

// ---------- images on a page (bounding boxes from the operator list) ----------
function mul(m, n) { return [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]]; }
export async function imageBoxes(page) {
  const ops = await page.getOperatorList();
  const O = engine().OPS;
  const paint = new Set([O.paintImageXObject, O.paintInlineImageXObject, O.paintImageMaskXObject, O.paintImageXObjectRepeat, O.paintInlineImageXObjectGroup].filter(v => v !== undefined));
  let ctm = [1, 0, 0, 1, 0, 0]; const stack = []; const boxes = [];
  for (let i = 0; i < ops.fnArray.length; i++) {
    const fn = ops.fnArray[i], a = ops.argsArray[i];
    if (fn === O.save) stack.push(ctm);
    else if (fn === O.restore) ctm = stack.pop() || [1, 0, 0, 1, 0, 0];
    else if (fn === O.transform) ctm = mul(ctm, a);
    else if (fn === O.paintFormXObjectBegin) { stack.push(ctm); if (Array.isArray(a?.[0]) && a[0].length === 6) ctm = mul(ctm, a[0]); }
    else if (fn === O.paintFormXObjectEnd) ctm = stack.pop() || [1, 0, 0, 1, 0, 0];
    else if (paint.has(fn)) {
      const pts = [[0, 0], [1, 0], [0, 1], [1, 1]].map(([x, y]) => [ctm[0] * x + ctm[2] * y + ctm[4], ctm[1] * x + ctm[3] * y + ctm[5]]);
      const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
      const b = { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
      if (b.w > 4 && b.h > 4) boxes.push(b);
    }
  }
  // merge overlapping / touching boxes (tiles of one figure)
  const merged = [];
  for (const b of boxes) {
    let m = merged.find(o => !(b.x > o.x + o.w + 6 || o.x > b.x + b.w + 6 || b.y > o.y + o.h + 6 || o.y > b.y + b.h + 6));
    if (m) { const x2 = Math.max(m.x + m.w, b.x + b.w), y2 = Math.max(m.y + m.h, b.y + b.h); m.x = Math.min(m.x, b.x); m.y = Math.min(m.y, b.y); m.w = x2 - m.x; m.h = y2 - m.y; }
    else merged.push({ ...b });
  }
  return merged; // PDF user-space coordinates (origin bottom-left)
}

// Render a page (or a crop of it) to a canvas.
export async function renderPage(pdf, pageNum, canvas, { scale = 1.5, crop = null, maxPixels = 16e6 } = {}) {
  const page = await pdf.getPage(pageNum);
  let vp = page.getViewport({ scale });
  if (vp.width * vp.height > maxPixels) vp = page.getViewport({ scale: scale * Math.sqrt(maxPixels / (vp.width * vp.height)) });
  const ctx = canvas.getContext('2d');
  if (crop) {
    const T = vp.transform; const pt = (x, y) => [T[0] * x + T[2] * y + T[4], T[1] * x + T[3] * y + T[5]];
    const [x1, y1] = pt(crop.x, crop.y); const [x2, y2] = pt(crop.x + crop.w, crop.y + crop.h);
    const rx = Math.max(0, Math.min(x1, x2) - 4), ry = Math.max(0, Math.min(y1, y2) - 4);
    const rw = Math.min(vp.width - rx, Math.abs(x2 - x1) + 8), rh = Math.min(vp.height - ry, Math.abs(y2 - y1) + 8);
    canvas.width = Math.ceil(rw); canvas.height = Math.ceil(rh);
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, canvas, viewport: vp, transform: [1, 0, 0, 1, -rx, -ry] }).promise;
  } else {
    canvas.width = Math.ceil(vp.width); canvas.height = Math.ceil(vp.height);
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, canvas, viewport: vp }).promise;
  }
  return { page, viewport: vp };
}

// ---------- cloud upload of the original PDF in parts ----------
export async function uploadOriginal(file, onProgress, signal) {
  const chunks = [];
  const total = Math.ceil(file.size / CHUNK);
  for (let i = 0; i < total; i++) {
    if (signal?.aborted) throw Object.assign(new Error('cancelled'), { code: 'cancelled' });
    const part = file.slice(i * CHUNK, Math.min(file.size, (i + 1) * CHUNK));
    const blob = new Blob([HDR, part], { type: 'application/pdf' });
    const r = await Store.upload(blob, 'application/pdf');
    chunks.push({ id: r.id, n: part.size });
    onProgress?.({ stage: 'Storing original PDF', done: i + 1, total });
  }
  return { chunks, hdr: HDR_LEN, size: file.size };
}

// Text pack: JSON asset(s), split so each stays well under the 20 MiB limit.
export async function uploadPack(pack) {
  const { pages, ...rest } = pack;
  const parts = []; let cur = []; let size = 0; let first = 0;
  const flush = async () => {
    const blob = new Blob([JSON.stringify({ first, pages: cur })], { type: 'application/json' });
    const r = await Store.upload(blob, 'application/json');
    parts.push({ id: r.id, first, count: cur.length });
    first += cur.length; cur = []; size = 0;
  };
  for (const t of pages) { const s = (t || '').length * 1.1 + 8; if (size + s > 12e6 && cur.length) await flush(); cur.push(t); size += s; }
  if (cur.length) await flush();
  const metaBlob = new Blob([JSON.stringify(rest)], { type: 'application/json' });
  const m = await Store.upload(metaBlob, 'application/json');
  return { meta: m.id, parts };
}

export async function downloadPack(ref) {
  const meta = await (await Store.fetchAsset(ref.meta)).json();
  const pages = [];
  for (const p of ref.parts) { const j = await (await Store.fetchAsset(p.id)).json(); for (let k = 0; k < j.pages.length; k++) pages[j.first + k] = j.pages[k]; }
  return { ...meta, pages };
}

export async function fileFingerprint(file) {
  const pdf = await openSource(blobSource(file));
  try { return { fingerprint: pdf.fingerprints?.[0] || null, numPages: pdf.numPages }; } finally { closePdf(pdf); }
}
