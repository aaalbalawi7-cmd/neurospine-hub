// Optional AI for the standalone website: calls the Claude API directly from the
// browser with the user's own API key (stored only on this device). It offers the
// same interface the rest of the app uses, so every citation check still applies.

const KEY = 'nsh-api';
export function apiConfig() { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; } }
export function saveApiConfig(cfg) { try { if (cfg?.key) localStorage.setItem(KEY, JSON.stringify(cfg)); else localStorage.removeItem(KEY); return true; } catch { return false; } }
export const MODELS = [
  ['claude-sonnet-5-5', 'Claude Sonnet 5.5 (balanced, recommended)'],
  ['claude-opus-5-5', 'Claude Opus 5.5 (most capable, slower)'],
  ['claude-haiku-5-5', 'Claude Haiku 5.5 (fastest)'],
];

const blobToB64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res({ type: blob.type || 'image/jpeg', data: String(r.result).split(',')[1] }); r.onerror = rej; r.readAsDataURL(blob); });
function mergeTurns(list) {
  const out = [];
  for (const m of list) { const last = out[out.length - 1]; if (last && last.role === m.role && typeof last.content === 'string' && typeof m.content === 'string') last.content += '\n\n' + m.content; else out.push({ role: m.role, content: m.content }); }
  return out;
}
function mapError(status, body) {
  const msg = body?.error?.message || ('HTTP ' + status);
  if (status === 401 || status === 403) return { code: 'bad_key', message: msg };
  if (status === 429) return { code: 'rate_limited', message: msg };
  if (status === 400 && /too long|too many tokens|prompt is too long/i.test(msg)) return { code: 'prompt_too_large', message: msg };
  if (status === 400 && /model/i.test(msg)) return { code: 'bad_model', message: msg };
  return { code: 'upstream_error', message: msg };
}

export function makeApiSample() {
  const sample = async (input, opts = {}) => {
    const cfg = apiConfig();
    if (!cfg.key) throw { code: 'no_key', message: 'No API key' };
    let msgs = mergeTurns(typeof input === 'string' ? [{ role: 'user', content: input }] : input);
    if (opts.images) {
      const imgs = await Promise.all([].concat(opts.images instanceof FileList ? [...opts.images] : opts.images).map(blobToB64));
      const last = msgs[msgs.length - 1];
      last.content = [...imgs.map(d => ({ type: 'image', source: { type: 'base64', media_type: d.type, data: d.data } })), { type: 'text', text: last.content }];
    }
    const tools = (opts.tools || []).map(t => ({ name: t.name, description: t.description, input_schema: t.inputSchema || { type: 'object', properties: {} } }));
    let shown = ''; let finalText = '';
    for (let round = 0; round < 6; round++) {
      const body = { model: cfg.model || MODELS[0][0], max_tokens: 6000, messages: msgs };
      if (tools.length && round < 5) body.tools = tools;
      let r;
      try {
        r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST', signal: opts.signal,
          headers: { 'x-api-key': cfg.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true', 'content-type': 'application/json' },
          body: JSON.stringify(body),
        });
      } catch (e) { throw { code: e?.name === 'AbortError' ? 'cancelled' : 'upstream_error', message: e?.message || 'Network error', text: finalText || undefined }; }
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw { ...mapError(r.status, j), text: finalText || undefined };
      const blocks = j.content || [];
      const t = blocks.filter(b => b.type === 'text').map(b => b.text).join('');
      const uses = blocks.filter(b => b.type === 'tool_use');
      if (t) { finalText = t; shown = t; opts.onText?.({ text: shown, delta: t }); }
      if (j.stop_reason !== 'tool_use' || !uses.length) return { text: finalText || shown || '', truncated: j.stop_reason === 'max_tokens', modelTierApplied: 'default' };
      msgs.push({ role: 'assistant', content: blocks });
      const results = [];
      for (const u of uses) {
        const tool = (opts.tools || []).find(x => x.name === u.name); let out;
        try { out = tool ? await tool.execute(u.input || {}, { signal: opts.signal || new AbortController().signal }) : 'Error: unknown tool'; out = typeof out === 'string' ? out : JSON.stringify(out); }
        catch (e) { out = 'Error: ' + (e?.message || e); }
        results.push({ type: 'tool_result', tool_use_id: u.id, content: String(out).slice(0, 32000) });
      }
      msgs.push({ role: 'user', content: results });
    }
    return { text: finalText, truncated: true, modelTierApplied: 'default' };
  };
  sample.json = async (input, opts) => {
    const { text } = await sample(input, opts);
    const tryParse = s => { try { return JSON.parse(s); } catch { return undefined; } };
    let v = tryParse(text.trim());
    if (v === undefined) { const m = /```(?:json)?\s*([\s\S]*?)```/.exec(text); if (m) v = tryParse(m[1]); }
    if (v === undefined) { const a = text.search(/[[{]/); const b = Math.max(text.lastIndexOf('}'), text.lastIndexOf(']')); if (a >= 0 && b > a) v = tryParse(text.slice(a, b + 1)); }
    if (v === undefined) throw { code: 'invalid_json', message: 'Reply was not JSON', text };
    return v;
  };
  sample.limits = async () => ({ maxPromptBytes: 600000, tools: { maxCount: 8 }, images: { maxCount: 5, maxInputBytes: 5e6, mediaTypes: ['image/jpeg', 'image/png'] } });
  sample.isApi = true;
  return sample;
}

// Quick key check with a tiny request.
export async function testKey(cfg) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': cfg.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true', 'content-type': 'application/json' },
    body: JSON.stringify({ model: cfg.model || MODELS[0][0], max_tokens: 8, messages: [{ role: 'user', content: 'Reply with OK.' }] }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw mapError(r.status, j);
  return true;
}
