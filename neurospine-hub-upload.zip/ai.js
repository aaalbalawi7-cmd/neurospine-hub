// AI features. Every one of them works only on passages retrieved from the uploaded
// PDFs, requires a citation for each statement, and checks those citations locally.
import { Lib, esc, tokenize } from './library.js';
import { Store, uid } from './store.js';
import { SECTIONS } from './taxonomy.js';
import { getPdf, renderPage } from './pdfproc.js';
import { S, views, actions, $, $$, go, render, toast, modal, confirmBox, citeChip, putItem, delItem, pageHash, emptyState, storageError } from './core.js';
import { bestPassages } from './views.js';

const RULES = `You are the retrieval assistant inside a personal neurosurgery and spine surgery reference library. The library contains only the user's own uploaded PDFs.

STRICT SOURCE RULES
1. Use ONLY the numbered source passages given to you in this conversation or returned by the search_library tool. Do not use any outside or prior medical knowledge, even when you are sure of it. Do not fill gaps.
2. End every factual sentence, bullet or table cell with its citation(s) in square brackets, e.g. [S3] or [S2][S5]. Cite only passage numbers you were actually given. Never invent a number.
3. If a statement combines information from passages of two or more different documents, begin that line with "Synthesis:" and cite every passage it relies on.
4. For key specifics (grades, scales, numbers, percentages, measurements, doses, indications, contraindications), include a short exact quote from the passage in double quotes, followed by its citation.
5. If the passages do not contain the answer, reply with exactly: Information not found in the uploaded sources. You may then add one line naming what the passages do cover, with citations.
6. Preserve the original meaning. Do not generalize beyond what the passages say. No disclaimers or advice that are not in the passages.
7. Write concise Markdown: short headings, bullets, and tables where they help.`;

const normStr = s => ' ' + tokenize(s).join(' ') + ' ';

// ---------- source registry ----------
function makeRegistry(existing = []) {
  const list = existing.slice(); const byKey = new Map(list.map(s => [s.key, s]));
  return {
    list,
    add(pa, extra = {}) {
      const key = pa.gi + ':' + (pa.li ?? 0) + ':' + pa.text.length;
      if (byKey.has(key)) return byKey.get(key);
      const s = { s: 'S' + (list.length + 1), key, gi: pa.gi, docId: pa.docId, p: pa.p, head: pa.head || '', crumbs: (pa.crumbs || []).slice(-3), text: pa.text.slice(0, 1600), ...extra };
      list.push(s); byKey.set(key, s); return s;
    },
    get(id) { return list.find(x => x.s === id); },
  };
}
const fmtSource = s => `[${s.s}] Document: ${Lib.docName(s.docId)} | Page ${Lib.label(s.docId, s.p)} (PDF page ${s.p + 1})${s.crumbs.length || s.head ? ` | Section: ${[...s.crumbs, s.head].filter(Boolean).join(' > ')}` : ''}\n"""\n${s.text}\n"""`;

// ---------- markdown + citation rendering ----------
function inline(s) {
  return s.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<i>$2</i>');
}
function citeHtml(html, reg, allowed) {
  return html.replace(/\[((?:S\d+)(?:\s*[,;]\s*S\d+)*)\]/g, (m, ids) => ids.split(/\s*[,;]\s*/).map(id => {
    const s = reg.get(id);
    if (!s || (allowed && !allowed(s))) return `<span class="cite bad" title="This citation does not match any passage that was provided, so it was rejected">${esc(id)}</span>`;
    return `<a class="cite" href="#${pageHash(s.docId, s.p)}" title="${esc(Lib.cite(s.docId, s.p))}">${esc(id)}</a>`;
  }).join(''));
}
// Verify quoted fragments against the passages cited on the same line.
function verifyQuotes(line, reg) {
  const ids = [...line.matchAll(/S\d+/g)].map(m => m[0]); const srcs = ids.map(id => reg.get(id)).filter(Boolean);
  if (!srcs.length) return line;
  return line.replace(/(["“])([^"”]{6,300})(["”])/g, (m, a, q, b) => {
    const nq = normStr(q); const ok = nq.trim().length > 0 && srcs.some(s => normStr(s.text).includes(nq));
    return m + (ok ? '' : '');
  });
}
export function renderAnswer(text, reg, allowed) {
  const lines = text.replace(/\r/g, '').split('\n').map(l => verifyQuotes(l, reg));
  const out = []; let list = null; let para = [];
  const block = (tag, raw, cls = '') => {
    const synth = /^\s*(\*\*)?synthesis:?(\*\*)?/i.test(raw);
    const cited = /\[S\d+/.test(raw); const nf = /information not found in the uploaded sources/i.test(raw);
    const uncited = !cited && !nf && raw.replace(/[#*_\s]/g, '').length > 30;
    const c = [cls, synth ? 'synth' : '', uncited ? 'uncited' : ''].filter(Boolean).join(' ');
    let h = citeHtml(inline(esc(raw)), reg, allowed).replace(//g, '<span class="qv ok" title="Quote found in the cited passage">✓ verified</span>').replace(//g, '<span class="qv no" title="This quote was not found word-for-word in the cited passage">⚠ quote not found</span>');
    return `<${tag}${c ? ` class="${c}"` : ''}${uncited ? ' title="No citation on this statement"' : ''}>${h}</${tag}>`;
  };
  const flushPara = () => { if (para.length) { out.push(block('p', para.join(' '))); para = []; } };
  const flushList = () => { if (list) { out.push(`<${list.tag}>${list.items.map(i => block('li', i)).join('')}</${list.tag}>`); list = null; } };
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (/^\s*\|/.test(l)) { // table
      flushPara(); flushList();
      const rows = []; while (i < lines.length && /^\s*\|/.test(lines[i])) rows.push(lines[i++]); i--;
      const cells = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const body = rows.filter(r => !/^\s*\|?\s*:?-{2,}/.test(r));
      out.push(`<table><thead><tr>${cells(body[0] || '').map(c => block('th', c)).join('')}</tr></thead><tbody>${body.slice(1).map(r => `<tr>${cells(r).map(c => block('td', c)).join('')}</tr>`).join('')}</tbody></table>`);
      continue;
    }
    const h = /^\s*(#{1,4})\s+(.*)$/.exec(l);
    if (h) { flushPara(); flushList(); out.push(`<h${Math.min(4, h[1].length + 1)}>${citeHtml(inline(esc(h[2])), reg, allowed)}</h${Math.min(4, h[1].length + 1)}>`); continue; }
    const li = /^\s*([-*•]|\d+[.)])\s+(.*)$/.exec(l);
    if (li) { flushPara(); const tag = /\d/.test(li[1]) ? 'ol' : 'ul'; if (!list || list.tag !== tag) { flushList(); list = { tag, items: [] }; } list.items.push(li[2]); continue; }
    if (!l.trim()) { flushPara(); flushList(); continue; }
    if (list && /^\s{2,}/.test(l)) { list.items[list.items.length - 1] += ' ' + l.trim(); continue; }
    flushList(); para.push(l.trim());
  }
  flushPara(); flushList();
  return out.join('');
}
function usedSources(text, reg) { const ids = new Set([...text.matchAll(/S\d+/g)].map(m => m[0])); return reg.list.filter(s => ids.has(s.s)); }
function sourcesHtml(srcs, title = 'Sources cited') {
  if (!srcs.length) return '';
  return `<div class="srcs"><div class="muted" style="font-size:12.5px;font-weight:600">${title}</div>${srcs.map(s => `<details class="src"><summary><span class="cite">${s.s}</span>${S.docs.has(s.docId) ? citeChip(s.docId, s.p) : esc(Lib.cite(s.docId, s.p))}<span class="crumbs">${esc([...s.crumbs, s.head].filter(Boolean).slice(-2).join(' › '))}</span></summary><pre data-src-doc="${s.docId}" data-src-p="${s.p}">${esc(s.text)}</pre></details>`).join('')}</div>`;
}
const noAi = () => Store.standalone ? 'Written answers need your Claude API key: add it in Settings › AI assistant. The matching passages are shown instead.' : 'The assistant isn\'t available in this view. The verbatim passages are the source material.';
const aiOn = () => Store.standalone ? !!Store.aiReady : !!Store.sample;
function aiError(e) {
  const c = e?.code;
  if (c === 'no_key') return noAi();
  if (c === 'bad_key') return 'Your Claude API key was rejected. Check it in Settings › AI assistant.';
  if (c === 'bad_model') return 'The selected model isn\'t available for your API key. Choose another in Settings › AI assistant.';
  if (c === 'not_granted' || c === 'sampling_disabled' || c === 'not_declared' || c === 'capability_disabled') return 'The assistant isn\'t allowed in this view. Passages are still listed so you can read the sources directly.';
  if (c === 'rate_limited') return 'Too many requests right now. Wait a minute and try again.';
  if (c === 'prompt_too_large') return 'The question pulled in too much text. Narrow it to fewer documents or a more specific question.';
  if (c === 'refused') return 'The assistant declined this request. Try rephrasing it.';
  if (c === 'cancelled') return 'Stopped.';
  return 'The assistant could not answer (' + (c || e?.message || 'error') + '). Try again.';
}
const legend = `<div class="legend"><span><span class="cite">S1</span> stated in that passage (opens the page)</span><span><span style="border-left:3px solid #7c5cd6;padding-left:6px">Synthesis</span> combines several documents</span><span><span class="qv ok">✓ verified</span> quote matched word-for-word</span><span><span class="uncited">dotted</span> no citation</span></div>`;

// ---------- assistant ----------
let current = null; let ctl = null;
views.assistant = () => {
  const ai = aiOn();
  const chats = S.chats;
  if (!current && chats.length && !S.askTopic && !S.askContext) current = chats[0];
  const docs = [...S.docs.values()];
  const A = S.asst = S.asst || { docs: [], category: '' };
  const examples = ['What are the surgical indications for spinal epidural abscess?', 'Compare the classifications of meningioma grade across my references.', 'Summarize the surgical approaches to the cervical spine.', 'What are the complications of anterior cervical discectomy and fusion?', 'Compare the management recommendations for chronic subdural hematoma across my uploaded references.'];
  return `<div class="page-head"><span class="eyebrow">AI Medical Assistant</span><h1>Ask your library</h1><p>Answers are written only from passages retrieved from your PDFs. Every statement carries a citation you can open; quotes are checked word-for-word against the cited page.${ai ? '' : ` <b>${esc(noAi())}</b>`}</p></div>
  <div class="chat">
    <div class="stack"><button class="btn primary" data-act="chat-new">New conversation</button>
      <div class="list">${chats.map(c => `<div class="li"><a href="#assistant" data-act="chat-open" data-id="${c.id}" style="${current?.id === c.id ? 'font-weight:600' : ''}">${esc(c.title || 'Conversation')}</a><button class="btn sm ghost" data-act="chat-del" data-id="${c.id}" aria-label="Delete conversation">×</button></div>`).join('') || '<p class="muted" style="font-size:13px">No saved conversations.</p>'}</div></div>
    <div class="stack">
      <div class="panel stack" style="padding:14px">
        ${docs.length > 1 ? `<div class="chips" id="adocs"><span class="muted" style="font-size:13px">Search in:</span>${docs.map(d => `<button class="chip ${!A.docs.length || A.docs.includes(d.id) ? 'on' : ''}" data-doc="${d.id}">${esc(Lib.shortName(d.id))}</button>`).join('')}</div>` : ''}
        <div class="row"><select id="acat"><option value="">All categories</option>${Lib.taxonomy.map(c => `<option value="${c.id}" ${A.category === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>${S.askContext ? `<span class="chip on">Using selected passage · ${esc(Lib.shortName(S.askContext.docId))} p. ${esc(Lib.label(S.askContext.docId, S.askContext.p))}</span>` : ''}${S.askTopic ? `<span class="chip on">Topic: ${esc(Lib.topics.get(S.askTopic)?.name || '')}</span>` : ''}</div>
      </div>
      <div class="thread" id="thread">${current ? threadHtml(current) : `<div class="panel stack"><h3>Try a question</h3><div class="chips">${examples.map(q => `<button class="chip" data-act="chat-example">${esc(q)}</button>`).join('')}</div>${legend}</div>`}</div>
      <form id="aform" class="stack"><textarea id="aq" placeholder="Ask about indications, classifications, approaches, complications… (Enter to send, Shift+Enter for a new line)" style="min-height:76px"></textarea><div class="row end"><button type="button" class="btn hidden" id="astop">Stop</button><button class="btn primary" id="asend">Ask</button></div></form>
    </div></div>`;
};
function threadHtml(chat) {
  const reg = makeRegistry(chat.sources || []);
  return legend + chat.msgs.map(m => m.role === 'user' ? `<div class="msg user"><div class="bubble">${esc(m.content)}</div></div>` : `<div class="msg"><div class="bubble md">${m.error ? `<p class="muted">${esc(m.error)}</p>` : ''}${m.content ? renderAnswer(m.content, reg) : ''}${sourcesHtml(m.content ? usedSources(m.content, reg) : (m.passages || []).map(id => reg.get(id)).filter(Boolean), m.content ? 'Sources cited' : 'Matching passages')}</div></div>`).join('');
}
views.after_assistant = (a, root) => {
  const A = S.asst; const f = root.querySelector('#aform'); const q = root.querySelector('#aq');
  root.querySelector('#adocs')?.addEventListener('click', e => { const b = e.target.closest('[data-doc]'); if (!b) return; if (!A.docs.length) A.docs = [...S.docs.keys()]; const i = A.docs.indexOf(b.dataset.doc); if (i >= 0) A.docs.splice(i, 1); else A.docs.push(b.dataset.doc); b.classList.toggle('on'); });
  root.querySelector('#acat').addEventListener('change', e => { A.category = e.target.value; });
  f.addEventListener('submit', e => { e.preventDefault(); const v = q.value.trim(); if (v) { q.value = ''; ask(v); } });
  q.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); f.requestSubmit(); } });
  root.querySelector('#astop').addEventListener('click', () => ctl?.abort());
  if (S.askTopic && !q.value) q.value = `Summarize what my sources say about ${Lib.topics.get(S.askTopic)?.name}.`;
  if (S.askContext && !q.value) q.value = 'Explain this passage using my sources.';
};
actions['chat-new'] = () => { current = null; S.askTopic = null; S.askContext = null; render(); };
actions['chat-open'] = (el) => { current = S.chats.find(c => c.id === el.dataset.id) || null; render(); };
actions['chat-del'] = async (el) => { if (!await confirmBox('Delete this conversation?')) return; S.chats = S.chats.filter(c => c.id !== el.dataset.id); if (current?.id === el.dataset.id) current = null; await delItem('chats', el.dataset.id); render(); };
actions['chat-example'] = (el) => { $('#aq').value = el.textContent; $('#aq').focus(); };

function scopeDocs() { const A = S.asst || {}; const all = [...S.docs.keys()]; return A.docs?.length && A.docs.length < all.length ? A.docs : undefined; }
function docByName(name) { if (!name) return undefined; const n = name.toLowerCase(); const hit = [...S.docs.values()].filter(d => (d.title || d.name).toLowerCase().includes(n) || n.includes((d.title || d.name).toLowerCase().slice(0, 18))); return hit.length ? hit.map(d => d.id) : undefined; }

async function ask(question) {
  if (!Lib.pageCount) { toast('Upload PDFs first.', 'bad'); return; }
  if (!current) { current = { id: uid(), title: question.slice(0, 70), msgs: [], sources: [], createdAt: Date.now() }; S.chats.unshift(current); }
  const chat = current; const reg = makeRegistry(chat.sources);
  chat.msgs.push({ role: 'user', content: question });
  // retrieval
  const docs = scopeDocs(); const category = S.asst?.category || undefined;
  const fresh = [];
  if (S.askContext) { const c = S.askContext; const gi = Lib.gi(c.docId, c.p); fresh.push(reg.add({ gi, docId: c.docId, p: c.p, li: -1, text: c.text, head: 'Selected passage', crumbs: Lib.breadcrumb(c.docId, c.p) })); }
  if (S.askTopic) { const tc = Lib.topicContent(S.askTopic, { perSection: 2 }); for (const sec of tc?.sections || []) for (const pa of sec.items) if (fresh.length < 14) fresh.push(reg.add(pa)); }
  for (const pa of Lib.retrieve(question, { docs, category, k: 12 })) if (fresh.length < 18) fresh.push(reg.add(pa));
  S.askContext = null; S.askTopic = null;
  const thread = $('#thread');
  const draw = () => { if (current === chat && $('#thread')) $('#thread').innerHTML = threadHtml(chat); };
  if (!aiOn()) {
    chat.msgs.push({ role: 'assistant', content: '', passages: fresh.map(s => s.s), error: fresh.length ? 'Showing the passages that best match your question.' : 'Information not found in the uploaded sources.' });
    chat.sources = reg.list; draw(); await saveChat(chat); return;
  }
  const pending = { role: 'assistant', content: '', pending: true };
  chat.msgs.push(pending); draw();
  if (thread) thread.lastElementChild.querySelector('.bubble').innerHTML = '<p class="muted">Searching your library and writing a cited answer…</p>';
  $('#astop')?.classList.remove('hidden'); $('#asend') && ($('#asend').disabled = true);
  const prevTurns = chat.msgs.slice(0, -2).filter(m => m.content).slice(-6).map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));
  const prevCited = new Set(prevTurns.filter(m => m.role === 'assistant').flatMap(m => [...m.content.matchAll(/S\d+/g)].map(x => x[0])));
  const carry = reg.list.filter(s => prevCited.has(s.s) && !fresh.includes(s)).slice(0, 10);
  const ctxSources = [...carry, ...fresh];
  const final = `${ctxSources.length ? 'SOURCE PASSAGES\n\n' + ctxSources.map(fmtSource).join('\n\n') : 'No passages matched this question in the library.'}\n\nQUESTION\n${question}\n\nAnswer using only the passages above (and any you retrieve with search_library), following the strict source rules.`;
  const messages = [{ role: 'user', content: RULES }, ...prevTurns, { role: 'user', content: final }];
  ctl = new AbortController();
  let tools; try { const lim = await Store.sample.limits(); if (lim?.tools) tools = [{
    name: 'search_library',
    description: 'Full-text search of the user\'s uploaded PDF library. Returns numbered passages (S#) with document and page that you may cite. Use it to look for other wording, another document, or missing details.',
    inputSchema: { type: 'object', properties: { query: { type: 'string', description: 'Search terms; supports "phrases", AND, OR, NOT' }, document: { type: 'string', description: 'Optional: part of a document title to search within' } }, required: ['query'] },
    execute: (input) => { const ps = Lib.retrieve(String(input.query || ''), { docs: docByName(input.document) || docs, k: 6 }).map(pa => reg.add(pa)); if (thread) { const b = $('#thread')?.lastElementChild?.querySelector('.bubble'); if (b && !pending.content) b.innerHTML = `<p class="muted">Searching for “${esc(String(input.query || ''))}”…</p>`; } return ps.length ? ps.map(fmtSource).join('\n\n') : 'No passages found for that search.'; },
  }]; } catch { /* no tools */ }
  try {
    const res = await Store.sample(messages, {
      cache: false, signal: ctl.signal, tools,
      onText: ({ text }) => { pending.content = text; const b = $('#thread')?.lastElementChild?.querySelector('.bubble'); if (b && current === chat) b.innerHTML = renderAnswer(text, reg); },
    });
    pending.content = res.text; if (res.truncated) pending.error = 'The answer was cut short. Ask a narrower question for the rest.';
  } catch (e) { pending.content = e?.text || ''; pending.error = aiError(e); if (!pending.content) pending.passages = fresh.map(s => s.s); }
  delete pending.pending; chat.sources = reg.list; chat.updatedAt = Date.now();
  $('#astop')?.classList.add('hidden'); $('#asend') && ($('#asend').disabled = false);
  draw(); await saveChat(chat);
}
async function saveChat(chat) {
  const copy = JSON.parse(JSON.stringify(chat));
  // keep documents under the 256 KiB limit: trim source text first, then old turns
  const size = () => JSON.stringify(copy).length;
  for (const s of copy.sources) if (size() > 230000) s.text = s.text.slice(0, 500);
  while (size() > 240000 && copy.msgs.length > 2) copy.msgs.splice(0, 2);
  await putItem('chats', copy);
}

// ---------- topic section summary ----------
actions['ai-section'] = async (el) => {
  const tid = el.dataset.topic, sid = el.dataset.sec; const key = `topic:${tid}:${sid}`.replace(/[^A-Za-z0-9_\-.~:@+]/g, '_');
  const box = $('#ai-' + sid); const t = Lib.topics.get(tid); const sec = SECTIONS.find(s => s.id === sid);
  const show = (rec) => { const reg = makeRegistry(rec.sources); box.innerHTML = `<div class="bubble md" style="border-color:color-mix(in srgb,var(--accent) 35%,transparent)"><div class="row between"><b>Cited summary · ${esc(sec.name)}</b><span class="row"><span class="muted" style="font-size:12px">Organized by AI from the passages below</span><button class="btn sm ghost" data-act="ai-section-redo" data-topic="${tid}" data-sec="${sid}">Regenerate</button></span></div>${renderAnswer(rec.text, reg)}${sourcesHtml(usedSources(rec.text, reg))}</div>`; };
  const cached = S.ai.get(key);
  if (cached && !el.dataset.redo) { show(cached); return; }
  if (!aiOn()) { box.innerHTML = `<p class="notfound">${esc(noAi())}</p>`; return; }
  const c = Lib.topicContent(tid, { perSection: 8 }); const s = c.sections.find(x => x.id === sid);
  if (!s) { box.innerHTML = '<p class="notfound">Information not found in the uploaded sources.</p>'; return; }
  const reg = makeRegistry(); s.items.forEach(pa => reg.add(pa));
  box.innerHTML = '<p class="muted">Writing a cited summary from the passages…</p>';
  const prompt = `${RULES}\n\nTASK\nSummarize what these passages say about the "${sec.name}" of ${t.name}. Organize by sub-points. If the documents differ, say so, citing each. If the passages contain nothing about ${sec.name.toLowerCase()} of ${t.name}, reply: Information not found in the uploaded sources.\n\nSOURCE PASSAGES\n\n${reg.list.map(fmtSource).join('\n\n')}`;
  try {
    const res = await Store.sample(prompt, { cache: false });
    const rec = { id: key, text: res.text, sources: reg.list, createdAt: Date.now() };
    S.ai.set(key, rec); show(rec); putItem('ai', rec);
  } catch (e) { box.innerHTML = `<p class="notfound">${esc(aiError(e))}</p>`; }
};
actions['ai-section-redo'] = (el) => { const b = document.createElement('button'); b.dataset.topic = el.dataset.topic; b.dataset.sec = el.dataset.sec; b.dataset.redo = '1'; actions['ai-section'](b); };

// ---------- flashcard drafts ----------
actions['fc-gen'] = async () => {
  const tid = $('#fc-topic')?.value; const box = $('#fc-drafts'); if (!tid) { toast('Choose a topic first.', 'bad'); return; }
  if (!aiOn()) { box.innerHTML = `<p class="notfound">${esc(noAi())} You can still create cards by selecting text and choosing “Flashcard”.</p>`; return; }
  const t = Lib.topics.get(tid); const c = Lib.topicContent(tid, { perSection: 2 }); const reg = makeRegistry();
  for (const s of c.sections) for (const pa of s.items) if (reg.list.length < 12) reg.add(pa);
  if (!reg.list.length) { box.innerHTML = '<p class="notfound">Information not found in the uploaded sources.</p>'; return; }
  box.innerHTML = '<p class="muted">Drafting cards from the passages…</p>';
  const prompt = `Write up to 8 study flashcards about ${t.name}, using ONLY the passages below. Each card needs a question ("front") and an answer that is an EXACT, contiguous quote copied character-for-character from one passage ("quote", 8 to 70 words), plus that passage's id ("source", e.g. "S2"). Do not paraphrase the quote. Do not use outside knowledge.\nReply with only a JSON array like [{"front":"...","quote":"...","source":"S1"}].\n\nPASSAGES\n\n${reg.list.map(fmtSource).join('\n\n')}`;
  try {
    const arr = await Store.sample.json(prompt, { cache: false });
    const drafts = (Array.isArray(arr) ? arr : []).map(d => { const s = reg.get(String(d.source || '').trim()); const q = String(d.quote || ''); const ok = s && q.length > 10 && normStr(s.text).includes(normStr(q)); return { front: String(d.front || '').slice(0, 300), quote: q, s, ok }; });
    const good = drafts.filter(d => d.ok && d.front);
    S._drafts = good;
    box.innerHTML = `<p class="muted" style="font-size:13px">${good.length} of ${drafts.length} drafts passed the verbatim check${drafts.length - good.length ? `; ${drafts.length - good.length} discarded because their answer wasn't found word-for-word in the source` : ''}.</p>` + (good.length ? `<div class="list">${good.map((d, i) => `<label class="li chk" style="align-items:flex-start"><input type="checkbox" checked data-i="${i}"><span style="flex:1"><b>${esc(d.front)}</b><br><span style="font:14px/1.5 var(--font-read)">${esc(d.quote)}</span></span>${citeChip(d.s.docId, d.s.p)}</label>`).join('')}</div><div class="row end"><button class="btn primary" data-act="fc-save-drafts" data-deck="${esc(t.name)}">Save selected cards</button></div>` : '');
  } catch (e) { box.innerHTML = `<p class="notfound">${esc(aiError(e))}</p>`; }
};
actions['fc-save-drafts'] = async (el) => {
  const boxes = $$('#fc-drafts input[type=checkbox]'); let k = 0;
  for (const b of boxes) if (b.checked) { const d = S._drafts[+b.dataset.i]; const c = { id: uid(), front: d.front, back: d.quote, docId: d.s.docId, p: d.s.p, deck: el.dataset.deck, ef: 2.5, interval: 0, reps: 0, due: Date.now(), createdAt: Date.now(), generated: true }; S.cards.push(c); await putItem('cards', c); k++; }
  toast(`${k} cards saved.`); render();
};

// ---------- OCR of scanned pages ----------
actions['ocr-doc'] = async (meta, pages) => {
  if (!aiOn()) { toast(noAi(), 'bad'); return; }
  const lim = await Store.sample.limits().catch(() => null);
  if (!lim?.images) { toast('Sending page images to the assistant isn\'t enabled in this view.', 'bad'); return; }
  let pdf; try { ({ pdf } = await getPdf(meta)); } catch { toast('Attach the original PDF first.', 'bad'); return; }
  const todo = pages.slice(0, 40); const got = {};
  const { progress } = await import('./app.js');
  for (const [i, p] of todo.entries()) {
    progress(i, todo.length, `OCR: page ${p + 1} (${i + 1} of ${todo.length})`);
    try {
      const c = document.createElement('canvas'); await renderPage(pdf, p + 1, c, { scale: 2, maxPixels: 9e6 });
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.88));
      const res = await Store.sample('This image is one scanned page from a medical PDF. Transcribe all of its text exactly as printed, in reading order, keeping line breaks. Do not correct, interpret, summarize or add anything. Write tables row by row with cells separated by " | ". If there is no text, reply with: [no text]', { images: [blob] });
      if (!/^\s*\[no text\]\s*$/i.test(res.text)) got[p] = res.text.slice(0, 20000);
    } catch (e) { if (e?.code === 'rate_limited') { toast('Rate limited; OCR paused. Run it again later for the remaining pages.', 'bad'); break; } }
  }
  progress();
  meta.ocr = { ...(meta.ocr || {}), ...got };
  // store in ≤200 KB documents
  let chunk = {}; let size = 0; let k = 0;
  const flush = async () => { if (!Object.keys(chunk).length) return; await Store.put('ocr', meta.id + '_' + (k++), { docId: meta.id, pages: chunk }).catch(storageError); chunk = {}; size = 0; };
  for (const [p, t] of Object.entries(meta.ocr)) { if (size + t.length > 190000) await flush(); chunk[p] = t; size += t.length; }
  await flush();
  const pack = Lib.docs.get(meta.id)?.pack; if (pack) { await Lib.addDoc(meta, pack); Lib.finalize(); }
  toast(`OCR finished for ${Object.keys(got).length} page(s). Their text is now searchable and marked as OCR.`); render();
};

// ---------- AI comparison ----------
actions['cmp-ai'] = async () => {
  const C = S.cmp; if (!C?.cols) actions['cmp-run']();
  if (!S.cmp.cols) return;
  const out = $('#cmpai'); if (!out) return;
  if (!aiOn()) { out.innerHTML = `<p class="notfound">${esc(noAi())}</p>`; return; }
  const reg = makeRegistry();
  for (const col of C.cols) for (const aid of C.aspects) for (const pa of bestPassages(col.query, aid, col.docs, 2).items) reg.add(pa, { col: col.id });
  if (!reg.list.length) { out.innerHTML = '<p class="notfound">Information not found in the uploaded sources.</p>'; return; }
  out.innerHTML = '<p class="muted">Comparing the passages…</p>';
  const colDesc = C.cols.map(c => `- column "${c.id}": ${c.name}`).join('\n');
  const prompt = `${RULES}\n\nTASK\nBuild a structured comparison. Columns:\n${colDesc}\nAspects (rows): ${C.aspects.map(a => SECTIONS.find(s => s.id === a).name).join(', ')}.\nEach passage below is labeled with the column it belongs to. A cell may only use passages of its own column. If a column has nothing on an aspect, use the text "Information not found in the uploaded sources." with an empty cites list. Then list agreements and differences between the columns, each with citations from both sides.\nReply with only JSON of this shape: {"rows":[{"aspect":"...","cells":{"<column id>":{"text":"...","cites":["S1"]}}}],"agreements":[{"text":"...","cites":["S1","S4"]}],"differences":[{"text":"...","cites":["S2","S6"]}]}\n\nSOURCE PASSAGES\n\n${reg.list.map(s => `(column ${s.col}) ` + fmtSource(s)).join('\n\n')}`;
  try {
    const j = await Store.sample.json(prompt, { cache: false });
    const chk = (cites, col) => (Array.isArray(cites) ? cites : []).map(String).map(id => { const s = reg.get(id); return { id, s, ok: !!s && (!col || s.col === col) }; });
    const cell = (c, col) => { if (!c) return '<span class="muted">Information not found in the uploaded sources.</span>'; const cs = chk(c.cites, col); const anyOk = cs.some(x => x.ok); return `<div class="x">${esc(c.text || '')}</div><div style="margin-top:6px">${cs.map(x => x.ok ? `<a class="cite" href="#${pageHash(x.s.docId, x.s.p)}" title="${esc(Lib.cite(x.s.docId, x.s.p))}">${x.id}</a>` : `<span class="cite bad" title="Rejected: not a passage of this column">${esc(x.id)}</span>`).join('')}${!anyOk && !/information not found/i.test(c.text || '') ? ' <span class="qv no">⚠ unsupported</span>' : ''}</div>`; };
    const list = (arr, title) => (arr || []).length ? `<h3 style="margin-top:14px">${title}</h3><ul>${arr.map(a => { const cs = chk(a.cites); return `<li>${esc(a.text || '')} ${cs.map(x => x.ok ? `<a class="cite" href="#${pageHash(x.s.docId, x.s.p)}">${x.id}</a>` : `<span class="cite bad">${esc(x.id)}</span>`).join('')}</li>`; }).join('')}</ul>` : '';
    out.innerHTML = `<div class="panel md"><div class="row between"><h3>Structured comparison (AI-organized, cited)</h3><span class="muted" style="font-size:12.5px">Synthesized from the passages listed below</span></div><div class="tablewrap"><table class="cmp"><thead><tr><th>Aspect</th>${C.cols.map(c => `<th>${esc(c.name)}</th>`).join('')}</tr></thead><tbody>${(j.rows || []).map(r => `<tr><th>${esc(r.aspect || '')}</th>${C.cols.map(c => `<td>${cell(r.cells?.[c.id], c.id)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>${list(j.agreements, 'Agreements')}${list(j.differences, 'Differences')}${sourcesHtml(reg.list, 'Passages provided')}</div>`;
  } catch (e) { out.innerHTML = `<p class="notfound">${esc(aiError(e))}</p>`; }
};
