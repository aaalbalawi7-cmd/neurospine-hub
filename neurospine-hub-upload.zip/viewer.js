// Original-page viewer: renders the PDF page with a selectable text layer,
// search-term marks, colored highlights, notes and bookmarks.
import { Lib, esc, tokenize } from './library.js';
import { getPdf, pdfjsLib } from './pdfproc.js';
import { HIGHLIGHT_COLORS, HIGHLIGHT_LABELS } from './taxonomy.js';
import { S, views, actions, $, $$, go, render, toast, modal, confirmBox, putItem, delItem, citeChip, pageHash, recordVisit, colorCss, uid } from './core.js';
import { openCardModal, openQrefModal } from './views.js';

const V = { docId: null, p: 0, zoom: 1, pdf: null, where: null, tab: 'text', task: null, hl: null, seq: 0 };
export function setViewerHighlight(hl) { V.hl = hl; }

views.viewer = (arg) => {
  const meta = S.docs.get(arg?.docId);
  if (!meta) return `<div style="padding:24px">${'<div class="panel"><h2>Document not found</h2><p class="muted">This document is not in your library. It may have been removed.</p></div>'}</div>`;
  if (V.docId !== meta.id) { V.pdf = null; V.where = null; }
  V.docId = meta.id; V.p = Math.max(0, Math.min((meta.pages || 1) - 1, arg.p));
  const total = meta.pages || 0; const lbl = Lib.label(meta.id, V.p);
  const bm = S.bm.find(b => b.type === 'page' && b.docId === meta.id && b.p === V.p);
  return `<div class="viewer">
    <div class="vmain" id="vmain">
      <div class="vbar">
        <a class="icon-btn" href="#library" title="Back to library" aria-label="Back to library">←</a>
        <span class="title" title="${esc(meta.title || meta.name)}">${esc(meta.title || meta.name)}</span>
        <span style="flex:1"></span>
        <button class="icon-btn" data-act="v-prev" aria-label="Previous page" ${V.p <= 0 ? 'disabled' : ''}>‹</button>
        <label class="row" style="gap:4px"><span class="muted" style="font-size:13px">Page</span><input class="pg tnum" id="v-pg" type="text" value="${esc(lbl)}" aria-label="Page"></label>
        <span class="muted tnum" style="font-size:13px">PDF ${V.p + 1} / ${total}</span>
        <button class="icon-btn" data-act="v-next" aria-label="Next page" ${V.p >= total - 1 ? 'disabled' : ''}>›</button>
        <button class="icon-btn" data-act="v-zoom" data-z="-1" aria-label="Zoom out">−</button>
        <button class="icon-btn" data-act="v-zoom" data-z="0" aria-label="Fit width" title="Fit width">⤢</button>
        <button class="icon-btn" data-act="v-zoom" data-z="1" aria-label="Zoom in">+</button>
        <button class="icon-btn ${bm ? 'on' : ''}" data-act="v-bookmark" aria-label="Bookmark this page" title="Bookmark page">★</button>
        <button class="icon-btn" data-act="v-full" aria-label="Full screen" title="Full screen">⛶</button>
      </div>
      <div class="crumbs" style="padding:6px 14px;border-bottom:1px solid var(--line);background:var(--surface)">${esc(Lib.breadcrumb(meta.id, V.p).join(' › ') || ' ')} ${(Lib.pageTopics[Lib.gi(meta.id, V.p)] || []).slice(0, 3).map(([t]) => `<a class="chip" style="margin-left:6px" href="#topic-${t}">${esc(Lib.topics.get(t)?.name || t)}</a>`).join('')}</div>
      <div class="vstage" id="vstage"><div class="pagewrap" id="pagewrap"><canvas id="pcanvas"></canvas><div class="hls" id="hls"></div><div class="textLayer" id="tlayer"></div></div><div id="v-msg"></div></div>
    </div>
    <aside class="vside">
      <div class="tabs" id="vtabs">${[['text', 'Page text'], ['notes', 'Notes'], ['outline', 'Outline'], ['find', 'Find']].map(([k, l]) => `<button data-tab="${k}" class="${V.tab === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="vpanel" id="vpanel"></div>
    </aside>
  </div>`;
};

views.after_viewer = async () => {
  const meta = S.docs.get(V.docId); if (!meta) return;
  recordVisit({ type: 'page', docId: meta.id, p: V.p });
  $('#vtabs').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; V.tab = b.dataset.tab; $$('#vtabs button').forEach(x => x.classList.toggle('on', x === b)); sidePanel(); });
  const pg = $('#v-pg');
  pg.addEventListener('change', () => {
    const v = pg.value.trim(); const labels = Lib.docs.get(meta.id)?.pack.labels;
    let idx = labels ? labels.indexOf(v) : -1;
    if (idx < 0 && /^\d+$/.test(v)) idx = +v - 1;
    if (idx >= 0 && idx < meta.pages) go(pageHash(meta.id, idx)); else { toast('No such page in this document.', 'bad'); pg.value = Lib.label(meta.id, V.p); }
  });
  sidePanel();
  await drawPage();
};

async function drawPage() {
  const meta = S.docs.get(V.docId); const seq = ++V.seq;
  const stage = $('#vstage'), wrap = $('#pagewrap'), canvas = $('#pcanvas'), tl = $('#tlayer'), msg = $('#v-msg');
  if (!stage) return;
  if (!V.pdf) {
    msg.innerHTML = '<p class="muted" style="text-align:center;padding:30px">Opening the original PDF…</p>'; wrap.style.display = 'none';
    try { const o = await getPdf(meta); V.pdf = o.pdf; V.where = o.where; }
    catch (e) { if (seq !== V.seq) return; textOnly(meta, e); return; }
  }
  if (seq !== V.seq) return;
  msg.innerHTML = ''; wrap.style.display = '';
  try {
    V.task?.cancel?.();
    const page = await V.pdf.getPage(V.p + 1);
    const vp1 = page.getViewport({ scale: 1 });
    const avail = Math.max(280, Math.min(stage.clientWidth - 24, 1500));
    const scale = (avail / vp1.width) * V.zoom;
    const vp = page.getViewport({ scale });
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    wrap.style.width = Math.floor(vp.width) + 'px'; wrap.style.height = Math.floor(vp.height) + 'px';
    wrap.style.setProperty('--scale-factor', scale); wrap.style.setProperty('--user-unit', 1); wrap.style.setProperty('--total-scale-factor', scale);
    canvas.width = Math.floor(vp.width * dpr); canvas.height = Math.floor(vp.height * dpr);
    const ctx = canvas.getContext('2d');
    V.task = page.render({ canvasContext: ctx, canvas, viewport: vp, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : null });
    await V.task.promise.catch(e => { if (e?.name !== 'RenderingCancelledException') throw e; });
    if (seq !== V.seq) return;
    tl.innerHTML = '';
    const textLayer = new pdfjsLib.TextLayer({ textContentSource: await page.getTextContent(), container: tl, viewport: vp });
    await textLayer.render();
    markHits(tl);
    drawHighlights();
  } catch (e) { console.error(e); msg.innerHTML = `<div class="panel error" style="margin:16px">Could not render this page: ${esc(e.message)}</div>`; }
}

function textOnly(meta, err) {
  const wrap = $('#pagewrap'), msg = $('#v-msg'); wrap.style.display = 'none';
  const gi = Lib.gi(meta.id, V.p);
  msg.innerHTML = `<div class="nopdf" style="padding:16px">
    <div class="panel stack"><h3>The original PDF isn't available on this device</h3>
      <p class="muted">${meta.chunks?.length ? 'The cloud copy could not be opened right now.' : 'This document was added on another device and its original was not stored in the cloud.'} Attach the same file to see the page as printed. The extracted text of this page is shown below, so citations still work.</p>
      <div class="row"><button class="btn primary" data-act="attach-pdf" data-id="${meta.id}">Attach ${esc(meta.name)}</button></div></div>
    <div class="panel"><div class="ptext" id="ptext-main">${gi >= 0 ? textWithMarks(gi) : '<span class="muted">Text not available.</span>'}</div></div></div>`;
}

function markHits(tl) {
  const hl = V.hl; if (!hl || (!hl.terms.size && !hl.phrases.length)) return;
  const words = new Set(hl.terms); for (const ph of hl.phrases) ph.forEach(w => words.add(w));
  for (const span of tl.querySelectorAll('span')) {
    if (span.children.length) continue;
    const t = span.textContent; if (!t || !t.trim()) continue;
    const re = /[A-Za-z0-9]+(?:['’][A-Za-z]+)?/g; let m; let out = ''; let pos = 0; let any = false;
    while ((m = re.exec(t))) { const nt = tokenize(m[0])[0]; if (nt && words.has(nt)) { out += esc(t.slice(pos, m.index)) + '<mark class="hit">' + esc(m[0]) + '</mark>'; pos = m.index + m[0].length; any = true; } }
    if (any) span.innerHTML = out + esc(t.slice(pos));
  }
}

function drawHighlights() {
  const box = $('#hls'); if (!box) return;
  const list = S.ann.filter(a => a.docId === V.docId && a.p === V.p && a.rects?.length);
  box.innerHTML = list.map(a => a.rects.map(r => `<div class="hl" data-ann="${a.id}" style="left:${r[0] * 100}%;top:${r[1] * 100}%;width:${r[2] * 100}%;height:${r[3] * 100}%;background:${colorCss(a.color)}"></div>`).join('')).join('');
}

function textWithMarks(gi) {
  const text = Lib.text[gi] || '';
  const anns = S.ann.filter(a => a.docId === Lib.gDoc[gi] && a.p === Lib.gPage[gi] && a.quote);
  const ranges = [];
  for (const a of anns) {
    const words = a.quote.split(/\s+/).filter(Boolean).slice(0, 80).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    if (!words.length) continue;
    try { const m = new RegExp(words.join('[\\s\\-]*'), 'i').exec(text); if (m) ranges.push([m.index, m.index + m[0].length, a]); } catch { /* ignore */ }
  }
  ranges.sort((x, y) => x[0] - y[0]);
  const hl = V.hl || { terms: new Set(), phrases: [] };
  let out = ''; let pos = 0;
  for (const [s, e, a] of ranges) { if (s < pos) continue; out += Lib.markHtml(text.slice(pos, s), hl); out += `<span class="ann" style="background:${colorCss(a.color)}" title="${esc(a.note || a.label || '')}">${Lib.markHtml(text.slice(s, e), hl)}</span>`; pos = e; }
  return out + Lib.markHtml(text.slice(pos), hl);
}

function sidePanel() {
  const box = $('#vpanel'); if (!box) return; const meta = S.docs.get(V.docId); const gi = Lib.gi(V.docId, V.p);
  if (V.tab === 'text') {
    box.innerHTML = `<div class="row between"><span class="muted" style="font-size:13px">Extracted text · select to highlight</span>${V.hl ? '<button class="btn sm ghost" data-act="v-clearhl">Clear search marks</button>' : ''}</div><div class="ptext" id="ptext">${gi >= 0 ? textWithMarks(gi) : ''}</div>`;
  } else if (V.tab === 'notes') {
    const all = S.ann.filter(a => a.docId === V.docId).sort((a, b) => (a.p - b.p) || (a.createdAt - b.createdAt));
    const here = all.filter(a => a.p === V.p), other = all.filter(a => a.p !== V.p);
    const card = a => `<div class="ann-card" style="--c:${colorCss(a.color)}"><div class="row between"><span>${a.label ? `<span class="label-chip">${esc(a.label)}</span>` : ''}</span>${citeChip(a.docId, a.p)}</div><q>${esc(a.quote)}</q>${a.note ? `<div>${esc(a.note)}</div>` : ''}<div class="row"><button class="btn sm ghost" data-act="ann-edit" data-id="${a.id}">Edit</button><button class="btn sm ghost danger" data-act="ann-del" data-id="${a.id}">Delete</button></div></div>`;
    box.innerHTML = `<h4>On this page</h4>${here.length ? here.map(card).join('') : '<p class="muted">No highlights on this page. Select text on the page or in “Page text” to add one.</p>'}${other.length ? `<h4>Elsewhere in this document</h4>${other.slice(0, 60).map(card).join('')}` : ''}`;
  } else if (V.tab === 'outline') {
    const ol = Lib.docs.get(V.docId)?.pack.outline || []; const cur = Lib.docs.get(V.docId)?.sectionOf?.[V.p];
    box.innerHTML = ol.length ? ol.map((e, i) => e.p >= 0 && !/^\S*\d{5,}\S*$/.test(e.t) ? `<a class="ol-item ${i === cur ? 'cur' : ''}" style="padding-left:${e.l * 14}px" href="#${pageHash(V.docId, e.p)}">${esc(e.t)} <span class="muted mono">${esc(Lib.label(V.docId, e.p))}</span></a>` : '').join('') : '<p class="muted">This PDF has no outline.</p>';
    const cur2 = box.querySelector('.cur'); if (cur2) box.scrollTop = cur2.offsetTop - box.offsetTop - box.clientHeight / 2;
  } else if (V.tab === 'find') {
    box.innerHTML = `<form id="vfind" class="row"><input type="search" id="vfq" placeholder="Find in this document" style="flex:1" value="${esc(V.findQ || '')}"><button class="btn">Find</button></form><div id="vfr"></div>`;
    const run = () => {
      const q = $('#vfq').value.trim(); V.findQ = q; if (!q) return;
      const r = Lib.search(q, { docs: [V.docId], fuzzy: S.prefs.fuzzy, abbr: S.prefs.abbr !== false }); const hl = Lib.highlightSet(r.info);
      $('#vfr').innerHTML = r.results.length ? `<p class="muted" style="font-size:13px">${r.total} pages</p>` + r.results.slice(0, 80).sort((a, b) => a.p - b.p).map(x => `<a class="result" style="display:block;color:inherit" href="#${pageHash(x.docId, x.p)}" data-hl="1"><b class="mono">p. ${esc(Lib.label(x.docId, x.p))}</b> <span class="snip" style="font-size:13.5px">${Lib.snippets(x.gi, hl, { max: 1, width: 22 })[0]}</span></a>`).join('') : '<p class="notfound">Information not found in the uploaded sources.</p>';
      V.pendingHL = hl;
    };
    $('#vfind').addEventListener('submit', e => { e.preventDefault(); run(); });
    $('#vfr').addEventListener('click', e => { if (e.target.closest('[data-hl]')) V.hl = V.pendingHL; });
    if (V.findQ) run();
  }
  void meta;
}

// ---------- toolbar actions ----------
actions['v-prev'] = () => { if (V.p > 0) go(pageHash(V.docId, V.p - 1)); };
actions['v-next'] = () => { const m = S.docs.get(V.docId); if (V.p < m.pages - 1) go(pageHash(V.docId, V.p + 1)); };
actions['v-zoom'] = (el) => { const z = +el.dataset.z; V.zoom = z === 0 ? 1 : Math.max(0.5, Math.min(4, V.zoom * (z > 0 ? 1.25 : 0.8))); drawPage(); };
actions['v-clearhl'] = () => { V.hl = null; sidePanel(); drawPage(); };
actions['v-full'] = async () => {
  const el = $('#vmain');
  try { if (document.fullscreenElement) await document.exitFullscreen(); else await el.requestFullscreen(); setTimeout(drawPage, 300); }
  catch { el.classList.toggle('fsfake'); el.style.cssText = el.classList.contains('fsfake') ? 'position:fixed;inset:0;z-index:70;background:var(--bg)' : ''; setTimeout(drawPage, 100); }
};
actions['v-bookmark'] = async (el) => {
  const ex = S.bm.find(b => b.type === 'page' && b.docId === V.docId && b.p === V.p);
  if (ex) { S.bm = S.bm.filter(b => b !== ex); await delItem('bm', ex.id); el.classList.remove('on'); toast('Bookmark removed.'); return; }
  const title = Lib.breadcrumb(V.docId, V.p).slice(-1)[0] || `Page ${Lib.label(V.docId, V.p)}`;
  const b = { id: uid(), type: 'page', docId: V.docId, p: V.p, title, note: '', createdAt: Date.now() };
  S.bm.push(b); await putItem('bm', b); el.classList.add('on'); toast('Page bookmarked.');
};
document.addEventListener('keydown', e => {
  if (S.route.name !== 'viewer' || e.target.closest('input,textarea,select')) return;
  if (e.key === 'ArrowLeft') actions['v-prev'](); else if (e.key === 'ArrowRight') actions['v-next']();
});
let resizeT; window.addEventListener('resize', () => { if (S.route.name === 'viewer') { clearTimeout(resizeT); resizeT = setTimeout(drawPage, 250); } });

// ---------- annotations ----------
function pageTopicsOf(docId, p) { return (Lib.pageTopics[Lib.gi(docId, p)] || []).slice(0, 3).map(x => x[0]); }
export async function saveAnnotation({ docId, p, quote, rects = null, color = 'yellow', label = '', note = '', source = 'page' }) {
  const topics = pageTopicsOf(docId, p);
  const a = { id: uid(), docId, p, quote: quote.slice(0, 4000), rects, color, label, note, source, topics, cat: topics[0] ? Lib.categoryOf(topics[0]) : '', createdAt: Date.now() };
  S.ann.push(a); await putItem('ann', a);
  if (S.route.name === 'viewer' && docId === V.docId && p === V.p) { drawHighlights(); sidePanel(); }
  return a;
}
export function annotationModal(a, onSave) {
  const m = modal(`<h3>${a.id ? 'Edit highlight' : 'Highlight with note'}</h3>
    <blockquote style="margin:0;font:15px/1.55 var(--font-read);max-height:180px;overflow:auto;border-left:3px solid var(--line);padding-left:10px">${esc(a.quote)}</blockquote>
    <div>${citeChip(a.docId, a.p)}</div>
    <div class="row">${HIGHLIGHT_COLORS.map(c => `<label class="chk"><input type="radio" name="hc" value="${c.id}" ${a.color === c.id ? 'checked' : ''}><span style="width:18px;height:18px;border-radius:50%;background:${c.css};display:inline-block;border:1px solid var(--line)"></span>${c.name}</label>`).join('')}</div>
    <label>Type <select id="hlab"><option value="">None</option>${HIGHLIGHT_LABELS.map(l => `<option ${a.label === l ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    <label>Note <textarea id="hnote" placeholder="Your own note (stored privately)">${esc(a.note || '')}</textarea></label>
    <div class="row end"><button class="btn" data-close>Cancel</button><button class="btn primary" id="hsave">Save</button></div>`);
  m.el.querySelector('#hsave').onclick = async () => {
    a.color = m.el.querySelector('input[name=hc]:checked')?.value || 'yellow'; a.label = m.el.querySelector('#hlab').value; a.note = m.el.querySelector('#hnote').value.trim();
    m.close(); await onSave(a);
  };
}
actions['ann-edit'] = (el) => { const a = S.ann.find(x => x.id === el.dataset.id); if (!a) return; annotationModal({ ...a }, async (u) => { Object.assign(a, u); await putItem('ann', a); toast('Saved.'); if (S.route.name === 'viewer') { drawHighlights(); sidePanel(); } else render(); }); };
actions['ann-del'] = async (el) => { if (!await confirmBox('Delete this highlight and its note?')) return; S.ann = S.ann.filter(x => x.id !== el.dataset.id); await delItem('ann', el.dataset.id); if (S.route.name === 'viewer') { drawHighlights(); sidePanel(); } else render(); };

// ---------- selection toolbar ----------
let tool = null; let selInfo = null;
function hideTool() { tool?.remove(); tool = null; }
function mergeRects(list) {
  const rs = list.slice().sort((a, b) => a[1] - b[1] || a[0] - b[0]); const out = [];
  for (const r of rs) { const l = out[out.length - 1]; if (l && Math.abs(l[1] - r[1]) < 0.004 && Math.abs(l[3] - r[3]) < 0.006 && r[0] <= l[0] + l[2] + 0.01) { const x2 = Math.max(l[0] + l[2], r[0] + r[2]); l[2] = x2 - l[0]; } else out.push(r.slice()); }
  return out;
}
function readSelection() {
  const sel = window.getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0); const node = range.commonAncestorContainer.nodeType === 1 ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
  const quote = sel.toString().replace(/\s+/g, ' ').trim(); if (quote.length < 2) return null;
  const inLayer = node.closest?.('#tlayer') || node.closest?.('.pagewrap');
  const inText = node.closest?.('.ptext');
  const inExcerpt = node.closest?.('[data-src-doc]');
  if (inLayer && S.route.name === 'viewer') {
    const wr = $('#pagewrap').getBoundingClientRect();
    const rects = mergeRects([...range.getClientRects()].filter(r => r.width > 1 && r.height > 1).map(r => [(r.left - wr.left) / wr.width, (r.top - wr.top) / wr.height, r.width / wr.width, r.height / wr.height]).filter(r => r[0] > -0.05 && r[1] > -0.05 && r[0] < 1.05 && r[1] < 1.05));
    return { docId: V.docId, p: V.p, quote, rects, source: 'page', range };
  }
  if (inText && S.route.name === 'viewer') return { docId: V.docId, p: V.p, quote, rects: null, source: 'text', range };
  if (inExcerpt) return { docId: inExcerpt.dataset.srcDoc, p: +inExcerpt.dataset.srcP, quote, rects: null, source: 'excerpt', range };
  return null;
}
function showTool(info) {
  hideTool(); selInfo = info;
  tool = document.createElement('div'); tool.className = 'seltool'; tool.setAttribute('role', 'toolbar');
  tool.innerHTML = HIGHLIGHT_COLORS.map(c => `<button class="sw" data-c="${c.id}" title="Highlight ${c.name}" aria-label="Highlight ${c.name}" style="background:${c.css}"></button>`).join('') +
    `<button data-x="note">Note</button><button data-x="bm">Bookmark</button><button data-x="card">Flashcard</button><button data-x="qref">Quick ref</button><button data-x="cite">Copy with citation</button><button data-x="ask">Ask AI</button>`;
  document.body.appendChild(tool);
  const r = info.range.getBoundingClientRect();
  const top = Math.max(8, r.top - tool.offsetHeight - 8 < 60 ? r.bottom + 8 : r.top - tool.offsetHeight - 8);
  tool.style.top = top + 'px'; tool.style.left = Math.max(8, Math.min(window.innerWidth - tool.offsetWidth - 8, r.left + r.width / 2 - tool.offsetWidth / 2)) + 'px';
  tool.addEventListener('mousedown', e => e.preventDefault());
  tool.addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return; const s = selInfo; hideTool(); window.getSelection()?.removeAllRanges();
    if (b.dataset.c) { await saveAnnotation({ ...s, color: b.dataset.c }); toast('Highlighted.'); return; }
    const x = b.dataset.x;
    if (x === 'note') annotationModal({ ...s, color: 'yellow', label: '', note: '' }, async (a) => { await saveAnnotation(a); toast('Highlight and note saved.'); });
    if (x === 'bm') { const bm = { id: uid(), type: 'passage', docId: s.docId, p: s.p, quote: s.quote.slice(0, 2000), title: Lib.breadcrumb(s.docId, s.p).slice(-1)[0] || '', createdAt: Date.now() }; S.bm.push(bm); await putItem('bm', bm); toast('Passage bookmarked.'); }
    if (x === 'card') openCardModal({ docId: s.docId, p: s.p, text: s.quote });
    if (x === 'qref') openQrefModal({ docId: s.docId, p: s.p, text: s.quote });
    if (x === 'cite') { const t = `“${s.quote}” (${Lib.cite(s.docId, s.p)})`; try { await navigator.clipboard.writeText(t); toast('Copied with citation.'); } catch { toast('Copy is blocked here.', 'bad'); } }
    if (x === 'ask') { S.askContext = { docId: s.docId, p: s.p, text: s.quote }; go('assistant'); }
  });
}
let selT;
document.addEventListener('selectionchange', () => { clearTimeout(selT); selT = setTimeout(() => { const info = readSelection(); if (info) showTool(info); else if (tool && !tool.matches(':hover')) hideTool(); }, 280); });
window.addEventListener('scroll', () => { if (tool && selInfo) { /* keep */ } }, { passive: true });
document.addEventListener('mousedown', e => { if (tool && !e.target.closest('.seltool')) setTimeout(() => { if (!readSelection()) hideTool(); }, 10); });

actions['attach-pdf'] = (el) => { import('./app.js').then(m => m.pickFileFor(S.docs.get(el.dataset.id))); };
