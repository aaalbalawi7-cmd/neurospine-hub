// Boot, shell, dashboard, PDF library (upload + processing) and settings.
import { Store, local, uid } from './store.js';
import { Lib, esc } from './library.js';
import { DEFAULT_TAXONOMY } from './taxonomy.js';
import { extractPdf, uploadOriginal, uploadPack, downloadPack, forgetPdf, getPdf, imageBoxes, fileFingerprint, CHUNK } from './pdfproc.js';
import { S, views, actions, $, $$, go, render, toast, modal, confirmBox, fmtDate, fmtAgo, n, citeChip, emptyState, saveSingleton, putItem, delItem, bindActions, topicStatusChip, isFav, saveFile, pageHash, storageError } from './core.js';
import './viewer.js';
import './views.js';
import './ai.js';
import { exportBackup } from './exporter.js';
import { apiConfig, saveApiConfig, testKey, MODELS } from './ai-api.js';

// ---------- theme ----------
function applyTheme() {
  const t = S.prefs.theme;
  if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme;
  document.documentElement.style.setProperty('--read-size', (S.prefs.fontSize || 16) + 'px');
}
function currentDark() { const t = document.documentElement.dataset.theme; return t ? t === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches; }

// ---------- progress ----------
export function progress(done, total, msg) {
  const bar = $('#pbar'), m = $('#pmsg');
  if (total == null) { bar.classList.add('hidden'); m.classList.add('hidden'); return; }
  bar.classList.remove('hidden'); m.classList.remove('hidden');
  bar.firstElementChild.style.width = Math.round(100 * done / Math.max(1, total)) + '%';
  m.textContent = msg;
}

// ---------- load everything ----------
async function loadUserData() {
  const [prefs, ts, fav, hist, tax, docs, ann, bm, cards, qc, cols, ai, chats, ocr, imgscan] = await Promise.all([
    Store.getS('prefs'), Store.getS('topicStatus'), Store.getS('favorites'), Store.getS('history'), Store.getS('taxonomy'),
    Store.list('docs'), Store.list('ann'), Store.list('bm'), Store.list('cards'), Store.list('qref'), Store.list('cols'), Store.list('ai'), Store.list('chats'), Store.list('ocr'), Store.list('imgscan'),
  ]);
  if (prefs) Object.assign(S.prefs, prefs);
  S.topicStatus = ts || {}; S.favorites = fav || { topics: [] }; S.history = hist || { items: [], counts: {} };
  if (!S.history.counts) S.history.counts = {};
  S.ann = ann; S.bm = bm; S.cards = cards; S.qcards = qc; S.cols = cols; S.chats = chats.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  S.ai = new Map(ai.map(x => [x.id, x]));
  if (tax?.tree) Lib.setTaxonomy(tax.tree);
  const ocrBy = new Map(); for (const o of ocr) { const d = o.docId; if (!ocrBy.has(d)) ocrBy.set(d, {}); Object.assign(ocrBy.get(d), o.pages || {}); }
  const scanBy = new Map(imgscan.map(x => [x.docId, x.pages || []]));
  S.docs = new Map(docs.sort((a, b) => (a.addedAt || 0) - (b.addedAt || 0)).map(d => [d.id, { ...d, ocr: ocrBy.get(d.id) || {}, imagePages: scanBy.get(d.id) || [] }]));
}

async function loadPack(meta) {
  let pack = await local.get('packs', meta.id);
  if (!pack && meta.pack) { try { pack = await downloadPack(meta.pack); await local.set('packs', meta.id, pack); } catch (e) { console.warn('pack download failed', e); } }
  return pack;
}

async function buildIndex() {
  Lib.reset();
  const metas = [...S.docs.values()].filter(m => m.status !== 'processing');
  let i = 0; const totalPages = metas.reduce((a, m) => a + (m.pages || 0), 0); let done = 0;
  for (const meta of metas) {
    progress(done, totalPages, `Loading ${meta.title || meta.name}…`);
    const pack = await loadPack(meta);
    if (!pack) { meta._missing = true; continue; }
    progress(done, totalPages, `Indexing ${meta.title || meta.name} (${n(meta.pages)} pages)…`);
    await Lib.addDoc(meta, pack);
    done += meta.pages || 0; i++;
  }
  Lib.finalize();
  progress();
}

// ---------- global search box ----------
function initGlobalSearch() {
  const inp = $('#gq'), box = $('#gac'); let sel = -1; let items = [];
  const close = () => { box.classList.add('hidden'); sel = -1; };
  const show = () => {
    if (!Lib.ready || inp.value.trim().length < 2) return close();
    items = Lib.suggest(inp.value, 8);
    if (!items.length) return close();
    box.innerHTML = items.map((s, k) => `<button data-k="${k}" class="${k === sel ? 'on' : ''}"><span>${esc(s.text)}</span><small>${s.kind === 'topic' ? 'Topic' : esc(s.hint || '')}</small></button>`).join('');
    box.classList.remove('hidden');
  };
  const submit = (q) => { close(); if (!q.trim()) return; S.search.q = q; S.search.shown = 20; go('search'); if (S.route.name === 'search') render(); };
  inp.addEventListener('input', show);
  inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); show(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = Math.max(-1, sel - 1); show(); e.preventDefault(); }
    else if (e.key === 'Enter') { const it = items[sel]; if (it?.kind === 'topic') { close(); go('topic-' + it.id); } else submit(it ? it.text : inp.value); }
    else if (e.key === 'Escape') close();
  });
  box.addEventListener('mousedown', e => { const b = e.target.closest('button'); if (!b) return; e.preventDefault(); const it = items[+b.dataset.k]; if (it.kind === 'topic') { close(); go('topic-' + it.id); } else { inp.value = it.text; submit(it.text); } });
  inp.addEventListener('blur', () => setTimeout(close, 150));
}

// ---------- dashboard ----------
views.dashboard = () => {
  const docs = [...S.docs.values()];
  const topics = Lib.allTopics();
  const withContent = topics.filter(t => (Lib.topicPages.get(t.id) || []).length).length;
  const due = S.cards.filter(c => (c.due || 0) <= Date.now()).length;
  const recentDocs = docs.slice().sort((a, b) => b.addedAt - a.addedAt).slice(0, 5);
  const recentTopics = S.history.items.filter(x => x.type === 'topic' && Lib.topics.has(x.id)).slice(0, 6);
  const recentPages = S.history.items.filter(x => x.type === 'page' && S.docs.has(x.docId)).slice(0, 5);
  const freq = Object.entries(S.history.counts).filter(([id]) => Lib.topics.has(id)).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const pending = Object.entries(S.topicStatus).filter(([id, s]) => s === 'review' && Lib.topics.has(id));
  const favs = S.favorites.topics.filter(id => Lib.topics.has(id));
  const bms = S.bm.slice().sort((a, b) => b.createdAt - a.createdAt).slice(0, 5);
  const tlink = id => { const t = Lib.topics.get(id); return `<a href="#topic-${id}">${esc(t.name)}</a>`; };
  const onboarding = !docs.length ? `<div class="panel" style="margin-bottom:18px"><div class="row between"><div class="stack" style="gap:6px"><h2>Start by adding your references</h2><p class="muted">Upload textbooks, guidelines, lecture notes or papers as PDFs. Each one is read page by page, indexed for search and sorted into the categories below. Every passage you see later links back to its document and page.</p></div><a class="btn primary" href="#library">Upload PDFs</a></div></div>` : '';
  return `
  <div class="page-head"><span class="eyebrow">Dashboard</span><h1>Your neurosurgery and spine library</h1></div>
  ${onboarding}
  <div class="tiles" style="margin-bottom:18px">
    <div class="tile"><b>${n(docs.length)}</b><span>PDF documents</span></div>
    <div class="tile"><b>${n(Lib.pageCount)}</b><span>Pages indexed</span></div>
    <div class="tile"><b>${n(withContent)}</b><span>Topics with sources</span></div>
    <div class="tile"><b>${n(Lib.figures.length)}</b><span>Figures &amp; tables</span></div>
    <div class="tile"><b>${n(S.ann.length)}</b><span>Highlights &amp; notes</span></div>
    <div class="tile"><b>${n(due)}</b><span>Flashcards due</span></div>
  </div>
  <form class="bigsearch" data-search-form style="margin-bottom:20px"><input type="search" id="dq" placeholder="Search all documents, for example: Spetzler-Martin, &quot;cauda equina&quot;, ACDF AND complications" aria-label="Search all documents"><button class="btn primary">Search</button></form>
  <div class="grid g3">
    <div class="panel"><h3>Recently added documents</h3>${recentDocs.length ? `<div class="list">${recentDocs.map(d => `<div class="li"><div><div class="t">${esc(d.title || d.name)}</div><small>${n(d.pages)} pages · ${fmtDate(d.addedAt)}</small></div><a class="btn sm" href="#${pageHash(d.id, 0)}">Open</a></div>`).join('')}</div>` : '<p class="muted">No documents yet.</p>'}</div>
    <div class="panel"><h3>Recently viewed topics</h3>${recentTopics.length ? `<div class="list">${recentTopics.map(x => `<div class="li">${tlink(x.id)}<small>${fmtAgo(x.t)}</small></div>`).join('')}</div>` : '<p class="muted">Topics you open appear here.</p>'}</div>
    <div class="panel"><h3>Frequently accessed</h3>${freq.length ? `<div class="list">${freq.map(([id, c]) => `<div class="li">${tlink(id)}<small class="tnum">${c} visits</small></div>`).join('')}</div>` : '<p class="muted">Your most-visited topics appear here.</p>'}</div>
    <div class="panel"><h3>Favorite topics</h3>${favs.length ? `<div class="list">${favs.map(id => `<div class="li">${tlink(id)}${topicStatusChip(id)}</div>`).join('')}</div>` : '<p class="muted">Star a topic to pin it here.</p>'}</div>
    <div class="panel"><h3>Pending review</h3>${pending.length ? `<div class="list">${pending.map(([id]) => `<div class="li">${tlink(id)}<span class="status s-review">Needs review</span></div>`).join('')}</div>` : '<p class="muted">Mark topics as “Needs review” to queue them here.</p>'}</div>
    <div class="panel"><h3>Saved bookmarks</h3>${bms.length ? `<div class="list">${bms.map(b => `<div class="li"><div><div class="t">${esc(b.title || 'Page ' + Lib.label(b.docId, b.p))}</div><small>${esc(Lib.shortName(b.docId))}</small></div>${S.docs.has(b.docId) ? citeChip(b.docId, b.p) : ''}</div>`).join('')}</div>` : '<p class="muted">Bookmark pages or passages while reading.</p>'}</div>
  </div>
  ${recentPages.length ? `<div class="panel" style="margin-top:16px"><h3>Reading history</h3><div class="chips">${recentPages.map(x => citeChip(x.docId, x.p)).join('')}</div></div>` : ''}
  `;
};
views.after_dashboard = (a, root) => {
  const f = root.querySelector('[data-search-form]');
  f?.addEventListener('submit', e => { e.preventDefault(); const q = root.querySelector('#dq').value; if (q.trim()) { S.search.q = q; S.search.shown = 20; go('search'); } });
};

// ---------- PDF library ----------
const saveDocMeta = (d) => { const { ocr, imagePages, _missing, ...rest } = d; return putItem('docs', rest); };
const queue = []; let running = false;
function cleanTitle(name) {
  let t = name.replace(/\.pdf$/i, '').replace(/^[0-9a-f]{8}-/i, '').replace(/^\d{6,}-/, '');
  t = t.replace(/_s_/g, "'s ").replace(/_s$/, "'s");
  if (!/\s/.test(t)) t = t.replace(/[-_]+/g, ' '); else t = t.replace(/_+/g, ' ');
  return t.replace(/\s+/g, ' ').trim().slice(0, 140);
}

views.library = () => {
  const docs = [...S.docs.values()].sort((a, b) => b.addedAt - a.addedAt);
  const cloudNote = Store.standalone ? 'Your library is stored in this browser on this device only. On iPhone, add this site to your Home Screen (Share › Add to Home Screen) so Safari keeps your PDFs and notes, and export a backup from Settings now and then.' : Store.cloud ? (Store.assets ? 'Your library is saved to your private cloud storage and follows you to other devices.' : 'Your notes sync to the cloud. Original PDFs stay on this device because file storage is only available to the hub\'s owner and editors.') : 'Cloud storage is not available in this view, so everything is kept in this browser only.';
  return `
  <div class="page-head"><span class="eyebrow">PDF Library</span><h1>Documents</h1><p>${cloudNote}</p></div>
  <div class="dropzone" id="drop">
    <h3>Drop PDF files here</h3>
    <p class="muted">Several files at once are fine, including large textbooks. Text, headings, outline, page numbers and figure captions are extracted in your browser.</p>
    <div class="row"><label class="btn primary" for="files">Choose PDFs</label><input id="files" type="file" accept="application/pdf,.pdf" multiple class="hidden">
    <label class="chk"><input type="checkbox" id="store-orig" ${S.prefs.storeOriginals ? 'checked' : ''} ${Store.assets ? '' : 'disabled'}> Keep original PDFs in cloud storage</label></div>
  </div>
  <div class="panel ${queue.length ? '' : 'hidden'}" id="queue" style="margin-top:16px"><h3>Processing</h3><div id="qlist"></div></div>
  <div class="row between" style="margin:22px 0 10px"><h2>${n(docs.length)} document${docs.length === 1 ? '' : 's'}</h2><span class="muted tnum">${n(Lib.pageCount)} pages indexed</span></div>
  ${docs.length ? `<div class="docs">${docs.map(docCard).join('')}</div>` : emptyState('No documents yet', 'Upload your first PDF to build the library.')}
  `;
};
function docCard(d) {
  const ld = Lib.docs.get(d.id);
  const topTopics = ld ? topicsForDoc(d.id).slice(0, 4) : [];
  const where = d.chunks?.length ? 'Original in cloud' : 'Original on this device';
  const scanned = (d.scanned || []).length; const ocrDone = Object.keys(d.ocr || {}).length;
  return `<div class="doc" data-doc="${d.id}">
    ${d.thumb ? `<img src="${d.thumb}" alt="">` : '<div class="ph"></div>'}
    <div class="stack" style="gap:7px">
      <h3>${esc(d.title || d.name)}</h3>
      <div class="facts"><span class="tnum">${n(d.pages)} pages</span><span>${n((ld?.pack.figs || []).length)} figure/table captions</span><span>${(ld?.pack.outline || []).length} outline entries</span><span>${where}</span>${d.status === 'processing' ? '<span style="color:var(--warn)">Processing interrupted</span>' : ''}${d._missing ? '<span style="color:var(--bad)">Index unavailable</span>' : ''}${scanned ? `<span>${scanned} scanned page${scanned > 1 ? 's' : ''}${ocrDone ? ` · ${ocrDone} OCR'd` : ''}</span>` : ''}</div>
      ${topTopics.length ? `<div class="chips">${topTopics.map(([id]) => `<a class="chip" href="#topic-${id}">${esc(Lib.topics.get(id).name)}</a>`).join('')}</div>` : ''}
      <div class="row" style="gap:6px">
        ${d.status === 'processing' ? `<button class="btn sm primary" data-act="resume" data-id="${d.id}">Resume</button>` : `<a class="btn sm primary" href="#${pageHash(d.id, 0)}">Open</a><button class="btn sm" data-act="doc-search" data-id="${d.id}">Search in document</button>`}
        <button class="btn sm ghost" data-act="doc-more" data-id="${d.id}">More…</button>
      </div>
    </div>
  </div>`;
}
function topicsForDoc(docId) {
  const d = Lib.docs.get(docId); if (!d) return [];
  const agg = new Map();
  for (let gi = d.base; gi < d.base + d.n; gi++) for (const [tid, s] of Lib.pageTopics[gi] || []) agg.set(tid, (agg.get(tid) || 0) + s);
  return [...agg.entries()].sort((a, b) => b[1] - a[1]);
}
views.after_library = (a, root) => {
  const inp = root.querySelector('#files'), drop = root.querySelector('#drop');
  inp.addEventListener('change', () => { enqueue([...inp.files]); inp.value = ''; });
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => enqueue([...e.dataTransfer.files]));
  root.querySelector('#store-orig').addEventListener('change', e => { S.prefs.storeOriginals = e.target.checked; saveSingleton('prefs'); });
  renderQueue();
};
function renderQueue() {
  const box = $('#qlist'); if (!box) return;
  $('#queue').classList.toggle('hidden', !queue.length);
  box.innerHTML = queue.map(q => `<div class="queue-item"><div class="row between"><b>${esc(q.name)}</b><span class="muted tnum">${esc(q.msg || '')}</span></div><div class="meter"><i style="width:${Math.round((q.pct || 0) * 100)}%"></i></div></div>`).join('');
}
function setQ(q, msg, pct) { q.msg = msg; if (pct != null) q.pct = pct; renderQueue(); }

function enqueue(files) {
  const pdfs = files.filter(f => /\.pdf$/i.test(f.name) || f.type === 'application/pdf');
  if (files.length && !pdfs.length) toast('Only PDF files can be added.', 'bad');
  for (const f of pdfs) queue.push({ file: f, name: f.name, msg: 'Waiting', pct: 0 });
  renderQueue();
  if (!running) runQueue();
}
async function runQueue() {
  running = true;
  while (queue.length) {
    const q = queue[0];
    try { await processFile(q); } catch (e) { console.error(e); toast(`${q.name}: ${e.message || 'processing failed'}`, 'bad'); }
    queue.shift(); renderQueue();
  }
  running = false;
  if (S.route.name === 'library') render();
}

async function processFile(q, existing) {
  const file = q.file;
  // duplicate checks: same name + size, then same PDF fingerprint
  if (!existing) {
    const dupName = [...S.docs.values()].find(d => d.name === file.name && d.size === file.size);
    if (dupName) { toast(`${file.name} is already in your library.`); return; }
    setQ(q, 'Checking for duplicates', 0.01);
    const { fingerprint } = await fileFingerprint(file);
    const dupFp = fingerprint && [...S.docs.values()].find(d => d.fingerprint === fingerprint);
    if (dupFp) { toast(`${file.name} is the same PDF as “${dupFp.title || dupFp.name}”. Skipped.`); return; }
  }
  const id = existing?.id || uid().replace(/[^a-z0-9]/gi, '');
  const meta = existing || { id, name: file.name, title: cleanTitle(file.name), size: file.size, addedAt: Date.now(), status: 'processing' };
  if (!existing) { S.docs.set(id, meta); await saveDocMeta(meta); }
  const savedLocal = await local.set('files', id, file);
  const partial = await local.get('partial', id);
  const res = await extractPdf(file, {
    partial,
    onProgress: ({ stage, done, total }) => setQ(q, `${stage} ${done ? n(done) + ' / ' + n(total) : ''}`, 0.05 + 0.75 * (done / Math.max(1, total))),
    onCheckpoint: (st) => local.set('partial', id, st),
  });
  const pack = { title: meta.title, numPages: res.numPages, labels: res.labels, labelSource: res.labelSource, outline: res.outline, heads: res.heads, figs: res.figs, scanned: res.scanned, pages: res.pages };
  await local.set('packs', id, pack);
  Object.assign(meta, { pages: res.numPages, fingerprint: res.fingerprint, thumb: res.thumb, scanned: res.scanned, figures: res.figs.length, savedLocal });
  // cloud copies
  if (Store.assets) {
    try { setQ(q, 'Saving text index to cloud', 0.82); meta.pack = await uploadPack(pack); }
    catch (e) { console.warn('pack upload', e); toast('The text index could not be saved to the cloud; it is kept on this device.', 'bad'); }
    if (S.prefs.storeOriginals) {
      const usage = await Store.usage();
      const room = usage ? usage.maxBytes - usage.bytes : Infinity;
      const tooMany = usage ? usage.files + Math.ceil(file.size / CHUNK) + 2 > usage.maxFiles : false;
      if (room < file.size * 1.02 || tooMany) toast(`Cloud file storage is nearly full, so the original of ${meta.title} stays on this device.`, 'bad');
      else {
        try { const up = await uploadOriginal(file, ({ done, total }) => setQ(q, `Storing original PDF ${done} / ${total}`, 0.84 + 0.15 * done / total)); Object.assign(meta, up); }
        catch (e) { console.warn('original upload', e); toast(`The original of ${meta.title} could not be stored in the cloud (${e.code || e.message}). It stays on this device.`, 'bad'); }
      }
    }
  }
  meta.status = 'ready';
  await saveDocMeta(meta);
  await local.del('partial', id);
  setQ(q, 'Indexing', 0.99);
  await Lib.addDoc(meta, pack); Lib.finalize();
  const found = topicsForDoc(id).length;
  toast(`${meta.title}: ${n(res.numPages)} pages indexed, ${found} topics matched.`);
}

actions.resume = async (el) => {
  const meta = S.docs.get(el.dataset.id); const file = await local.get('files', meta.id);
  if (!file) { pickFileFor(meta, true); return; }
  const q = { file, name: meta.name, msg: 'Resuming', pct: 0 }; queue.push(q); renderQueue();
  if (!running) { running = true; try { await processFile(q, meta); } catch (e) { toast(e.message, 'bad'); } queue.shift(); running = false; render(); }
};
actions['doc-search'] = (el) => { S.search.opts.docs = [el.dataset.id]; S.search.q = S.search.q || ''; go('search'); };
actions['doc-more'] = async (el) => {
  const d = S.docs.get(el.dataset.id); const hasLocal = !!(await local.get('files', d.id));
  const scanned = (d.scanned || []).filter(p => !(d.ocr || {})[p]);
  const m = modal(`<h3>${esc(d.title || d.name)}</h3>
    <div class="stack">
      <label>Display title <input type="text" id="dt" value="${esc(d.title || d.name)}" style="width:100%"></label>
      <div class="muted" style="font-size:13px">File: ${esc(d.name)} · ${(d.size / 1048576).toFixed(1)} MB · added ${fmtDate(d.addedAt)}<br>Original PDF: ${hasLocal ? 'on this device' : 'not on this device'}${d.chunks?.length ? ' · in cloud storage' : ''}</div>
      <div class="row">
        <button class="btn" id="m-save">Save title</button>
        <button class="btn" id="m-relink">${hasLocal ? 'Replace local copy' : 'Attach the PDF on this device'}</button>
        ${d.chunks?.length && !hasLocal ? '<button class="btn" id="m-keep">Download a copy to this device</button>' : ''}
        <button class="btn" id="m-scan">Find uncaptioned images</button>
        ${scanned.length ? `<button class="btn" id="m-ocr">OCR ${scanned.length} scanned page${scanned.length > 1 ? 's' : ''}</button>` : ''}
        <button class="btn danger" id="m-del">Remove from library</button>
      </div>
      <p class="muted" style="font-size:12.5px" id="m-msg"></p>
    </div>`);
  const $m = s => m.el.querySelector(s);
  $m('#m-save').onclick = async () => { d.title = $m('#dt').value.trim() || d.name; await saveDocMeta(d); m.close(); render(); };
  $m('#m-relink').onclick = () => { m.close(); pickFileFor(d); };
  $m('#m-keep') && ($m('#m-keep').onclick = async () => {
    $m('#m-msg').textContent = 'Downloading…';
    try { const parts = []; for (const [i, c] of d.chunks.entries()) { const r = await Store.fetchAsset(c.id); parts.push((await r.blob()).slice(d.hdr)); $m('#m-msg').textContent = `Downloading ${i + 1} / ${d.chunks.length}`; } await local.set('files', d.id, new Blob(parts, { type: 'application/pdf' })); forgetPdf(d.id); $m('#m-msg').textContent = 'Saved on this device.'; }
    catch (e) { $m('#m-msg').textContent = 'Download failed: ' + e.message; }
  });
  $m('#m-scan').onclick = () => { m.close(); deepImageScan(d); };
  $m('#m-ocr') && ($m('#m-ocr').onclick = () => { m.close(); actions['ocr-doc']?.(d, scanned); });
  $m('#m-del').onclick = async () => {
    if (!await confirmBox(`Remove “${d.title || d.name}”? Your highlights and notes on it are kept.`, 'Remove')) return;
    m.close(); S.docs.delete(d.id); await delItem('docs', d.id); await local.del('files', d.id); await local.del('packs', d.id); forgetPdf(d.id);
    for (const a of [...(d.chunks || []), ...(d.pack?.parts || []), ...(d.pack ? [{ id: d.pack.meta }] : [])]) await Store.deleteAsset(a.id);
    await Lib.removeDoc(d.id); render(); toast('Removed.');
  };
};
function pickFileFor(meta, resume) {
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'application/pdf,.pdf';
  inp.onchange = async () => {
    const f = inp.files[0]; if (!f) return;
    const { fingerprint, numPages } = await fileFingerprint(f);
    if ((meta.fingerprint && fingerprint !== meta.fingerprint) || (meta.pages && numPages !== meta.pages)) { toast('That file is a different PDF from the one in your library.', 'bad'); return; }
    await local.set('files', meta.id, f); forgetPdf(meta.id); toast('PDF attached on this device.');
    if (resume) actions.resume({ dataset: { id: meta.id } }); else render();
  };
  inp.click();
}
export { pickFileFor };

async function deepImageScan(d) {
  let pdf; try { ({ pdf } = await getPdf(d)); } catch { toast('The original PDF is needed for an image scan. Attach it first.', 'bad'); return; }
  const found = []; const pack = Lib.docs.get(d.id)?.pack; const captioned = new Set((pack?.figs || []).map(f => f.p));
  for (let p = 0; p < pdf.numPages; p++) {
    if (p % 10 === 0) progress(p, pdf.numPages, `Scanning ${d.title} for images: page ${p + 1} of ${pdf.numPages}`);
    try {
      const page = await pdf.getPage(p + 1); const vp = page.getViewport({ scale: 1 });
      const boxes = (await imageBoxes(page)).filter(b => b.w * b.h > vp.width * vp.height * 0.04);
      if (boxes.length && !captioned.has(p)) found.push(p);
      page.cleanup();
    } catch { /* skip page */ }
  }
  progress();
  d.imagePages = found;
  await Store.put('imgscan', d.id, { docId: d.id, pages: found }).catch(storageError);
  Lib.mineFigures(); toast(`${found.length} pages with uncaptioned images added to the Image Library.`);
}

// ---------- settings ----------
views.settings = async () => {
  const usage = Store.assets ? await Store.usage() : null;
  let est = null; try { est = await navigator.storage?.estimate?.(); } catch { /* ignore */ }
  const mb = x => (x / 1048576).toFixed(1) + ' MB';
  return `
  <div class="page-head"><span class="eyebrow">Settings</span><h1>Settings</h1></div>
  <div class="grid g2">
    <div class="panel stack"><h3>Appearance</h3>
      <div class="row"><span style="width:110px">Theme</span><div class="seg" id="themeseg">${['system', 'light', 'dark'].map(t => `<button data-t="${t}" class="${S.prefs.theme === t ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div></div>
      <div class="row"><span style="width:110px">Reading size</span><input type="range" min="13" max="22" value="${S.prefs.fontSize}" id="fsz"><span class="tnum" id="fszv">${S.prefs.fontSize}px</span></div>
    </div>
    <div class="panel stack"><h3>Search</h3>
      <label class="chk"><input type="checkbox" id="pf-fuzzy" ${S.prefs.fuzzy ? 'checked' : ''}> Fuzzy matching for spelling variations by default</label>
      <label class="chk"><input type="checkbox" id="pf-abbr" ${S.prefs.abbr !== false ? 'checked' : ''}> Expand abbreviations (SAH ↔ subarachnoid hemorrhage)</label>
      <p class="muted" style="font-size:13px">British and American spellings (haemorrhage, tumour, paediatric) always match each other.</p>
    </div>
    <div class="panel stack"><h3>Storage</h3>
      <p>${Store.standalone ? 'This website keeps your PDFs, index, highlights, notes, bookmarks and flashcards in this browser on this device. On iPhone, add it to your Home Screen so Safari doesn\'t clear them, and export a backup regularly.' : Store.cloud ? 'Notes, highlights, bookmarks, flashcards and settings are saved to your private cloud storage, visible only to you.' : 'Cloud storage is unavailable in this view. Data is saved in this browser only; export a backup regularly.'}</p>
      ${usage ? `<div><div class="row between"><span>Cloud file storage</span><span class="tnum muted">${mb(usage.bytes)} of ${mb(usage.maxBytes)} · ${usage.files} / ${usage.maxFiles} files</span></div><div class="meter"><i style="width:${Math.min(100, 100 * usage.bytes / usage.maxBytes)}%"></i></div></div>` : ''}
      ${est ? `<div class="row between"><span>This device (cache)</span><span class="tnum muted">${mb(est.usage || 0)} used</span></div>` : ''}
      <div class="row"><button class="btn" data-act="clear-cache">Clear this device's cache</button></div>
    </div>
    ${Store.standalone ? aiPanel() : ''}
    <div class="panel stack"><h3>Backup and recovery</h3>
      <p class="muted">A backup holds your highlights, notes, bookmarks, collections, flashcards, quick-reference cards, topic statuses, categories and document list. PDFs are not included.</p>
      <div class="row"><button class="btn primary" data-act="backup">Export backup (JSON)</button><label class="btn" for="restore">Restore from backup</label><input type="file" id="restore" accept=".json,application/json" class="hidden"></div>
    </div>
  </div>
  <div class="panel stack" style="margin-top:16px">
    <div class="row between"><h3>Categories and topics</h3><div class="row"><button class="btn sm" data-act="tax-add-cat">Add category</button><button class="btn sm" data-act="tax-reset">Reset to defaults</button><button class="btn sm primary" data-act="tax-save">Save categories</button></div></div>
    <p class="muted" style="font-size:13px">Rename, add or remove categories and topics. Keywords decide which pages belong to a topic (comma-separated; add <span class="mono">:2</span> to weight a keyword). Pages are re-sorted when you save.</p>
    <div id="taxed" class="stack">${taxEditor()}</div>
  </div>
  <div class="panel stack" style="margin-top:16px"><h3>Source policy</h3>
    <p>Everything this hub shows (passages, classifications, figures, quick-reference entries, flashcard answers and assistant replies) comes from the PDFs you upload. Topic pages show verbatim excerpts with their document and page. Where your sources have nothing on a heading, the heading is left out, and searches or questions with no match say “Information not found in the uploaded sources.” AI is used only to organize, summarize or compare passages taken from your library, and every AI statement must cite a passage you can open.</p>
  </div>`;
};
function aiPanel() {
  const c = apiConfig();
  return `<div class="panel stack"><h3>AI assistant</h3>
    <p class="muted" style="font-size:13.5px">The assistant, cited summaries, AI flashcards, comparisons and scanned-page reading use the Claude API with your own key from the Claude Console (console.anthropic.com). The key is saved only in this browser, requests go straight from this device to Anthropic, and usage is billed to your API account. Everything else works without a key.</p>
    <label>API key <input type="text" id="api-key" autocomplete="off" spellcheck="false" placeholder="sk-ant-…" value="${esc(c.key ? c.key.slice(0, 10) + '…' + c.key.slice(-4) : '')}" style="width:100%"></label>
    <label>Model <select id="api-model" style="width:100%">${MODELS.map(([id, name]) => `<option value="${id}" ${(c.model || MODELS[0][0]) === id ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label>
    <div class="row"><button class="btn primary" data-act="api-save">Save and test</button>${c.key ? '<button class="btn danger" data-act="api-clear">Remove key</button>' : ''}<span class="muted" id="api-msg" style="font-size:13px">${c.key ? 'A key is saved on this device.' : 'No key saved.'}</span></div>
  </div>`;
}
actions['api-save'] = async () => {
  const inp = $('#api-key'); const old = apiConfig(); let key = inp.value.trim();
  if (key.includes('…') && old.key) key = old.key;
  const cfg = { key, model: $('#api-model').value };
  if (!/^sk-ant-/.test(key)) { $('#api-msg').textContent = 'That doesn\'t look like a Claude API key (it starts with sk-ant-).'; return; }
  $('#api-msg').textContent = 'Testing…';
  try { await testKey(cfg); saveApiConfig(cfg); Store.aiReady = true; $('#api-msg').textContent = 'Key works. The assistant is on.'; toast('AI assistant enabled.'); }
  catch (e) { $('#api-msg').textContent = e.code === 'bad_key' ? 'The key was rejected.' : e.code === 'bad_model' ? 'This model isn\'t available for your key. Pick another.' : 'Could not reach the API: ' + (e.message || e.code); }
};
actions['api-clear'] = async () => { if (!await confirmBox('Remove the API key from this device?', 'Remove')) return; saveApiConfig(null); Store.aiReady = false; render(); };

let taxDraft = null;
function taxEditor() {
  taxDraft = taxDraft || JSON.parse(JSON.stringify(Lib.taxonomy));
  return taxDraft.map((c, ci) => `<details class="cat"><summary><span class="code">${esc(c.code || ci + 1)}</span><input type="text" value="${esc(c.name)}" data-input="tax-cat" data-ci="${ci}" style="flex:1" onclick="event.stopPropagation()"><button class="btn sm danger" data-act="tax-del-cat" data-ci="${ci}">Remove</button></summary>
    <div class="stack" style="padding:12px 16px">${c.subs.map((s, si) => s.alias ? `<div class="row muted" style="font-size:13px">↳ ${esc(s.name)} (shared with another category) <button class="btn sm ghost" data-act="tax-del-sub" data-ci="${ci}" data-si="${si}">Remove</button></div>` : `<div class="grid" style="grid-template-columns:220px 1fr auto;gap:8px;align-items:start"><input type="text" value="${esc(s.name)}" data-input="tax-sub-name" data-ci="${ci}" data-si="${si}"><textarea data-input="tax-sub-kw" data-ci="${ci}" data-si="${si}" style="min-height:44px">${esc((s.kw || []).join(', '))}</textarea><button class="btn sm danger" data-act="tax-del-sub" data-ci="${ci}" data-si="${si}">Remove</button></div>`).join('')}
    <div><button class="btn sm" data-act="tax-add-sub" data-ci="${ci}">Add topic</button></div></div></details>`).join('');
}
const reTax = () => { $('#taxed').innerHTML = taxEditor(); };
actions['tax-cat'] = el => { taxDraft[el.dataset.ci].name = el.value; };
actions['tax-sub-name'] = el => { taxDraft[el.dataset.ci].subs[el.dataset.si].name = el.value; };
actions['tax-sub-kw'] = el => { taxDraft[el.dataset.ci].subs[el.dataset.si].kw = el.value.split(',').map(s => s.trim().toLowerCase()).filter(Boolean); };
actions['tax-add-sub'] = el => { taxDraft[el.dataset.ci].subs.push({ id: 'c-' + uid(), name: 'New topic', kw: [] }); reTax(); $$('#taxed details')[el.dataset.ci].open = true; };
actions['tax-del-sub'] = el => { taxDraft[el.dataset.ci].subs.splice(el.dataset.si, 1); reTax(); $$('#taxed details')[el.dataset.ci].open = true; };
actions['tax-add-cat'] = () => { taxDraft.push({ id: 'cat-' + uid(), name: 'New category', code: String.fromCharCode(65 + taxDraft.length), subs: [] }); reTax(); };
actions['tax-del-cat'] = async el => { if (await confirmBox('Remove this category and its topics?', 'Remove')) { taxDraft.splice(el.dataset.ci, 1); reTax(); } };
actions['tax-reset'] = async () => { if (await confirmBox('Reset categories to the defaults? Custom topics will be removed.', 'Reset')) { taxDraft = JSON.parse(JSON.stringify(DEFAULT_TAXONOMY)); reTax(); } };
actions['tax-save'] = async () => { await saveTaxonomy(taxDraft); taxDraft = null; toast('Categories saved and pages re-sorted.'); render(); };
export async function saveTaxonomy(tree) {
  Lib.setTaxonomy(JSON.parse(JSON.stringify(tree)));
  Lib.classify(); Lib.mineFigures(); Lib.version++;
  await Store.setS('taxonomy', { tree: Lib.taxonomy }).catch(storageError);
}
actions['clear-cache'] = async () => { if (!await confirmBox('Clear cached PDFs and indexes on this device? Cloud copies are not affected; local-only PDFs will need to be attached again.', 'Clear')) return; for (const s of ['packs', 'files', 'thumbs', 'partial']) await local.clear(s); toast('Cache cleared. Reloading…'); setTimeout(() => location.reload(), 800); };
actions.backup = () => exportBackup();

views.after_settings = (a, root) => {
  root.querySelector('#themeseg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; S.prefs.theme = b.dataset.t; applyTheme(); saveSingleton('prefs'); $$('#themeseg button').forEach(x => x.classList.toggle('on', x === b)); });
  const fs = root.querySelector('#fsz'); fs.addEventListener('input', () => { S.prefs.fontSize = +fs.value; root.querySelector('#fszv').textContent = fs.value + 'px'; applyTheme(); });
  fs.addEventListener('change', () => saveSingleton('prefs'));
  root.querySelector('#pf-fuzzy').addEventListener('change', e => { S.prefs.fuzzy = e.target.checked; S.search.opts.fuzzy = e.target.checked; saveSingleton('prefs'); });
  root.querySelector('#pf-abbr').addEventListener('change', e => { S.prefs.abbr = e.target.checked; S.search.opts.abbr = e.target.checked; saveSingleton('prefs'); });
  root.querySelector('#restore').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    try { const { importBackup } = await import('./exporter.js'); const c = await importBackup(JSON.parse(await f.text())); toast(`Restored ${c} items.`); await loadUserData(); render(); }
    catch (err) { toast('That file is not a valid backup: ' + err.message, 'bad'); }
  });
};

// ---------- boot ----------
async function boot() {
  bindActions(document.body);
  $('#burger').onclick = () => document.body.classList.toggle('nav-open');
  document.body.addEventListener('click', e => { if (document.body.classList.contains('nav-open') && !e.target.closest('#side') && !e.target.closest('#burger')) document.body.classList.remove('nav-open'); });
  $('#theme-btn').onclick = () => { S.prefs.theme = currentDark() ? 'light' : 'dark'; applyTheme(); saveSingleton('prefs'); };
  initGlobalSearch();
  window.addEventListener('hashchange', render);
  applyTheme();
  render();
  await Store.init(status => {
    const pill = $('#storage-pill');
    pill.className = 'pill ' + (status === 'cloud' ? 'ok' : 'warn');
    pill.lastElementChild.textContent = status === 'cloud' ? 'Synced to your private cloud' : 'Saved on this device';
  });
  await loadUserData();
  S.search.opts.fuzzy = !!S.prefs.fuzzy; S.search.opts.abbr = S.prefs.abbr !== false;
  applyTheme();
  await buildIndex();
  render();
  // resume interrupted processing if the file is still here
  for (const d of S.docs.values()) if (d.status === 'processing' && await local.get('files', d.id)) toast(`Processing of ${d.title} was interrupted. Open the PDF Library to resume.`);
}
window.__hub = { S, Lib, Store };
boot();
